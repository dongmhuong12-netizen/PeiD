import { db } from "../src/db.js";

async function main() {
    const matches = await db.match.findMany({});
    console.log("=== Matches in DB ===");
    console.log(JSON.stringify(matches, null, 2));

    const swipes = await db.swipe.findMany({});
    console.log("=== Swipes in DB ===");
    console.log(JSON.stringify(swipes, null, 2));

    const profiles = await db.profile.findMany({});
    console.log("=== Profiles in DB ===");
    console.log(JSON.stringify(profiles, null, 2));
}

main().catch(console.error).finally(() => db.$disconnect());
