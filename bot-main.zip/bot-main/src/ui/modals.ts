import {
  FileUploadBuilder,
  LabelBuilder,
  ModalBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { Gender } from "@prisma/client";
import { LIMITS } from "../limits.js";
import { ID } from "../lib/ids.js";
import { PROMPTS, REQUIRED_PROMPTS } from "../features/prompts.js";
import { REPORT_REASONS } from "../features/reportReasons.js";
import { socialSpec } from "../features/socials.js";
import { GENDER_LABEL } from "./theme.js";
import type { FullProfile } from "./profileCard.js";

/// Modal cua Discord gio nhan duoc select menu VA file upload, khong con
/// chi text input nhu truoc. Nho vay toan bo onboarding — ten, tuoi, gioi
/// tinh, gu, anh — gom trong DUNG MOT popup.
///
/// Ke hoach ban dau la: modal text -> bot hoi anh -> user gui anh. Ba buoc,
/// va buoc cuoi dien ra trong kenh chat cong khai. Mot modal thi kin dao
/// hon va bo it nguoi giua chung hon.
///
/// Gioi han cung: 5 component moi modal.

/// Tao TextInput.
///
/// ⚠ Mau chot: CHI set value khi co noi dung. `.setValue("")` sinh ra
/// `value: ""` trong JSON, va Discord tu choi ca modal voi loi
/// `BASE_TYPE_MIN_LENGTH: Must be 2 or more` khi o co minLength — vi gia tri
/// mac dinh rong ngan hon minLength. Luc tao ho so moi, moi o deu rong, nen
/// bug nay lam /profile setup hong hoan toan.
///
/// Gom vao mot cho de khong con `.setValue(x ?? "")` rai rac — moi cai la
/// mot qua min chuc no.
function textInput(o: {
  id: string;
  style: TextInputStyle;
  min?: number;
  max?: number;
  required?: boolean;
  placeholder?: string;
  value?: string | null;
}): TextInputBuilder {
  const t = new TextInputBuilder().setCustomId(o.id).setStyle(o.style);
  if (o.min != null) t.setMinLength(o.min);
  if (o.max != null) t.setMaxLength(o.max);
  if (o.required != null) t.setRequired(o.required);
  if (o.placeholder) t.setPlaceholder(o.placeholder);
  if (o.value) t.setValue(o.value); // rong/undefined -> KHONG set
  return t;
}

/// Label description gioi han 100 ky tu (discord.js chan bang shapeshift o
/// toJSON). Cat cung de khong bao gio vuot — dung cho description dong theo
/// du lieu (vd hint MXH doi theo platform).
const clampDesc = (s: string) => (s.length > 100 ? s.slice(0, 99) + "…" : s);

const genderOptions = (selected?: string[]) =>
  Object.values(Gender).map((g) =>
    new StringSelectMenuOptionBuilder()
      .setLabel(GENDER_LABEL[g] ?? g)
      .setValue(g)
      .setDefault(selected?.includes(g) ?? false)
  );

export function basicsModal(existing?: FullProfile | null): ModalBuilder {
  const m = new ModalBuilder()
    .setCustomId(ID.profileModal("basics"))
    .setTitle(existing ? "Sửa thông tin" : "Tạo hồ sơ");

  const photoRequired = !existing?.photoUrl;

  m.addLabelComponents(
    new LabelBuilder().setLabel("Tên hiển thị").setTextInputComponent(
      textInput({
        id: "name",
        style: TextInputStyle.Short,
        min: 2,
        max: 32,
        required: true,
        placeholder: "Tên bạn muốn người khác gọi",
        value: existing?.displayName,
      })
    ),

    new LabelBuilder()
      .setLabel("Tuổi")
      .setDescription("Bot chỉ dành cho người từ 18 tuổi trở lên.")
      .setTextInputComponent(
        textInput({
          id: "age",
          style: TextInputStyle.Short,
          min: 2,
          max: 2,
          required: true,
          placeholder: "18",
          value: existing ? String(existing.age) : undefined,
        })
      ),

    new LabelBuilder()
      .setLabel("Giới tính của bạn")
      .setStringSelectMenuComponent(
        new StringSelectMenuBuilder()
          .setCustomId("gender")
          .setMinValues(1)
          .setMaxValues(1)
          .setPlaceholder("Chọn một")
          .addOptions(genderOptions(existing ? [existing.gender] : undefined))
      ),

    new LabelBuilder()
      .setLabel("Bạn muốn tìm")
      .setDescription("Chọn được nhiều lựa chọn.")
      .setStringSelectMenuComponent(
        new StringSelectMenuBuilder()
          .setCustomId("seeking")
          .setMinValues(1)
          .setMaxValues(Object.values(Gender).length)
          .setPlaceholder("Chọn một hoặc nhiều")
          .addOptions(genderOptions(existing?.seeking))
      ),

    new LabelBuilder()
      .setLabel(existing?.photoUrl ? "Đổi ảnh" : "Ảnh đại diện")
      .setDescription(
        existing?.photoUrl
          ? "Để trống nếu muốn giữ ảnh cũ."
          : "PNG, JPG hoặc WEBP. Tối đa 8MB."
      )
      .setFileUploadComponent(
        new FileUploadBuilder()
          .setCustomId("photo")
          // ⚠ minValues PHAI khop required: Discord tu choi mot component
          // required ma minValues = 0 (COMPONENT_REQUIRED_ZERO_MIN_VALUES).
          // Tao moi -> bat buoc 1 anh; sua -> co the bo trong de giu anh cu.
          .setMinValues(photoRequired ? 1 : 0)
          .setMaxValues(1)
          .setRequired(photoRequired)
      )
  );

  return m;
}

const promptOptions = (selectedKey?: string) =>
  PROMPTS.map((p) =>
    new StringSelectMenuOptionBuilder()
      .setLabel(p.text.length > 100 ? p.text.slice(0, 97) + "..." : p.text)
      .setValue(p.key)
      .setDefault(p.key === selectedKey)
  );

export function promptsModal(existing?: FullProfile | null): ModalBuilder {
  const answers = [...(existing?.prompts ?? [])].sort((a, b) => a.position - b.position);

  const m = new ModalBuilder()
    .setCustomId(ID.profileModal("prompts"))
    .setTitle("Câu trả lời của bạn");

  for (let i = 0; i < REQUIRED_PROMPTS; i++) {
    const cur = answers[i];
    m.addLabelComponents(
      new LabelBuilder()
        .setLabel(`Câu hỏi ${i + 1}`)
        .setStringSelectMenuComponent(
          new StringSelectMenuBuilder()
            .setCustomId(`prompt${i}`)
            .setMinValues(1)
            .setMaxValues(1)
            .setPlaceholder("Chọn một câu hỏi")
            .addOptions(promptOptions(cur?.promptKey))
        ),
      new LabelBuilder().setLabel(`Trả lời ${i + 1}`).setTextInputComponent(
        textInput({
          id: `answer${i}`,
          style: TextInputStyle.Paragraph,
          min: 2,
          max: LIMITS.promptAnswerMaxLength,
          required: true,
          value: cur?.answer,
        })
      )
    );
  }

  m.addLabelComponents(
    new LabelBuilder()
      .setLabel("Giới thiệu ngắn")
      .setDescription("Không bắt buộc.")
      .setTextInputComponent(
        textInput({
          id: "bio",
          style: TextInputStyle.Paragraph,
          max: LIMITS.bioMaxLength,
          required: false,
          value: existing?.bio,
        })
      )
  );

  return m;
}

export function prefsModal(existing: FullProfile): ModalBuilder {
  return new ModalBuilder()
    .setCustomId(ID.profilePrefs())
    .setTitle("Bộ lọc tìm kiếm")
    .addLabelComponents(
      // Gioi tinh muon tim — truoc day chi dat duoc luc tao ho so. Dua vao
      // day de doi doi tuong tim ma khong phai lam lai ca ho so.
      new LabelBuilder()
        .setLabel("Bạn muốn tìm")
        .setDescription("Chọn được nhiều lựa chọn.")
        .setStringSelectMenuComponent(
          new StringSelectMenuBuilder()
            .setCustomId("seeking")
            .setMinValues(1)
            .setMaxValues(Object.values(Gender).length)
            .setPlaceholder("Chọn một hoặc nhiều")
            .addOptions(genderOptions(existing.seeking))
        ),
      new LabelBuilder()
        .setLabel("Tuổi tối thiểu")
        .setDescription("Không nhỏ hơn 18.")
        .setTextInputComponent(
          textInput({
            id: "min",
            style: TextInputStyle.Short,
            max: 2,
            required: true,
            value: String(existing.seekAgeMin),
          })
        ),
      new LabelBuilder().setLabel("Tuổi tối đa").setTextInputComponent(
        textInput({
          id: "max",
          style: TextInputStyle.Short,
          max: 2,
          required: true,
          value: String(existing.seekAgeMax),
        })
      )
    );
}

export function socialModal(platform: string, current?: string): ModalBuilder {
  const spec = socialSpec(platform);
  return new ModalBuilder()
    .setCustomId(ID.profileSocialsModal(platform))
    .setTitle(spec?.label ?? "Link")
    .addLabelComponents(
      new LabelBuilder()
        .setLabel(spec?.label ?? "Tài khoản")
        // Label description toi da 100 ky tu. hint cua Facebook dai nen phai
        // rut gon + cat cung — neu khong shapeshift nem CombinedPropertyError
        // luc toJSON (khong phai Discord tu choi, ma discord.js tu chan).
        .setDescription(clampDesc(`${spec?.hint ?? ""} · Để trống = gỡ link`))
        .setTextInputComponent(
          textInput({
            id: "value",
            style: TextInputStyle.Short,
            max: 200,
            required: false,
            value: current,
          })
        )
    );
}

export function superLikeNoteModal(targetId: string, name: string): ModalBuilder {
  return new ModalBuilder()
    .setCustomId(ID.superLikeNote(targetId))
    .setTitle("Super Like")
    .addLabelComponents(
      new LabelBuilder()
        .setLabel(`Nhắn gì đó cho ${name}`)
        .setDescription(
          `Tối đa ${LIMITS.superLikeNoteMaxLength} ký tự. Họ chỉ đọc được nếu match.`
        )
        .setTextInputComponent(
          new TextInputBuilder()
            .setCustomId("note")
            .setStyle(TextInputStyle.Paragraph)
            .setMaxLength(LIMITS.superLikeNoteMaxLength)
            .setRequired(false)
            .setPlaceholder("Không bắt buộc — để trống cũng được.")
        )
    );
}

export function reportModal(targetId: string, name: string): ModalBuilder {
  return new ModalBuilder()
    .setCustomId(ID.reportSubmit(targetId))
    .setTitle(`Báo cáo ${name}`.slice(0, 45))
    .addLabelComponents(
      new LabelBuilder()
        .setLabel("Lý do")
        .setStringSelectMenuComponent(
          new StringSelectMenuBuilder()
            .setCustomId("reason")
            .setMinValues(1)
            .setMaxValues(1)
            .setPlaceholder("Chọn lý do")
            .addOptions(
              REPORT_REASONS.map((r) =>
                new StringSelectMenuOptionBuilder().setLabel(r.label).setValue(r.key)
              )
            )
        ),
      new LabelBuilder()
        .setLabel("Chi tiết")
        .setDescription("Không bắt buộc, nhưng giúp mod xử lý nhanh hơn.")
        .setTextInputComponent(
          new TextInputBuilder()
            .setCustomId("details")
            .setStyle(TextInputStyle.Paragraph)
            .setMaxLength(500)
            .setRequired(false)
        )
    );
}
