import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ContainerBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  TextDisplayBuilder,
} from "discord.js";
import type { Profile, PromptAnswer, SocialLink } from "@prisma/client";
import { ID } from "../lib/ids.js";
import { getPrompt, MAX_PROMPTS } from "../features/prompts.js";
import { socialDisplay } from "../features/socials.js";
import { TAGS } from "../features/tags.js";
import {
  COLOR,
  GENDER_LABEL,
  GLYPH,
  PLATFORM_GLYPH,
  PLATFORM_LABEL,
  meta,
  sub,
  timeAgo,
} from "./theme.js";

function g(glyphs: Map<string, string> | undefined, key: keyof typeof GLYPH): string {
  return glyphs?.get(key) ?? GLYPH[key];
}

export function tagsList(p: FullProfile): string | null {
  if (!p.tags || p.tags.length === 0) return null;
  return p.tags
    .map((t) => {
      const spec = TAGS.find((tag) => tag.key === t);
      return spec ? `\`${spec.emoji} ${spec.label}\`` : `\`${t}\``;
    })
    .join("  ");
}

export type FullProfile = Profile & {
  prompts: PromptAnswer[];
  socials: SocialLink[];
};

const text = (s: string) => new TextDisplayBuilder().setContent(s);

const rule = () =>
  new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);

const gap = () =>
  new SeparatorBuilder().setDivider(false).setSpacing(SeparatorSpacingSize.Small);

// ─────────────────────────────────────────────────────────────────────────
// Cac manh dung chung
// ─────────────────────────────────────────────────────────────────────────

function header(p: FullProfile, opts: { showActivity: boolean }): TextDisplayBuilder[] {
  const out = [text(`### ${p.displayName}  ${GLYPH.dot}  ${p.age}`)];
  const line = meta(
    GENDER_LABEL[p.gender] ?? p.gender,
    opts.showActivity && `hoạt động ${timeAgo(p.lastActiveAt)}`
  );
  if (line) out.push(text(sub(line)));
  return out;
}

export function photo(p: FullProfile): MediaGalleryBuilder | null {
  if (!p.photoUrl) return null;
  return new MediaGalleryBuilder().addItems(
    new MediaGalleryItemBuilder().setURL(p.photoUrl).setDescription(`Ảnh của ${p.displayName}`)
  );
}

/// Prompt render thanh: tieu de dam + cau tra loi. Day la phan "thit" cua
/// profile — no la thu nguoi luot thuc su doc.
function promptBlocks(p: FullProfile): TextDisplayBuilder[] {
  return [...p.prompts]
    .sort((a, b) => a.position - b.position)
    .slice(0, MAX_PROMPTS)
    .map((pa) => {
      const q = getPrompt(pa.promptKey);
      // Prompt bi go khoi PROMPTS sau khi user da tra loi -> van hien cau
      // tra loi, chi bo tieu de. Khong lam vo card.
      return text(q ? `**${q.text}**\n${pa.answer}` : pa.answer);
    });
}

function interleave(blocks: TextDisplayBuilder[]): (TextDisplayBuilder | SeparatorBuilder)[] {
  const out: (TextDisplayBuilder | SeparatorBuilder)[] = [];
  blocks.forEach((b, i) => {
    if (i > 0) out.push(gap());
    out.push(b);
  });
  return out;
}

function push(c: ContainerBuilder, items: (TextDisplayBuilder | SeparatorBuilder)[]) {
  for (const it of items) {
    if (it instanceof SeparatorBuilder) c.addSeparatorComponents(it);
    else c.addTextDisplayComponents(it);
  }
}

// ─────────────────────────────────────────────────────────────────────────
// Card khi dang luot
// ─────────────────────────────────────────────────────────────────────────

export function swipeCard(
  p: FullProfile,
  ctx: {
    swipesLeft: number;
    superLikes: number;
    /// Khac null neu nguoi nay da Super Like minh -> banner noi bat + note.
    incomingSuperLike?: { note: string | null } | null;
    /// True neu MINH da Super Like nguoi nay -> disable nut super + ghi chu.
    youSuperLiked?: boolean;
    glyphs?: Map<string, string>;
  }
): ContainerBuilder {
  const incoming = ctx.incomingSuperLike ?? null;
  const youSuperLiked = ctx.youSuperLiked ?? false;
  const glyphs = ctx.glyphs;
  const c = new ContainerBuilder().setAccentColor(incoming ? COLOR.violet : COLOR.rose);

  // Banner Super Like len tren cung: nguoi luot biet ngay nguoi nay da Super
  // Like minh, va doc duoc loi nhan ho gui kem.
  if (incoming) {
    c.addTextDisplayComponents(
      text(`### ${g(glyphs, "superLike")} ${p.displayName} đã Super Like bạn`)
    );
    if (incoming.note) {
      c.addTextDisplayComponents(text(`> ${incoming.note.replace(/\n/g, "\n> ")}`));
    }
    c.addSeparatorComponents(rule());
  }

  for (const t of header(p, { showActivity: true })) c.addTextDisplayComponents(t);

  const tags = tagsList(p);
  if (tags) c.addTextDisplayComponents(text(tags));

  const img = photo(p);
  if (img) c.addMediaGalleryComponents(img);

  if (p.bio) {
    c.addTextDisplayComponents(text(`> ${p.bio.replace(/\n/g, "\n> ")}`));
  }

  const blocks = promptBlocks(p);
  if (blocks.length) {
    c.addSeparatorComponents(rule());
    push(c, interleave(blocks));
  }

  c.addSeparatorComponents(rule());

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(ID.swipe("like", p.userId))
      .setLabel("Thích")
      .setEmoji(g(glyphs, "like"))
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(ID.swipe("pass", p.userId))
      .setLabel("Bỏ qua")
      .setEmoji(g(glyphs, "pass"))
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(ID.swipe("super", p.userId))
      .setLabel("Super Like")
      .setEmoji(g(glyphs, "superLike"))
      .setStyle(ButtonStyle.Primary)
      // Da super like nguoi nay roi, hoac het so du -> disable. Super Like
      // la item boost: gui xong VAN Thich/Bo qua duoc (2 nut kia con mo).
      .setDisabled(youSuperLiked || ctx.superLikes <= 0),
    new ButtonBuilder()
      .setCustomId(ID.reportOpen(p.userId))
      .setLabel("Báo cáo")
      .setEmoji(g(glyphs, "report"))
      .setStyle(ButtonStyle.Secondary)
  );
  c.addActionRowComponents(row);

  c.addTextDisplayComponents(
    text(
      sub(
        meta(
          youSuperLiked ? `${g(glyphs, "superLike")} Đã Super Like — giờ Thích hoặc Bỏ qua` : null,
          `còn ${ctx.swipesLeft} lượt hôm nay`,
          ctx.superLikes > 0 ? `${ctx.superLikes} super like` : null
        )
      )
    )
  );

  return c;
}

// ─────────────────────────────────────────────────────────────────────────
// Card xem profile cua chinh minh
// ─────────────────────────────────────────────────────────────────────────

export function selfCard(p: FullProfile, missing: string[], glyphs?: Map<string, string>): ContainerBuilder {
  const ready = missing.length === 0;
  const c = new ContainerBuilder().setAccentColor(ready ? COLOR.rose : COLOR.slate);

  for (const t of header(p, { showActivity: false })) c.addTextDisplayComponents(t);

  const tags = tagsList(p);
  if (tags) c.addTextDisplayComponents(text(tags));

  const img = photo(p);
  if (img) c.addMediaGalleryComponents(img);

  if (p.bio) c.addTextDisplayComponents(text(`> ${p.bio.replace(/\n/g, "\n> ")}`));

  const blocks = promptBlocks(p);
  if (blocks.length) {
    c.addSeparatorComponents(rule());
    push(c, interleave(blocks));
  }

  if (p.socials.length) {
    c.addSeparatorComponents(rule());
    c.addTextDisplayComponents(
      text(
        p.socials
          .map((s) => `${PLATFORM_GLYPH[s.platform] ?? "🔗"} ${socialDisplay(s.platform, s.value)}`)
          .join("   ")
      )
    );
    c.addTextDisplayComponents(text(sub("Chỉ hiện với người đã match với bạn.")));
  }

  c.addSeparatorComponents(rule());

  if (!ready) {
    c.addTextDisplayComponents(
      text(`**Chưa xong**\n${missing.map((m) => `• ${m}`).join("\n")}`)
    );
    c.addTextDisplayComponents(
      text(sub("Profile chưa xuất hiện với ai cho đến khi hoàn tất."))
    );
    c.addSeparatorComponents(gap());
  }

  c.addActionRowComponents(
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(ID.profileModal("basics"))
        .setLabel("Sửa thông tin")
        .setEmoji(g(glyphs, "edit"))
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(ID.profileModal("prompts"))
        .setLabel("Sửa câu trả lời")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(ID.profilePrefs())
        .setLabel("Bộ lọc")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(ID.profileSocials())
        .setLabel("Link MXH")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(ID.profileTags())
        .setLabel("Sở thích")
        .setStyle(ButtonStyle.Secondary)
    )
  );

  return c;
}

// ─────────────────────────────────────────────────────────────────────────
// Card sau khi match — day la luc socials duoc tiet lo
// ─────────────────────────────────────────────────────────────────────────

export function matchRevealCard(p: FullProfile, matchId: string, glyphs?: Map<string, string>): ContainerBuilder {
  const c = new ContainerBuilder().setAccentColor(COLOR.gold);

  for (const t of header(p, { showActivity: true })) c.addTextDisplayComponents(t);

  const tags = tagsList(p);
  if (tags) c.addTextDisplayComponents(text(tags));

  const img = photo(p);
  if (img) c.addMediaGalleryComponents(img);

  const blocks = promptBlocks(p);
  if (blocks.length) {
    c.addSeparatorComponents(rule());
    push(c, interleave(blocks));
  }

  c.addSeparatorComponents(rule());

  if (p.socials.length) {
    c.addTextDisplayComponents(
      text(
        `**${g(glyphs, "sparkle")} Link của ${p.displayName}**\n` +
        p.socials
          .map(
            (s) =>
              `${PLATFORM_GLYPH[s.platform] ?? "🔗"} ${PLATFORM_LABEL[s.platform]} — ` +
              socialDisplay(s.platform, s.value)
          )
          .join("\n")
      )
    );
  } else {
    c.addTextDisplayComponents(text(sub(`${p.displayName} chưa gắn link MXH nào.`)));
  }

  c.addSeparatorComponents(gap());
  c.addActionRowComponents(
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(ID.unmatchAsk(matchId))
        .setLabel("Hủy match")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(ID.reportOpen(p.userId))
        .setLabel("Báo cáo")
        .setEmoji(g(glyphs, "report"))
        .setStyle(ButtonStyle.Secondary)
    )
  );

  return c;
}

// ─────────────────────────────────────────────────────────────────────────
// Trang thai rong / thong bao — dung chung mot ngon ngu thi giac
// ─────────────────────────────────────────────────────────────────────────

export function notice(opts: {
  color?: number;
  title: string;
  body?: string;
  footer?: string;
  buttons?: ButtonBuilder[];
}): ContainerBuilder {
  const c = new ContainerBuilder().setAccentColor(opts.color ?? COLOR.slate);
  c.addTextDisplayComponents(text(`### ${opts.title}`));
  if (opts.body) c.addTextDisplayComponents(text(opts.body));
  if (opts.footer) c.addTextDisplayComponents(text(sub(opts.footer)));
  if (opts.buttons?.length) {
    c.addSeparatorComponents(gap());
    c.addActionRowComponents(
      new ActionRowBuilder<ButtonBuilder>().addComponents(...opts.buttons)
    );
  }
  return c;
}

export function destinyCard(
  p: FullProfile,
  sharedTags: string[]
): ContainerBuilder {
  const c = new ContainerBuilder().setAccentColor(COLOR.gold);

  // Tarot-themed header
  c.addTextDisplayComponents(
    text(`### ✨ QUẺ BÓI DUYÊN PHẬN HÀNG NGÀY ✨`)
  );

  let prediction = "";
  if (sharedTags.length === 0) {
    prediction = "🌌 *\"Đi tìm nét đối lập. Sự khác biệt cá tính giữa hai bạn chính là miếng ghép hoàn hảo để bù trừ cho nhau.\"*";
  } else if (sharedTags.length <= 2) {
    prediction = `🌱 *\"Nhịp đập chung nho nhỏ. Hai bạn chia sẻ sở thích chung là **${sharedTags.join(", ")}**. Một buổi cafe trò chuyện nhẹ nhàng sẽ khởi đầu duyên nợ!\"*`;
  } else {
    prediction = `🔥 *\"Định mệnh vẫy gọi! Hai bạn có sự tương hợp tuyệt vời với ${sharedTags.length} tags chung: **${sharedTags.join(", ")}**. Thích ngay kẻo bỏ lỡ cơ duyên tốt!\"*`;
  }

  c.addTextDisplayComponents(text(prediction));
  c.addSeparatorComponents(rule());

  for (const t of header(p, { showActivity: false })) c.addTextDisplayComponents(t);

  const tags = tagsList(p);
  if (tags) c.addTextDisplayComponents(text(tags));

  const img = photo(p);
  if (img) c.addMediaGalleryComponents(img);

  if (p.bio) {
    c.addTextDisplayComponents(text(`> ${p.bio.replace(/\n/g, "\n> ")}`));
  }

  const blocks = promptBlocks(p);
  if (blocks.length) {
    c.addSeparatorComponents(rule());
    push(c, interleave(blocks));
  }

  c.addSeparatorComponents(rule());

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(ID.destinyLike(p.userId))
      .setLabel("Thích Duyên Phận 💖")
      .setStyle(ButtonStyle.Success)
  );
  c.addActionRowComponents(row);

  return c;
}
