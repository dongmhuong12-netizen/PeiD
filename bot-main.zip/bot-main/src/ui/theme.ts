/// Ngon ngu thiet ke.
///
/// Nguyen tac:
///  1. Mau tram, khong neon. Bang mau dating 2025 (Hinge/Feeld) chu khong
///     phai blurple mac dinh cua Discord — blurple la thu lam bot trong "cu".
///  2. Chu it. Dung `-# subtext` cho moi thong tin phu -> chu nho, mau xam,
///     tao ra thu bac thi giac ma embed cu khong lam duoc.
///  3. Emoji la dau hieu chuc nang, khong phai trang tri. Moi nut toi da 1.
///  4. Separator thay cho dong `───` go tay.

export const COLOR = {
  /// Profile card. Hong dat, am, khong chua.
  rose: 0xe0576b,
  /// Khoanh khac match. Vang kim -> cam giac "phan thuong".
  gold: 0xe8a33d,
  /// Xac nhan, thanh cong.
  mint: 0x4ec9a0,
  /// Thong tin trung tinh, trang thai rong.
  slate: 0x8b95a5,
  /// Canh bao, report, unmatch.
  crimson: 0xd94040,
  /// Super like.
  violet: 0x8b7cf6,
} as const;

/// ⚠ Cac glyph dung trong ButtonBuilder.setEmoji() PHAI la emoji Unicode
/// that — Discord tu choi ky tu dingbat (loi COMPONENT_INVALID_EMOJI).
/// Cac dingbat kieu chu (✕ ✎ ⚑ ✦) TRONG GIONG emoji nhung khong phai, va
/// Discord bo ca message. Nhung glyph nao co the vao setEmoji (xem
/// scripts/selftest kiem tra) chi duoc lay tu bo emoji that duoi day.
///
/// Glyph chi dung trong text (dot) thi khong bi rang buoc nay.
export const GLYPH = {
  like: "💗",
  pass: "❌",
  superLike: "⭐",
  report: "🚩",
  chat: "💬",
  edit: "📝",
  photo: "🖼",
  sparkle: "✨",
  dot: "·",
} as const;

/// `-# ` la cu phap subtext cua Discord: chu nho, mau mo.
/// Day la cong cu chinh tao thu bac thi giac trong Components V2.
export const sub = (s: string) => `-# ${s}`;

/// Ngan cach cac muc metadata tren 1 dong: "Nữ · 23 · Hoạt động 2h trước"
export const meta = (...parts: (string | null | undefined | false)[]) =>
  parts.filter(Boolean).join(`  ${GLYPH.dot}  `);

/// Thoi gian tuong doi, tieng Viet. Discord co <t:unix:R> nhung no khong
/// dung duoc trong subtext mot cach on dinh o moi client, va ta muon
/// kiem soat do chinh xac ("2 giờ trước" du chinh xac hon "1 giờ 47 phút").
export function timeAgo(date: Date): string {
  const s = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));
  if (s < 120) return "vừa xong";
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} phút trước`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} giờ trước`;
  const d = Math.floor(h / 24);
  if (d === 1) return "hôm qua";
  if (d < 7) return `${d} ngày trước`;
  const w = Math.floor(d / 7);
  if (w < 5) return `${w} tuần trước`;
  return "lâu rồi";
}

export const GENDER_LABEL: Record<string, string> = {
  MALE: "Nam",
  FEMALE: "Nữ",
  NONBINARY: "Phi nhị nguyên",
  OTHER: "Khác",
};

export const PLATFORM_LABEL: Record<string, string> = {
  INSTAGRAM: "Instagram",
  FACEBOOK: "Facebook",
  TIKTOK: "TikTok",
  SPOTIFY: "Spotify",
  TWITTER: "X",
  OTHER: "Khác",
};

export const PLATFORM_GLYPH: Record<string, string> = {
  INSTAGRAM: "📷",
  FACEBOOK: "🌐",
  TIKTOK: "🎵",
  SPOTIFY: "🎧",
  TWITTER: "𝕏",
  OTHER: "🔗",
};
