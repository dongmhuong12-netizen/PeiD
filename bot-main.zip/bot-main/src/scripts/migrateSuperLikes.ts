/// Migration MOT LAN: chuyen Super Like tu Swipe (co) sang SuperLikeSent (moi).
///
///   DATABASE_URL=<url> npx tsx src/scripts/migrateSuperLikes.ts
///
/// Boi vi truoc day Super Like la mot huong swipe (SwipeAction.SUPER_LIKE) va
/// TINH LA mot cu thich. Gio no la item boost tach roi. De giu dung y nghia
/// cu, moi Swipe SUPER_LIKE duoc chuyen thanh:
///   - SuperLikeSent(from -> to, note)   — phan boost
///   - Swipe.action = LIKE                — phan quyet dinh (van la mot cu thich)
///
/// Idempotent: chay lai khong sao (SuperLikeSent unique -> bo qua; swipe da
/// LIKE -> khong con SUPER_LIKE de chuyen). An toan chay tren DB that.

import { SwipeAction } from "@prisma/client";
import { db } from "../db.js";
import { isUniqueViolation } from "../lib/pair.js";

async function main() {
  const legacy = await db.swipe.findMany({ where: { action: SwipeAction.SUPER_LIKE } });
  console.log(`Tim thay ${legacy.length} swipe SUPER_LIKE cu.`);

  let moved = 0;
  for (const s of legacy) {
    // 1. Tao SuperLikeSent (giu note). Trung thi bo qua.
    try {
      await db.superLikeSent.create({
        data: { guildId: s.guildId, fromUserId: s.fromUserId, toUserId: s.toUserId, note: s.note },
      });
    } catch (err) {
      if (!isUniqueViolation(err)) throw err;
    }
    // 2. Chuyen swipe thanh LIKE (van la mot cu thich).
    await db.swipe.update({ where: { id: s.id }, data: { action: SwipeAction.LIKE, note: null } });
    moved++;
  }

  console.log(`Da chuyen ${moved} swipe -> SuperLikeSent + LIKE.`);
  const remain = await db.swipe.count({ where: { action: SwipeAction.SUPER_LIKE } });
  console.log(remain === 0 ? "Sach — khong con swipe SUPER_LIKE." : `⚠ Con ${remain} swipe SUPER_LIKE.`);
  await db.$disconnect();
}

await main();
