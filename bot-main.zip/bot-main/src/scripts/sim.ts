/// Simulation harness — drive router.route() bang interaction GIA.
///
///   npm run sim   (can DB nhap giong dbtest — DATABASE_URL tro DB nhap)
///
/// selftest kiem PAYLOAD (hinh dang message). dbtest kiem HAM feature.
/// sim kiem LUONG: bam lenh/nut/modal that su chay qua router, gate, va cac
/// handler — bat loi dieu huong/logic ma hai cai kia bo sot.
///
/// Discord that duoc gia lap: interaction ghi lai moi reply/showModal/DM;
/// client gia bat cac lan gui vao kenh/thread/DM. XOA SACH DB truoc khi chay.

import { Gender, MatchStatus, ProfileStatus, SwipeAction } from "@prisma/client";
import { db } from "../db.js";
import { route } from "../interactions/router.js";
import { ID } from "../lib/ids.js";

let pass = 0;
let fail = 0;
function ok(name: string, cond: boolean, detail?: unknown) {
  if (cond) {
    pass++;
    console.log(`  \x1b[32m✓\x1b[0m ${name}`);
  } else {
    fail++;
    console.log(`  \x1b[31m✗ ${name}\x1b[0m`, detail ?? "");
  }
}
const group = (n: string) => console.log(`\n\x1b[1m${n}\x1b[0m`);

const G = "1490000000000000001";
const OWNER = "1490000000000000999";
const BOT = "1490000000000000000";
const VERIFIED_ROLE = "1490000000000000500";
const LOUNGE = "1490000000000000600";
const MOD = "1490000000000000700";
const uid = (n: number) => String(1490000000000001000n + BigInt(n));

// ─────────────────────────────────────────────────────────────────────────
// The gioi gia lap
// ─────────────────────────────────────────────────────────────────────────

interface Sent {
  kind: string;
  payload: any;
}

const dms = new Map<string, any[]>(); // userId -> DM payloads
const channelSends = new Map<string, any[]>(); // channelId/threadId -> payloads
const threadMembers = new Map<string, Set<string>>(); // threadId -> userIds
let threadSeq = 0;

function fakeUser(id: string) {
  return {
    id,
    username: `u${id.slice(-4)}`,
    displayName: `U${id.slice(-4)}`,
    bot: id === BOT,
    send: async (payload: any) => {
      const arr = dms.get(id) ?? [];
      arr.push(payload);
      dms.set(id, arr);
      return { id: "dm-msg" };
    },
  };
}

function fakeThread(name: string) {
  const id = `thread-${++threadSeq}`;
  threadMembers.set(id, new Set());
  return {
    id,
    name,
    archived: false,
    isThread: () => true,
    isTextBased: () => true,
    isSendable: () => true,
    members: {
      add: async (userId: string) => threadMembers.get(id)!.add(userId),
    },
    send: async (payload: any) => {
      const arr = channelSends.get(id) ?? [];
      arr.push(payload);
      channelSends.set(id, arr);
      return { id: "t-msg" };
    },
    setLocked: async () => {},
    setArchived: async () => {},
  };
}

function fakeChannel(id: string) {
  return {
    id,
    isTextBased: () => true,
    isSendable: () => true,
    send: async (payload: any) => {
      const arr = channelSends.get(id) ?? [];
      arr.push(payload);
      channelSends.set(id, arr);
      return { id: "c-msg" };
    },
    threads: {
      create: async (opts: { name: string }) => fakeThread(opts.name),
    },
  };
}

const fakeGuild = {
  id: G,
  name: "Test Server",
  ownerId: OWNER,
  get client() {
    return fakeClient;
  },
  roles: { everyone: { id: G } },
  members: { fetchMe: async () => ({ id: BOT }) },
};

const fakeClient: any = {
  user: { id: BOT, tag: "TestBot#0000" },
  users: { fetch: async (id: string) => fakeUser(id) },
  guilds: { fetch: async () => fakeGuild },
  channels: {
    fetch: async (id: string) => {
      if (id.startsWith("thread-")) return fakeThread("x"); // hiem khi can
      return fakeChannel(id);
    },
  },
  rest: { post: async () => ({ refreshed_urls: [] }) },
};

// ─────────────────────────────────────────────────────────────────────────
// Interaction gia
// ─────────────────────────────────────────────────────────────────────────

function baseOutbox() {
  const out: Sent[] = [];
  return { out, wrap: (kind: string) => async (payload: any) => void out.push({ kind, payload }) };
}

/// member.roles.cache.has — gate.ts doc kieu nay.
function fakeMember(userId: string, roles: string[]) {
  return { id: userId, roles: { cache: new Set(roles) } };
}

interface FakeOpts {
  user: string;
  roles?: string[]; // role user dang co (mac dinh: co verified role)
}

function commandInteraction(
  o: FakeOpts & {
    commandName: string;
    subcommand?: string;
    options?: Record<string, any>;
  }
) {
  const { out } = baseOutbox();
  const opt = o.options ?? {};
  const i: any = {
    _out: out,
    _kind: "command",
    isChatInputCommand: () => true,
    isButton: () => false,
    isModalSubmit: () => false,
    isStringSelectMenu: () => false,
    isRepliable: () => true,
    inGuild: () => true,
    guildId: G,
    guild: fakeGuild,
    client: fakeClient,
    user: fakeUser(o.user),
    member: fakeMember(o.user, o.roles ?? [VERIFIED_ROLE]),
    commandName: o.commandName,
    replied: false,
    deferred: false,
    options: {
      getSubcommand: () => o.subcommand,
      getUser: (n: string, req?: boolean) => {
        const v = opt[n];
        if (!v && req) throw new Error(`thieu option ${n}`);
        return v ? fakeUser(v) : null;
      },
      getInteger: (n: string, req?: boolean) => {
        const v = opt[n];
        if (v == null && req) throw new Error(`thieu option ${n}`);
        return v ?? null;
      },
      getString: (n: string, req?: boolean) => {
        const v = opt[n];
        if (v == null && req) throw new Error(`thieu option ${n}`);
        return v ?? null;
      },
      getBoolean: (n: string) => opt[n] ?? null,
      getRole: (n: string, req?: boolean) => {
        const v = opt[n];
        if (!v && req) throw new Error(`thieu option ${n}`);
        return v ? { id: v, name: `role-${v}` } : null;
      },
      getChannel: (n: string, req?: boolean) => {
        const v = opt[n];
        if (!v && req) throw new Error(`thieu option ${n}`);
        return v ? fakeChannel(v) : null;
      },
    },
    reply: async (p: any) => {
      i.replied = true;
      out.push({ kind: "reply", payload: p });
    },
    editReply: async (p: any) => out.push({ kind: "editReply", payload: p }),
    followUp: async (p: any) => out.push({ kind: "followUp", payload: p }),
    deferReply: async (p: any) => {
      i.deferred = true;
      out.push({ kind: "deferReply", payload: p });
    },
    showModal: async (m: any) => out.push({ kind: "showModal", payload: m.toJSON ? m.toJSON() : m }),
  };
  return i;
}

function buttonInteraction(o: FakeOpts & { customId: string; fromMessage?: boolean }) {
  const { out } = baseOutbox();
  const i: any = {
    _out: out,
    _kind: "button",
    isChatInputCommand: () => false,
    isButton: () => true,
    isModalSubmit: () => false,
    isStringSelectMenu: () => false,
    isRepliable: () => true,
    inGuild: () => true,
    guildId: G,
    guild: fakeGuild,
    client: fakeClient,
    user: fakeUser(o.user),
    member: fakeMember(o.user, o.roles ?? [VERIFIED_ROLE]),
    customId: o.customId,
    replied: false,
    deferred: false,
    reply: async (p: any) => {
      i.replied = true;
      out.push({ kind: "reply", payload: p });
    },
    update: async (p: any) => out.push({ kind: "update", payload: p }),
    editReply: async (p: any) => out.push({ kind: "editReply", payload: p }),
    followUp: async (p: any) => out.push({ kind: "followUp", payload: p }),
    deferReply: async (p: any) => {
      i.deferred = true;
      out.push({ kind: "deferReply", payload: p });
    },
    deferUpdate: async () => {
      i.deferred = true;
      out.push({ kind: "deferUpdate", payload: null });
    },
    showModal: async (m: any) => out.push({ kind: "showModal", payload: m.toJSON ? m.toJSON() : m }),
  };
  return i;
}

function modalInteraction(
  o: FakeOpts & {
    customId: string;
    text?: Record<string, string>;
    selects?: Record<string, string[]>;
    files?: Record<string, any>;
    fromMessage?: boolean;
  }
) {
  const { out } = baseOutbox();
  const i: any = {
    _out: out,
    _kind: "modal",
    isChatInputCommand: () => false,
    isButton: () => false,
    isModalSubmit: () => true,
    isStringSelectMenu: () => false,
    isRepliable: () => true,
    inGuild: () => true,
    guildId: G,
    guild: fakeGuild,
    client: fakeClient,
    user: fakeUser(o.user),
    member: fakeMember(o.user, o.roles ?? [VERIFIED_ROLE]),
    customId: o.customId,
    replied: false,
    deferred: false,
    isFromMessage: () => o.fromMessage ?? false,
    fields: {
      getTextInputValue: (id: string) => o.text?.[id] ?? "",
      getStringSelectValues: (id: string) => o.selects?.[id] ?? [],
      getUploadedFiles: (id: string) => {
        const f = o.files?.[id];
        return { first: () => f, size: f ? 1 : 0 };
      },
    },
    reply: async (p: any) => {
      i.replied = true;
      out.push({ kind: "reply", payload: p });
    },
    editReply: async (p: any) => out.push({ kind: "editReply", payload: p }),
    followUp: async (p: any) => out.push({ kind: "followUp", payload: p }),
    deferReply: async (p: any) => {
      i.deferred = true;
      out.push({ kind: "deferReply", payload: p });
    },
    deferUpdate: async () => {
      i.deferred = true;
      out.push({ kind: "deferUpdate", payload: null });
    },
    showModal: async (m: any) => out.push({ kind: "showModal", payload: m.toJSON ? m.toJSON() : m }),
  };
  return i;
}

// ─────────────────────────────────────────────────────────────────────────
// Tien ich doc output
// ─────────────────────────────────────────────────────────────────────────

/// Gom text tu tat ca component (title/body/footer) cua cac lan gui ra.
function textOf(out: Sent[]): string {
  const parts: string[] = [];
  const walk = (n: any) => {
    if (!n || typeof n !== "object") return;
    if (typeof n.content === "string") parts.push(n.content);
    for (const k of ["components", "items", "accessory", "component"]) {
      const v = n[k];
      if (Array.isArray(v)) v.forEach(walk);
      else if (v) walk(v);
    }
  };
  for (const s of out) {
    if (s.payload?.content) parts.push(s.payload.content);
    for (const c of s.payload?.components ?? []) walk(c.toJSON ? c.toJSON() : c);
  }
  return parts.join(" │ ");
}

const kinds = (out: Sent[]) => out.map((s) => s.kind);

// Fake attachment hop le cho validatePhoto.
const fakePhoto = {
  url: "https://cdn.discordapp.com/attachments/1/2/anh.png",
  contentType: "image/png",
  size: 200_000,
  width: 800,
  height: 800,
};

async function wipe() {
  await db.superLikeGrant.deleteMany({});
  await db.superLikeBalance.deleteMany({});
  await db.fatherGrant.deleteMany({});
  await db.cupidGrant.deleteMany({});
  await db.report.deleteMany({});
  await db.block.deleteMany({});
  await db.match.deleteMany({});
  await db.swipe.deleteMany({});
  await db.promptAnswer.deleteMany({});
  await db.socialLink.deleteMany({});
  await db.profile.deleteMany({});
  await db.guildConfig.deleteMany({});
  dms.clear();
  channelSends.clear();
  threadMembers.clear();
}

async function seedConfig() {
  await db.guildConfig.create({
    data: {
      guildId: G,
      enabled: true,
      verifiedRoleId: VERIFIED_ROLE,
      loungeChannelId: LOUNGE,
      modChannelId: MOD,
      dailySwipeLimit: 30,
    },
  });
}

/// Chay het onboarding qua router: /profile setup -> modal basics -> (nut) ->
/// modal prompts. Tra ve profile.
async function onboard(user: string, opts: { gender: Gender; seeking: Gender[]; age: number }) {
  // /profile setup -> showModal(basics)
  const c = commandInteraction({ user, commandName: "profile", subcommand: "setup" });
  await route(c);

  // submit modal basics
  const basics = modalInteraction({
    user,
    customId: ID.profileModal("basics"),
    text: { name: `Ten${user.slice(-3)}`, age: String(opts.age) },
    selects: { gender: [opts.gender], seeking: opts.seeking },
    files: { photo: fakePhoto },
  });
  await route(basics);

  // submit modal prompts
  const prompts = modalInteraction({
    user,
    customId: ID.profileModal("prompts"),
    text: { answer0: "Cau tra loi mot", answer1: "Cau tra loi hai", bio: "Xin chao" },
    selects: { prompt0: ["weekend"], prompt1: ["cook_worst"] },
  });
  await route(prompts);

  return { basics, prompts };
}

// ─────────────────────────────────────────────────────────────────────────
// LUONG
// ─────────────────────────────────────────────────────────────────────────

async function flowOnboarding() {
  group("Luong onboarding: /profile setup -> modal -> modal -> ACTIVE");
  await wipe();
  await seedConfig();

  const A = uid(1);
  const c = commandInteraction({ user: A, commandName: "profile", subcommand: "setup" });
  await route(c);
  ok("/profile setup -> mo modal basics", kinds(c._out).includes("showModal"));
  ok("modal do la basics", c._out[0]?.payload?.custom_id === ID.profileModal("basics"));

  const basics = modalInteraction({
    user: A,
    customId: ID.profileModal("basics"),
    text: { name: "Linh", age: "23" },
    selects: { gender: [Gender.FEMALE], seeking: [Gender.MALE] },
    files: { photo: fakePhoto },
  });
  await route(basics);
  const afterBasics = await db.profile.findUnique({ where: { guildId_userId: { guildId: G, userId: A } } });
  ok("sau basics: profile duoc tao", !!afterBasics, afterBasics?.id);
  ok("sau basics: luu dung ten/tuoi/gioi tinh", afterBasics?.displayName === "Linh" && afterBasics?.age === 23 && afterBasics?.gender === Gender.FEMALE);
  ok("sau basics: chua ACTIVE (chua tra loi prompt)", afterBasics?.status === ProfileStatus.DRAFT, afterBasics?.status);
  ok("sau basics: dan toi buoc tra loi cau hoi", /câu hỏi/i.test(textOf(basics._out)));

  const prompts = modalInteraction({
    user: A,
    customId: ID.profileModal("prompts"),
    text: { answer0: "Trung chien", answer1: "Ngu ca ngay", bio: "Thich meo" },
    selects: { prompt0: ["cook_worst"], prompt1: ["weekend"] },
  });
  await route(prompts);
  const done = await db.profile.findUnique({
    where: { guildId_userId: { guildId: G, userId: A } },
    include: { prompts: true },
  });
  ok("sau prompts: 2 cau tra loi luu vao DB", done?.prompts.length === 2, done?.prompts.length);
  ok("sau prompts: profile ACTIVE", done?.status === ProfileStatus.ACTIVE, done?.status);
  ok("sau prompts: bao san sang", /sẵn sàng/i.test(textOf(prompts._out)));
}

async function flowGate() {
  group("Luong chan cua (gate)");
  await wipe();
  await seedConfig();
  await onboard(uid(10), { gender: Gender.MALE, seeking: [Gender.FEMALE], age: 25 });

  // Nguoi khong co verified role -> bi tu choi.
  const noRole = commandInteraction({ user: uid(11), commandName: "explore", roles: [] });
  await route(noRole);
  ok("thieu verified role -> bi tu choi", /role/i.test(textOf(noRole._out)) && !kinds(noRole._out).includes("editReply"));

  // Server chua bat -> tu choi.
  await db.guildConfig.update({ where: { guildId: G }, data: { enabled: false } });
  const off = commandInteraction({ user: uid(10), commandName: "explore" });
  await route(off);
  ok("bot chua bat -> tu choi", /chưa được bật|chưa dùng/i.test(textOf(off._out)));
  await db.guildConfig.update({ where: { guildId: G }, data: { enabled: true } });
}

async function flowExploreAndMatch() {
  group("Luong explore -> like -> match -> opt-in -> thread");
  await wipe();
  await seedConfig();
  const A = uid(20), B = uid(21);
  await onboard(A, { gender: Gender.MALE, seeking: [Gender.FEMALE], age: 25 });
  await onboard(B, { gender: Gender.FEMALE, seeking: [Gender.MALE], age: 24 });

  // A /explore -> thay card cua B (displayName = "Ten" + 3 so cuoi uid).
  const ex = commandInteraction({ user: A, commandName: "explore" });
  await route(ex);
  ok("A explore -> defer roi editReply mot card", kinds(ex._out).includes("editReply"));
  ok("A explore -> card la ho so cua B", textOf(ex._out).includes("Ten021"), textOf(ex._out).slice(0, 60));

  // A bam Like B
  const likeA = buttonInteraction({ user: A, customId: ID.swipe("like", B) });
  await route(likeA);
  const sw = await db.swipe.findFirst({ where: { guildId: G, fromUserId: A, toUserId: B } });
  ok("A like B -> swipe LIKE duoc ghi", sw?.action === SwipeAction.LIKE, sw?.action);
  ok("A like B -> chua match (B chua like)", (await db.match.count()) === 0);

  // B bam Like A -> match
  const likeB = buttonInteraction({ user: B, customId: ID.swipe("like", A) });
  await route(likeB);
  const match = await db.match.findFirst({ where: { guildId: G } });
  ok("B like A -> tao 1 match", !!match && (await db.match.count()) === 1);
  ok("match o trang thai PENDING_OPT_IN", match?.status === MatchStatus.PENDING_OPT_IN, match?.status);
  ok("ca A va B nhan DM match", (dms.get(A)?.length ?? 0) > 0 && (dms.get(B)?.length ?? 0) > 0);
  ok("B thay bao Match", /match/i.test(textOf(likeB._out)));

  // Ca hai bam "Bat dau chat" -> thread
  const readyA = buttonInteraction({ user: A, customId: ID.matchReady(match!.id) });
  await route(readyA);
  ok("A bam ready -> cho B", (await db.match.findUnique({ where: { id: match!.id } }))?.status === MatchStatus.PENDING_OPT_IN);
  ok("A ready -> bao dang cho", /chờ|ghi nhận/i.test(textOf(readyA._out)));

  const readyB = buttonInteraction({ user: B, customId: ID.matchReady(match!.id) });
  await route(readyB);
  const active = await db.match.findUnique({ where: { id: match!.id } });
  ok("B bam ready -> match ACTIVE", active?.status === MatchStatus.ACTIVE, active?.status);
  ok("thread duoc tao va luu", !!active?.threadId, active?.threadId);
  ok("ca hai duoc them vao thread", (threadMembers.get(active!.threadId!)?.size ?? 0) === 2, threadMembers.get(active!.threadId!)?.size);
  ok("co tin nhan gui vao thread (card + loi chuc)", (channelSends.get(active!.threadId!)?.length ?? 0) >= 2);
}

async function flowSuperLike() {
  group("Luong super like: uu tien + banner + note + DM");
  await wipe();
  await seedConfig();
  const A = uid(30), B = uid(31), C = uid(32);
  await onboard(A, { gender: Gender.MALE, seeking: [Gender.FEMALE], age: 25 });
  await onboard(B, { gender: Gender.FEMALE, seeking: [Gender.MALE], age: 24 });
  await onboard(C, { gender: Gender.FEMALE, seeking: [Gender.MALE], age: 24 });
  await db.superLikeBalance.create({ data: { guildId: G, userId: A, amount: 2 } });

  // A bam super like B -> mo modal note
  const superBtn = buttonInteraction({ user: A, customId: ID.swipe("super", B) });
  await route(superBtn);
  ok("super like -> mo modal nhap note", kinds(superBtn._out).includes("showModal"));

  // A submit note
  const note = modalInteraction({
    user: A,
    customId: ID.superLikeNote(B),
    text: { note: "Yeu em" },
    fromMessage: true,
  });
  await route(note);
  const slSent = await db.superLikeSent.findFirst({ where: { guildId: G, fromUserId: A, toUserId: B } });
  ok("super like -> tao SuperLikeSent + note (KHONG phai swipe)", slSent?.note === "Yeu em", slSent);
  ok("super like -> KHONG ghi swipe (item boost, chua quyet dinh)", (await db.swipe.count({ where: { guildId: G, fromUserId: A } })) === 0);
  ok("so du super like tru 1 (2 -> 1)", (await db.superLikeBalance.findUnique({ where: { guildId_userId: { guildId: G, userId: A } } }))?.amount === 1);
  ok("B nhan DM bao bi super like", (dms.get(B)?.length ?? 0) > 0 && /super like/i.test(JSON.stringify(dms.get(B) ?? [])));
  ok("super like xong -> re-render lai card B (van luot tiep duoc)", note._out.some((s: Sent) => s.kind === "editReply"));

  // Super like xong A VAN thich B duoc -> tao swipe LIKE
  await route(buttonInteraction({ user: A, customId: ID.swipe("like", B) }));
  ok("super like xong VAN thich B duoc -> swipe LIKE", (await db.swipe.findFirst({ where: { guildId: G, fromUserId: A, toUserId: B } }))?.action === SwipeAction.LIKE);

  // B explore -> thay A dau hang, card co banner + note
  const exB = commandInteraction({ user: B, commandName: "explore" });
  await route(exB);
  const t = textOf(exB._out);
  ok("B explore -> card A co banner Super Like", /super like/i.test(t), t.slice(0, 80));
  ok("B explore -> card co note 'Yeu em'", /Yeu em/.test(t));

  // B thich lai A -> match (nho super like da lam A noi bat)
  await route(buttonInteraction({ user: B, customId: ID.swipe("like", A) }));
  ok("B thich lai -> match (super like -> like -> like)", (await db.match.count({ where: { guildId: G } })) === 1);
}

async function flowReport() {
  group("Luong report: khong tu khoa, chi bao mod");
  await wipe();
  await seedConfig();
  const A = uid(40), B = uid(41);
  await onboard(A, { gender: Gender.MALE, seeking: [Gender.FEMALE], age: 25 });
  await onboard(B, { gender: Gender.FEMALE, seeking: [Gender.MALE], age: 24 });

  // A bam nut report B -> mo modal
  const rBtn = buttonInteraction({ user: A, customId: ID.reportOpen(B) });
  await route(rBtn);
  ok("bam report -> mo modal report", kinds(rBtn._out).includes("showModal"));

  // A submit report
  const rModal = modalInteraction({
    user: A,
    customId: ID.reportSubmit(B),
    selects: { reason: ["spam"] },
    text: { details: "quang cao" },
  });
  await route(rModal);
  ok("report duoc ghi vao DB", (await db.report.count({ where: { guildId: G, reportedId: B } })) === 1);
  ok("ho so B KHONG bi khoa (van ACTIVE)", (await db.profile.findUnique({ where: { guildId_userId: { guildId: G, userId: B } } }))?.status === ProfileStatus.ACTIVE);
  ok("A bi block khoi B (auto-block phia nguoi report)", (await db.block.count({ where: { blockerId: A, blockedId: B } })) === 1);
  ok("mod channel nhan tin bao cao", (channelSends.get(MOD)?.length ?? 0) === 1);
  ok("bao cho A: khong tu khoa", /không tự|mod quyết|đã gửi báo cáo/i.test(textOf(rModal._out)));
}

async function flowAdminPerms() {
  group("Luong phan quyen admin");
  await wipe();
  await seedConfig();
  const cupid = uid(50), target = uid(51);
  await onboard(target, { gender: Gender.FEMALE, seeking: [Gender.MALE], age: 24 });

  // Nguoi thuong dung /cupid give -> bi tu choi
  const denied = commandInteraction({
    user: uid(52),
    commandName: "cupid",
    subcommand: "give",
    options: { user: target, amount: 3 },
  });
  await route(denied);
  ok("nguoi thuong /cupid give -> tu choi", /không.*quyền|đủ quyền/i.test(textOf(denied._out)));
  ok("nguoi thuong -> khong cap duoc super like", (await db.superLikeBalance.count()) === 0);

  // Owner /cupidform cap Cupid full
  const form = commandInteraction({ user: OWNER, commandName: "cupidform", options: { user: cupid } });
  await route(form);
  ok("owner cupidform -> tao Cupid full quyen", (await db.cupidGrant.count({ where: { guildId: G, userId: cupid } })) === 1);

  // Cupid gio /cupid give duoc
  const give = commandInteraction({
    user: cupid,
    commandName: "cupid",
    subcommand: "give",
    options: { user: target, amount: 3 },
  });
  await route(give);
  ok("Cupid /cupid give -> cap duoc super like", (await db.superLikeBalance.findUnique({ where: { guildId_userId: { guildId: G, userId: target } } }))?.amount === 3);

  // reset-swipes (Father-only) — owner
  await db.swipe.create({ data: { guildId: G, fromUserId: target, toUserId: uid(53), action: SwipeAction.PASS } });
  const reset = commandInteraction({ user: OWNER, commandName: "father", subcommand: "reset-swipes", options: { user: target } });
  await route(reset);
  ok("owner reset-swipes -> xoa swipe cua target", (await db.swipe.count({ where: { guildId: G, fromUserId: target } })) === 0);

  // Cupid KHONG duoc dung /father
  const cupidFather = commandInteraction({ user: cupid, commandName: "father", subcommand: "reset-swipes", options: { user: target } });
  await route(cupidFather);
  ok("Cupid dung /father -> bi tu choi", /Father/i.test(textOf(cupidFather._out)));
}

async function flowEdgeCases() {
  group("Luong bien: pause, super het so du, report trung, pool rong");
  await wipe();
  await seedConfig();
  const A = uid(70), B = uid(71);
  await onboard(A, { gender: Gender.MALE, seeking: [Gender.FEMALE], age: 25 });
  await onboard(B, { gender: Gender.FEMALE, seeking: [Gender.MALE], age: 24 });

  // Pause -> explore bi chan
  await route(commandInteraction({ user: A, commandName: "profile", subcommand: "pause" }));
  ok("pause -> profile PAUSED", (await db.profile.findUnique({ where: { guildId_userId: { guildId: G, userId: A } } }))?.status === ProfileStatus.PAUSED);
  const exPaused = commandInteraction({ user: A, commandName: "explore" });
  await route(exPaused);
  ok("dang pause -> explore bi chan (khong hien card)", /ẩn|resume/i.test(textOf(exPaused._out)));
  await route(commandInteraction({ user: A, commandName: "profile", subcommand: "resume" }));
  ok("resume -> ACTIVE lai", (await db.profile.findUnique({ where: { guildId_userId: { guildId: G, userId: A } } }))?.status === ProfileStatus.ACTIVE);

  // Super like khi het so du (0) -> bao het, KHONG crash, khong ghi swipe
  const superBroke = buttonInteraction({ user: A, customId: ID.swipe("super", B) });
  await route(superBroke);
  ok("super like het so du -> bao het (khong crash)", /hết super like/i.test(textOf(superBroke._out)));
  ok("super like het so du -> KHONG ghi swipe", (await db.swipe.count({ where: { guildId: G, fromUserId: A } })) === 0);

  // Report B roi report lai -> already_reported
  await route(modalInteraction({ user: A, customId: ID.reportSubmit(B), selects: { reason: ["spam"] } }));
  const dupR = modalInteraction({ user: A, customId: ID.reportSubmit(B), selects: { reason: ["spam"] } });
  await route(dupR);
  ok("report trung nguoi -> bao da bao roi", /đã báo cáo người này rồi/i.test(textOf(dupR._out)));
  ok("report trung -> van chi 1 report", (await db.report.count({ where: { guildId: G, reporterId: A, reportedId: B } })) === 1);

  // Pool rong: A da report+block B nen B ra khoi pool -> explore het ho so
  const exEmpty = commandInteraction({ user: A, commandName: "explore" });
  await route(exEmpty);
  ok("het nguoi hop le -> bao het ho so (khong crash)", /hết hồ sơ|hết lượt|nới bộ lọc/i.test(textOf(exEmpty._out)));
}

async function flowUnmatch() {
  group("Luong unmatch: trong thread -> khoa + bao doi phuong");
  await wipe();
  await seedConfig();
  const A = uid(80), B = uid(81);
  await onboard(A, { gender: Gender.MALE, seeking: [Gender.FEMALE], age: 25 });
  await onboard(B, { gender: Gender.FEMALE, seeking: [Gender.MALE], age: 24 });
  await route(buttonInteraction({ user: A, customId: ID.swipe("like", B) }));
  await route(buttonInteraction({ user: B, customId: ID.swipe("like", A) }));
  const match = (await db.match.findFirst({ where: { guildId: G } }))!;
  await route(buttonInteraction({ user: A, customId: ID.matchReady(match.id) }));
  await route(buttonInteraction({ user: B, customId: ID.matchReady(match.id) }));

  // A bam Huy match -> confirm -> unmatch
  const ask = buttonInteraction({ user: A, customId: ID.unmatchAsk(match.id) });
  await route(ask);
  ok("bam huy match -> hoi xac nhan", /huỷ match|không thể hoàn tác/i.test(textOf(ask._out)));

  const dmBefore = dms.get(B)?.length ?? 0;
  const doIt = buttonInteraction({ user: A, customId: ID.unmatchDo(match.id) });
  await route(doIt);
  const after = await db.match.findUnique({ where: { id: match.id } });
  ok("xac nhan huy -> match UNMATCHED", after?.status === MatchStatus.UNMATCHED, after?.status);
  ok("unmatch -> B nhan DM bao", (dms.get(B)?.length ?? 0) > dmBefore);
  // Sau unmatch, A va B da co swipe nen khong thay lai nhau (vinh vien).
  const exA = commandInteraction({ user: A, commandName: "explore" });
  await route(exA);
  ok("sau unmatch -> A khong thay lai B", !textOf(exA._out).includes("Ten081"));
}

async function flowMatchesFallback() {
  group("Luong /matches (duong lui khi tat DM)");
  await wipe();
  await seedConfig();
  const A = uid(60), B = uid(61);
  await onboard(A, { gender: Gender.MALE, seeking: [Gender.FEMALE], age: 25 });
  await onboard(B, { gender: Gender.FEMALE, seeking: [Gender.MALE], age: 24 });
  await route(buttonInteraction({ user: A, customId: ID.swipe("like", B) }));
  await route(buttonInteraction({ user: B, customId: ID.swipe("like", A) }));

  const m = commandInteraction({ user: A, commandName: "matches" });
  await route(m);
  ok("/matches -> hien match dang cho", /chờ|bắt đầu chat/i.test(textOf(m._out)) || kinds(m._out).includes("editReply"));
}

// ─────────────────────────────────────────────────────────────────────────
async function main() {
  console.log("\n\x1b[1mSimulation — drive router bang interaction gia\x1b[0m");
  try {
    await db.$queryRaw`SELECT 1`;
  } catch {
    console.error("\n\x1b[31m  Khong ket noi duoc DB. Chi tro DATABASE_URL vao DB NHAP.\x1b[0m\n");
    process.exit(1);
  }

  await flowOnboarding();
  await flowGate();
  await flowExploreAndMatch();
  await flowSuperLike();
  await flowReport();
  await flowAdminPerms();
  await flowEdgeCases();
  await flowUnmatch();
  await flowMatchesFallback();

  await wipe();
  await db.$disconnect();

  console.log(`\n${"─".repeat(56)}`);
  if (fail === 0) console.log(`\x1b[32m  ${pass} buoc luong deu qua.\x1b[0m\n`);
  else {
    console.log(`\x1b[31m  ${fail} loi\x1b[0m / ${pass + fail} buoc\n`);
    process.exit(1);
  }
}

await main();
