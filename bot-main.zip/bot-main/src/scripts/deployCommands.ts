import { REST, Routes } from "discord.js";
import { config } from "../config.js";
import { commandJSON } from "../commands/definitions.js";
import { logger } from "../lib/logger.js";

const log = logger("deploy");

const rest = new REST().setToken(config.discord.token);

// DEV_GUILD_ID co dien -> deploy vao 1 server, hien ra ngay.
// De trong -> deploy global, Discord mat toi 1 gio de lan toa.
const route = config.discord.devGuildId
  ? Routes.applicationGuildCommands(config.discord.clientId, config.discord.devGuildId)
  : Routes.applicationCommands(config.discord.clientId);

try {
  const res = (await rest.put(route, { body: commandJSON })) as unknown[];
  log.info(
    `da dang ky ${res.length} lenh ` +
      (config.discord.devGuildId
        ? `vao server ${config.discord.devGuildId} (hien ra ngay)`
        : "toan cuc (cho toi 1 gio de lan toa)")
  );
  for (const c of commandJSON) log.info(`  /${c.name}`);
} catch (err) {
  log.error("dang ky lenh that bai", err);
  process.exit(1);
}
