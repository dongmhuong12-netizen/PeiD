/// Kiem tra phan logic thuan + tinh hop le cua payload gui len Discord.
///
/// Khong can database, khong can token. Chay: npm run selftest
///
/// Muc dich: bat loi TRUOC khi Discord tu choi payload luc chay that.
/// Components V2 va modal-co-select la tinh nang moi — sai schema thi
/// Discord tra 400 va user chi thay "This interaction failed".

import {
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
} from "discord.js";
import { parseSocial, socialUrl, socialDisplay, socialSpecs } from "../features/socials.js";
import { expiresAt, isStale } from "../lib/cdnUrl.js";
import { ID, parseId } from "../lib/ids.js";
import { resolveSwipeLimit } from "../limits.js";
import { GLYPH, PLATFORM_LABEL, timeAgo, meta, sub } from "../ui/theme.js";
import { orderPair } from "../lib/pair.js";
import { basicsModal, promptsModal, reportModal, socialModal, superLikeNoteModal, prefsModal } from "../ui/modals.js";
import { swipeCard, selfCard, notice, matchRevealCard, type FullProfile } from "../ui/profileCard.js";
import { commandJSON } from "../commands/definitions.js";
import {
  ALL_PERMISSIONS,
  CUPID_REQUIRED,
  PERMISSION_HINT,
  PERMISSION_LABEL,
} from "../features/admin/cupidCommands.js";
import { Gender, ProfileStatus, SocialPlatform } from "@prisma/client";

let pass = 0;
let fail = 0;

function ok(name: string, cond: boolean, detail?: unknown) {
  if (cond) {
    pass++;
    console.log(`  \x1b[32m✓\x1b[0m ${name}`);
  } else {
    fail++;
    console.log(`  \x1b[31m✗ ${name}\x1b[0m`, detail ?? "");
  }
}

function group(name: string) {
  console.log(`\n\x1b[1m${name}\x1b[0m`);
}

// ─────────────────────────────────────────────────────────────────────────
group("Socials — chan link ra ngoai domain cho phep");

const evil = [
  "https://evil-instagram.com/victim",
  "https://instagram.com.evil.co/victim",
  "https://evil.com/instagram.com/x",
  "javascript:alert(1)",
  "https://instagram.com@evil.com/x",
];
for (const url of evil) {
  const r = parseSocial("INSTAGRAM", url);
  ok(`chan: ${url}`, r.ok === false, r);
}

const good: [string, string, string][] = [
  ["INSTAGRAM", "linh.ng", "linh.ng"],
  ["INSTAGRAM", "@linh.ng", "linh.ng"],
  ["INSTAGRAM", "instagram.com/linh.ng", "linh.ng"],
  ["INSTAGRAM", "https://www.instagram.com/linh.ng/?igshid=abc", "linh.ng"],
  ["TIKTOK", "https://tiktok.com/@linhcooks", "linhcooks"],
  ["TWITTER", "https://x.com/linhng", "linhng"],
  ["FACEBOOK", "https://m.facebook.com/linh.nguyen.9", "linh.nguyen.9"],
  ["SPOTIFY", "https://open.spotify.com/user/abc123", "abc123"],
];
for (const [plat, input, want] of good) {
  const r = parseSocial(plat, input);
  ok(`${plat}: "${input}" -> ${want}`, r.ok && r.handle === want, r);
}

ok(
  "URL dung lai luon tro ve domain hardcode",
  socialUrl("INSTAGRAM", "linh.ng") === "https://instagram.com/linh.ng"
);
ok("socialDisplay tao markdown link", socialDisplay("TWITTER", "a").includes("https://x.com/a"));

// ─────────────────────────────────────────────────────────────────────────
group("Photo — doc han cua URL Discord CDN");

const future = Math.floor((Date.now() + 86_400_000) / 1000).toString(16);
const past = Math.floor((Date.now() - 3600_000) / 1000).toString(16);
const soon = Math.floor((Date.now() + 600_000) / 1000).toString(16);

ok("doc duoc tham so ex", expiresAt(`https://cdn.discordapp.com/a.png?ex=${future}&is=x&hm=y`) !== null);
ok("URL con han -> khong stale", isStale(`https://cdn.discordapp.com/a.png?ex=${future}`) === false);
ok("URL het han -> stale", isStale(`https://cdn.discordapp.com/a.png?ex=${past}`) === true);
ok("URL sap het han (10 phut) -> stale", isStale(`https://cdn.discordapp.com/a.png?ex=${soon}`) === true);
ok("URL khong co ex -> khong stale", isStale("https://cdn.discordapp.com/a.png") === false);
ok("URL rac -> khong no", isStale("khong-phai-url") === false);

// ─────────────────────────────────────────────────────────────────────────
group("customId codec");

const roundtrips = [
  ID.swipe("like", "123456789012345678"),
  ID.swipe("super", "123456789012345678"),
  ID.matchReady("clxyz123456789abcdefghij"),
  ID.reportOpen("123456789012345678"),
  ID.profileModal("prompts"),
  ID.profileSocialsModal("INSTAGRAM"),
];
for (const id of roundtrips) {
  ok(`roundtrip "${id}" (${id.length}/100 ky tu)`, parseId(id) !== null && id.length <= 100);
}
ok("bo qua customId cua bot khac", parseId("someotherbot|foo") === null);
ok("bo qua action khong hop le", parseId("d|sw|hack|123") === null);
ok("swipe parse dung", JSON.stringify(parseId(ID.swipe("like", "999"))) === JSON.stringify({ kind: "swipe", action: "like", targetId: "999" }));

// ─────────────────────────────────────────────────────────────────────────
group("Tran swipe co gian theo pool");

ok("pool 0 -> toi thieu 5", resolveSwipeLimit(0, 15) === 5);
ok("pool 8 -> 5 (san toi thieu)", resolveSwipeLimit(8, 15) === 5);
ok("pool 40 -> 10", resolveSwipeLimit(40, 15) === 10);
ok("pool 200 -> 15 (tran cua admin)", resolveSwipeLimit(200, 15) === 15);
ok("pool 5000 -> 30 (tran cung)", resolveSwipeLimit(5000, 999) === 30);

// ─────────────────────────────────────────────────────────────────────────
group("Sap xep cap userId cho Match");

const a = orderPair("111", "999");
const b = orderPair("999", "111");
ok("hai chieu cho ra cung mot cap", a.userAId === b.userAId && a.userBId === b.userBId, [a, b]);
ok("userA < userB", a.userAId < a.userBId);

// ─────────────────────────────────────────────────────────────────────────
group("Theme");

ok("timeAgo vua xong", timeAgo(new Date()) === "vừa xong");
ok("timeAgo 3 gio", timeAgo(new Date(Date.now() - 3 * 3600_000)) === "3 giờ trước");
ok("timeAgo hom qua", timeAgo(new Date(Date.now() - 30 * 3600_000)) === "hôm qua");
ok("meta bo qua gia tri rong", meta("a", null, false, "b") === "a  ·  b");
ok("sub tao subtext", sub("x") === "-# x");

// ─────────────────────────────────────────────────────────────────────────
group("Payload Components V2 — kiem tra hinh dang JSON");

const fakeProfile: FullProfile = {
  id: "clfake000000000000000000",
  guildId: "1",
  userId: "123456789012345678",
  displayName: "Linh",
  age: 23,
  gender: Gender.FEMALE,
  bio: "Thích mèo, ghét cà rốt.",
  photoUrl: "https://cdn.discordapp.com/attachments/1/2/a.png?ex=" + future,
  seeking: [Gender.MALE],
  seekAgeMin: 20,
  seekAgeMax: 30,
  status: ProfileStatus.ACTIVE,
  tags: [],
  lastDestinyAt: null,
  lastActiveAt: new Date(Date.now() - 7200_000),
  timesShown: 3,
  consentAt: new Date(),
  createdAt: new Date(),
  updatedAt: new Date(),
  prompts: [
    { id: "p1", profileId: "x", promptKey: "cook_worst", answer: "Trứng chiên.", position: 0 },
    { id: "p2", profileId: "x", promptKey: "weekend", answer: "Ngủ.", position: 1 },
  ],
  socials: [
    { id: "s1", profileId: "x", platform: SocialPlatform.INSTAGRAM, value: "linh.ng" },
  ],
};

const CONTAINER = 17;
const TEXT_DISPLAY = 10;
const ACTION_ROW = 1;
const MEDIA_GALLERY = 12;
const SEPARATOR = 14;
const LABEL = 18;

function checkContainer(name: string, c: { toJSON(): any }) {
  let json: any;
  try {
    json = c.toJSON();
  } catch (e) {
    ok(`${name} build duoc`, false, (e as Error).message);
    return;
  }
  ok(`${name}: type = Container(17)`, json.type === CONTAINER, json.type);
  ok(`${name}: co component con`, Array.isArray(json.components) && json.components.length > 0);
  const types = new Set<number>(json.components.map((x: any) => x.type));
  const allowed = new Set([TEXT_DISPLAY, ACTION_ROW, MEDIA_GALLERY, SEPARATOR, 9, 13]);
  ok(
    `${name}: chi chua component hop le`,
    [...types].every((t) => allowed.has(t)),
    [...types]
  );
  // Container toi da 40 component.
  ok(`${name}: <= 40 component`, json.components.length <= 40, json.components.length);
  // Moi action row toi da 5 nut.
  for (const row of json.components.filter((x: any) => x.type === ACTION_ROW)) {
    ok(`${name}: action row <= 5 nut`, row.components.length <= 5, row.components.length);
  }
}

checkContainer("swipeCard", swipeCard(fakeProfile, { swipesLeft: 12, superLikes: 2 }));
checkContainer("swipeCard (het super like)", swipeCard(fakeProfile, { swipesLeft: 1, superLikes: 0 }));
checkContainer(
  "swipeCard (bi super like, co note)",
  swipeCard(fakeProfile, { swipesLeft: 5, superLikes: 1, incomingSuperLike: { note: "Chào bạn nhé!" } })
);
checkContainer(
  "swipeCard (bi super like, note rong)",
  swipeCard(fakeProfile, { swipesLeft: 5, superLikes: 1, incomingSuperLike: { note: null } })
);
checkContainer(
  "swipeCard (minh da super like nguoi nay)",
  swipeCard(fakeProfile, { swipesLeft: 5, superLikes: 1, youSuperLiked: true })
);
checkContainer("selfCard (hoan chinh)", selfCard(fakeProfile, []));
checkContainer("selfCard (thieu)", selfCard(fakeProfile, ["Chưa có ảnh"]));
checkContainer("matchRevealCard", matchRevealCard(fakeProfile, "clmatch0000000000000000"));
checkContainer("notice", notice({ title: "x", body: "y", footer: "z" }));

// Profile khong co anh — khong duoc no.
checkContainer("swipeCard (khong anh)", swipeCard({ ...fakeProfile, photoUrl: null }, { swipesLeft: 5, superLikes: 0 }));
// Profile co prompt da bi go khoi danh sach — khong duoc no.
checkContainer(
  "swipeCard (prompt da xoa)",
  swipeCard(
    { ...fakeProfile, prompts: [{ id: "p", profileId: "x", promptKey: "khong_ton_tai", answer: "abc", position: 0 }] },
    { swipesLeft: 5, superLikes: 0 }
  )
);

// ─────────────────────────────────────────────────────────────────────────
group("Payload message — trung custom_id & emoji (2 luat da lam hong bot)");

// Walk ca cay component cua MOT message, gom moi custom_id va moi emoji.
function collect(node: any, ids: string[], emojis: string[]) {
  if (!node || typeof node !== "object") return;
  if (typeof node.custom_id === "string") ids.push(node.custom_id);
  if (node.emoji && typeof node.emoji === "object" && node.emoji.name && !node.emoji.id) {
    emojis.push(node.emoji.name); // emoji custom (co id) thi luon hop le
  }
  for (const k of ["components", "items", "accessory"]) {
    const v = node[k];
    if (Array.isArray(v)) v.forEach((c) => collect(c, ids, emojis));
    else if (v) collect(v, ids, emojis);
  }
}

// Emoji Unicode phai co Emoji_Presentation (hoac VS16). Dingbat kieu chu
// (✕ ✎ ⚑ ✦) truot bai nay — dung cai Discord tu choi.
const validEmoji = (e: string) => /\p{Emoji_Presentation}/u.test(e) || e.includes("️");

// Quet SAU mot node: kiem moi gioi han cua discord.js/Discord tren tung
// loai component. Quet chu dong de khong phai doi tung loi runtime lo ra.
function deepCheck(name: string, node: any) {
  if (!node || typeof node !== "object") return;
  const t = node.type;

  if (t === 2 /* Button */) {
    if (typeof node.label === "string")
      ok(`${name}: button label "${node.label.slice(0, 16)}" <= 80`, node.label.length <= 80, node.label.length);
    if (typeof node.custom_id === "string")
      ok(`${name}: button custom_id <= 100`, node.custom_id.length <= 100, node.custom_id.length);
  }

  if (t >= 3 && t <= 8 /* cac loai Select */) {
    if (typeof node.placeholder === "string")
      ok(`${name}: select placeholder <= 150`, node.placeholder.length <= 150, node.placeholder.length);
    if (typeof node.custom_id === "string")
      ok(`${name}: select custom_id <= 100`, node.custom_id.length <= 100, node.custom_id.length);
    if (Array.isArray(node.options)) {
      ok(`${name}: select co 1..25 option`, node.options.length >= 1 && node.options.length <= 25, node.options.length);
      for (const o of node.options) {
        ok(`${name}: option label <= 100`, typeof o.label === "string" && o.label.length <= 100, o.label);
        ok(`${name}: option value <= 100`, typeof o.value === "string" && o.value.length <= 100, o.value);
        if (typeof o.description === "string")
          ok(`${name}: option description <= 100`, o.description.length <= 100, o.description.length);
      }
    }
  }

  if (t === 10 /* TextDisplay */ && typeof node.content === "string")
    ok(`${name}: text display <= 4000`, node.content.length <= 4000, node.content.length);

  for (const k of ["components", "items", "accessory", "component"]) {
    const v = node[k];
    if (Array.isArray(v)) v.forEach((c) => deepCheck(name, c));
    else if (v) deepCheck(name, v);
  }
}

// Kiem MOT message (mang cac component o cap cao nhat, dung nhu luc gui).
function validateMessage(name: string, components: { toJSON(): any }[]) {
  const ids: string[] = [];
  const emojis: string[] = [];
  for (const c of components) {
    const json = c.toJSON();
    collect(json, ids, emojis);
    deepCheck(name, json);
  }

  const seen = new Set<string>();
  const dup: string[] = [];
  for (const id of ids) {
    if (seen.has(id)) dup.push(id);
    seen.add(id);
  }
  ok(`${name}: khong trung custom_id (${ids.length} nut)`, dup.length === 0, dup);
  for (const e of emojis) ok(`${name}: emoji "${e}" hop le`, validEmoji(e), e);
}

// Truoc het: chung minh bo kiem KHONG phai no-op — mot message co 2 nut
// trung custom_id phai bi bat.
{
  const bad = notice({
    title: "x",
    buttons: [
      new ButtonBuilder().setCustomId("d|so").setLabel("A").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("d|so").setLabel("B").setStyle(ButtonStyle.Secondary),
    ],
  });
  const ids: string[] = [];
  collect(bad.toJSON(), ids, []);
  ok("bo kiem bat duoc trung custom_id (test chinh no)", new Set(ids).size < ids.length, ids);
  ok("bo kiem bat duoc dingbat (test chinh no)", !validEmoji("✎") && !validEmoji("✕"));
}

// Moi GLYPH dung trong setEmoji phai la emoji that.
for (const g of ["like", "pass", "superLike", "report", "chat", "edit", "sparkle"] as const) {
  ok(`GLYPH.${g} = "${GLYPH[g]}" la emoji hop le`, validEmoji(GLYPH[g]), GLYPH[g]);
}

// Tung card rieng le.
validateMessage("swipeCard", [swipeCard(fakeProfile, { swipesLeft: 5, superLikes: 2 })]);
validateMessage("swipeCard (bi super like)", [
  swipeCard(fakeProfile, { swipesLeft: 5, superLikes: 1, incomingSuperLike: { note: "hi" } }),
]);
validateMessage("selfCard (hoan chinh)", [selfCard(fakeProfile, [])]);
validateMessage("selfCard (thieu)", [selfCard(fakeProfile, ["Chưa có ảnh"])]);
validateMessage("matchRevealCard", [matchRevealCard(fakeProfile, "clm00000000000000000000")]);
validateMessage("needProfile", [
  notice({
    title: "x",
    buttons: [
      new ButtonBuilder().setCustomId(ID.profileSetup()).setLabel("Tạo hồ sơ").setEmoji(GLYPH.sparkle).setStyle(ButtonStyle.Success),
    ],
  }),
]);

// To hop NHIEU card trong 1 message — day la cho da dinh loi trung
// custom_id: reply sau khi submit modal basics = notice + selfCard.
// selfCard co san nut Link MXH (ID.profileSocials); notice KHONG duoc co
// them nut do nua.
validateMessage("reply-sau-basics (notice + selfCard)", [
  notice({ title: "Hồ sơ đã sẵn sàng", footer: "..." }),
  selfCard(fakeProfile, []),
]);

// Hai select menu dung inline trong router/admin (socialsPicker, cupidPicker)
// — dung lai dung phep bien doi du lieu de cung duoc quet gioi han option.
validateMessage("socialsPicker", [
  new StringSelectMenuBuilder()
    .setCustomId(ID.profileSocials())
    .setPlaceholder("Chọn nền tảng để thêm hoặc sửa")
    .addOptions(
      socialSpecs().map((s) =>
        new StringSelectMenuOptionBuilder()
          .setLabel(PLATFORM_LABEL[s.platform] ?? s.label)
          .setValue(s.platform)
          .setDescription(s.hint.slice(0, 100))
      )
    ),
]);
validateMessage("cupidPicker", [
  new StringSelectMenuBuilder()
    .setCustomId(ID.cupidPerms("123456789012345678"))
    .setPlaceholder("Chọn quyền")
    .setMinValues(0)
    .setMaxValues(ALL_PERMISSIONS.length)
    .addOptions(
      ALL_PERMISSIONS.map((p) =>
        new StringSelectMenuOptionBuilder()
          .setLabel(PERMISSION_LABEL[p])
          .setValue(p)
          .setDescription(PERMISSION_HINT[p].slice(0, 100))
      )
    ),
]);

// /matches — nhieu the pending cho cac match KHAC nhau, custom_id kem matchId
// nen phai khac nhau.
validateMessage("/matches (2 match pending)", [
  notice({
    title: "A đang chờ",
    buttons: [
      new ButtonBuilder().setCustomId(ID.matchReady("m1")).setLabel("Chat").setEmoji(GLYPH.chat).setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(ID.matchDecline("m1")).setLabel("Bỏ").setStyle(ButtonStyle.Secondary),
    ],
  }),
  notice({
    title: "B đang chờ",
    buttons: [
      new ButtonBuilder().setCustomId(ID.matchReady("m2")).setLabel("Chat").setEmoji(GLYPH.chat).setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(ID.matchDecline("m2")).setLabel("Bỏ").setStyle(ButtonStyle.Secondary),
    ],
  }),
]);

// ─────────────────────────────────────────────────────────────────────────
group("Payload Modal");

function checkModal(name: string, m: { toJSON(): any }, wantComponents: number) {
  let json: any;
  try {
    json = m.toJSON();
  } catch (e) {
    ok(`${name} build duoc`, false, (e as Error).message);
    return;
  }
  ok(`${name}: co custom_id`, typeof json.custom_id === "string" && json.custom_id.length <= 100);
  ok(`${name}: title <= 45 ky tu`, json.title.length <= 45, json.title.length);
  // Gioi han cung cua Discord: 5 component moi modal.
  ok(`${name}: ${json.components.length} component (<= 5)`, json.components.length <= 5);
  ok(`${name}: dung ${wantComponents} component`, json.components.length === wantComponents, json.components.length);
  ok(
    `${name}: moi component la Label(18) hoac ActionRow(1)`,
    json.components.every((c: any) => c.type === LABEL || c.type === ACTION_ROW),
    json.components.map((c: any) => c.type)
  );

  // Gioi han Label: label <= 45, description <= 100 (discord.js chan bang
  // shapeshift o toJSON -> CombinedPropertyError, khong phai loi tu Discord).
  for (const c of json.components ?? []) {
    if (c.type !== LABEL) continue;
    if (typeof c.label === "string") {
      ok(`${name}: label "${c.label.slice(0, 20)}…" <= 45`, c.label.length <= 45, c.label.length);
    }
    if (typeof c.description === "string") {
      ok(
        `${name}: description <= 100 ("${c.description.slice(0, 24)}…")`,
        c.description.length <= 100,
        c.description.length
      );
    }
  }

  // Quet sau ca modal: gioi han button/select/option ap dung o day nua
  // (vd select trong modal, option label/description).
  for (const c of json.components ?? []) deepCheck(name, c);

  // Hai luat noi dung cua Discord da tung lam /profile setup hong voi
  // DiscordAPIError[50035]. checkModal cu chi soat cau truc nen bo lot.
  const inner: any[] = [];
  for (const c of json.components ?? []) {
    if (c.component) inner.push(c.component); // Label -> component ben trong
    if (Array.isArray(c.components)) inner.push(...c.components); // ActionRow
  }
  for (const comp of inner) {
    // (1) value = "" bi tu choi (BASE_TYPE_MIN_LENGTH) khi o co minLength.
    // Gia tri mac dinh rong phai la KHONG co truong value, khong phai "".
    if ("value" in comp) {
      ok(
        `${name}: input #${comp.custom_id} khong co value rong`,
        typeof comp.value === "string" && comp.value.length > 0,
        JSON.stringify(comp.value)
      );
    }
    // (2) component required KHONG duoc co min_values = 0
    // (COMPONENT_REQUIRED_ZERO_MIN_VALUES).
    if (comp.required === true && "min_values" in comp) {
      ok(
        `${name}: #${comp.custom_id} required nhung min_values = ${comp.min_values} (phai >= 1)`,
        comp.min_values >= 1,
        comp.min_values
      );
    }
  }
}

checkModal("basicsModal (tao moi)", basicsModal(null), 5);
checkModal("basicsModal (sua)", basicsModal(fakeProfile), 5);
checkModal("promptsModal", promptsModal(fakeProfile), 5);
checkModal("prefsModal", prefsModal(fakeProfile), 3);
// MOI platform — khong chi INSTAGRAM. Facebook co hint dai da tung lam
// description Label vuot 100 -> CombinedPropertyError. Them ca truong hop
// da co link san (co value) va chua co.
for (const s of socialSpecs()) {
  checkModal(`socialModal(${s.platform})`, socialModal(s.platform), 1);
  checkModal(`socialModal(${s.platform}, co san)`, socialModal(s.platform, "test.handle"), 1);
}
checkModal("superLikeNoteModal", superLikeNoteModal("1", "Linh"), 1);
checkModal("reportModal", reportModal("1", "Linh"), 2);
// Ten dai phai bi cat de khong vuot gioi han title.
checkModal("reportModal (ten rat dai)", reportModal("1", "A".repeat(200)), 2);

// Modal tao moi PHAI bat buoc upload anh; modal sua thi khong.
const createJson: any = basicsModal(null).toJSON();
const editJson: any = basicsModal(fakeProfile).toJSON();
const findUpload = (j: any) =>
  j.components.find((c: any) => c.component?.custom_id === "photo")?.component;
ok("modal tao moi: anh bat buoc", findUpload(createJson)?.required === true, findUpload(createJson));
ok("modal sua: anh khong bat buoc", findUpload(editJson)?.required === false, findUpload(editJson));

// ─────────────────────────────────────────────────────────────────────────
group("Slash command");

for (const c of commandJSON) {
  ok(`/${c.name}: ten hop le`, /^[\w-]{1,32}$/.test(c.name));
  ok(`/${c.name}: co mo ta <= 100 ky tu`, !!c.description && c.description.length <= 100);
}

// ─────────────────────────────────────────────────────────────────────────
group("Phan quyen — anh xa subcommand -> quyen");

// MOI subcommand cua /cupid PHAI co trong bang REQUIRED. Thieu mot cai thi
// handleCupid tra ve som va lenh do... khong lam gi ca. Im lang, khong loi.
// Te hon nua: neu ai do sua handleCupid thanh "khong co trong bang thi cho
// qua", lenh do thanh AI CUNG CHAY DUOC. Bai nay chan ca hai kich ban.
const cupidCmd: any = commandJSON.find((c) => c.name === "cupid");
const cupidSubs: string[] = (cupidCmd?.options ?? []).map((o: any) => o.name);
ok(`/cupid co ${cupidSubs.length} subcommand`, cupidSubs.length > 0);
for (const s of cupidSubs) {
  ok(`/cupid ${s} -> co quyen tuong ung trong bang REQUIRED`, s in CUPID_REQUIRED, s);
}
for (const k of Object.keys(CUPID_REQUIRED)) {
  ok(`bang REQUIRED khong co khoa thua: ${k}`, cupidSubs.includes(k));
}
ok(
  "moi quyen trong REQUIRED deu la quyen that",
  Object.values(CUPID_REQUIRED).every((p) => (ALL_PERMISSIONS as string[]).includes(p))
);

// Moi quyen phai co nhan va mo ta — thieu thi select menu hien "undefined".
for (const p of ALL_PERMISSIONS) {
  ok(`quyen ${p}: co nhan`, !!PERMISSION_LABEL[p] && PERMISSION_LABEL[p].length <= 100);
  ok(`quyen ${p}: co mo ta`, !!PERMISSION_HINT[p]);
}

// /father khong co bang quyen: moi subcommand deu doi isFather. Bai nay chot
// rang khong ai lo them subcommand /father vao ma tuong no duoc bao ve boi
// mot bang nao do.
const fatherCmd: any = commandJSON.find((c) => c.name === "father");
ok(
  `/father co ${(fatherCmd?.options ?? []).length} subcommand, tat ca deu chi Father`,
  (fatherCmd?.options ?? []).length > 0
);

// /cupidform: lenh top-level rieng (Father-only), phai co option user.
const cupidForm: any = commandJSON.find((c) => c.name === "cupidform");
ok("/cupidform ton tai", !!cupidForm);
ok(
  "/cupidform co option 'user' bat buoc",
  (cupidForm?.options ?? []).some((o: any) => o.name === "user" && o.required)
);
// /cupidform KHONG duoc nam trong bang CUPID_REQUIRED — no la Father-only,
// khong phai lenh Cupid theo quyen. Neu ai do nham dua no vao bang, no se
// thanh lenh Cupid cap thap dung duoc -> tu nang quyen.
ok("/cupidform khong bi xep nham vao lenh Cupid", !("cupidform" in CUPID_REQUIRED));

// ─────────────────────────────────────────────────────────────────────────
console.log(`\n${"─".repeat(56)}`);
if (fail === 0) {
  console.log(`\x1b[32m  ${pass} kiem tra deu qua.\x1b[0m\n`);
} else {
  console.log(`\x1b[31m  ${fail} loi\x1b[0m / ${pass + fail} kiem tra\n`);
  process.exit(1);
}
