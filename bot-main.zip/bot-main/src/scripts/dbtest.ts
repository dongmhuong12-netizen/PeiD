/// Integration test — CAN Postgres that.
///
///   docker run --name dating-db -e POSTGRES_PASSWORD=dev -p 5432:5432 -d postgres:16
///   npm run db:push
///   npm run dbtest
///
/// Tap trung vao nhung thu KHONG the kiem chung bang logic thuan: hanh vi
/// dong thoi that su cua Postgres. Bai quan trong nhat la RACE CONDITION —
/// no dua vao ngu nghia isolation that cua Postgres, nen mock khong chung
/// minh duoc gi ca.
///
/// Test nay XOA SACH cac bang truoc khi chay. Dung tro vao DB that.

import {
  CupidPermission,
  Gender,
  MatchStatus,
  ProfileStatus,
  ReportStatus,
  SwipeAction,
} from "@prisma/client";
import type { Guild } from "discord.js";
import { db } from "../db.js";
import { hasSuperLiked, recordSwipe, sendSuperLike } from "../features/swipe.js";
import { nextCandidate, countPool, getProfile } from "../features/discovery.js";
import { blockUser, fileReport, isBlocked } from "../features/safety.js";
import { LIMITS } from "../limits.js";
import { config } from "../config.js";
import {
  ALL_PERMISSIONS,
  authorityOf,
  demoteFather,
  listStaff,
  promoteFather,
  setCupidPermissions,
} from "../features/admin/permissions.js";
import {
  MAX_GRANT_PER_CALL,
  getBalance,
  giveSuperLikes,
  grantsByStaff,
} from "../features/admin/superlikes.js";
import {
  banProfile,
  resetUserSwipes,
  resolveReports,
  unbanProfile,
} from "../features/admin/moderation.js";

let pass = 0;
let fail = 0;

function ok(name: string, cond: boolean, detail?: unknown) {
  if (cond) {
    pass++;
    console.log(`  \x1b[32m✓\x1b[0m ${name}`);
  } else {
    fail++;
    console.log(`  \x1b[31m✗ ${name}\x1b[0m`, detail ?? "");
  }
}
const group = (n: string) => console.log(`\n\x1b[1m${n}\x1b[0m`);

const G = "999000000000000001";

async function wipe() {
  // Thu tu quan trong: xoa con truoc cha.
  await db.superLikeGrant.deleteMany({});
  await db.superLikeBalance.deleteMany({});
  await db.fatherGrant.deleteMany({});
  await db.cupidGrant.deleteMany({});
  await db.report.deleteMany({});
  await db.block.deleteMany({});
  await db.match.deleteMany({});
  await db.swipe.deleteMany({});
  await db.promptAnswer.deleteMany({});
  await db.socialLink.deleteMany({});
  await db.profile.deleteMany({});
  await db.guildConfig.deleteMany({});
}

async function mkProfile(opts: {
  userId: string;
  gender: Gender;
  seeking: Gender[];
  age?: number;
  seekAgeMin?: number;
  seekAgeMax?: number;
  status?: ProfileStatus;
}) {
  return db.profile.create({
    data: {
      guildId: G,
      userId: opts.userId,
      displayName: `U${opts.userId.slice(-2)}`,
      age: opts.age ?? 25,
      gender: opts.gender,
      seeking: opts.seeking,
      seekAgeMin: opts.seekAgeMin ?? 18,
      seekAgeMax: opts.seekAgeMax ?? 99,
      photoUrl: "https://cdn.discordapp.com/x.png",
      status: opts.status ?? ProfileStatus.ACTIVE,
      consentAt: new Date(),
      prompts: {
        create: [
          { promptKey: "weekend", answer: "a", position: 0 },
          { promptKey: "cook_worst", answer: "b", position: 1 },
        ],
      },
    },
    include: { prompts: true, socials: true },
  });
}

const uid = (n: number) => String(900000000000000000n + BigInt(n));

// ─────────────────────────────────────────────────────────────────────────
async function testRaceCondition() {
  group("RACE CONDITION — hai nguoi like nhau dung cung luc");
  console.log(
    "\x1b[90m  Day la bai quan trong nhat trong ca bo test. Neu logic sai,\n" +
      "  hai nguoi like nhau se KHONG match va khong ai biet tai sao.\x1b[0m"
  );

  // Mac dinh 50. Chay tren DB tu xa (proxy Railway) thi dat RACE_ROUNDS thap
  // hon vi do tre mang lam moi vong cham. Van du de bat loi race neu co.
  const ROUNDS = Number(process.env.RACE_ROUNDS) || 50;
  let noMatch = 0;
  let dupMatch = 0;
  let neitherReported = 0;

  for (let r = 0; r < ROUNDS; r++) {
    await wipe();
    const A = uid(r * 2 + 1);
    const B = uid(r * 2 + 2);
    await mkProfile({ userId: A, gender: Gender.MALE, seeking: [Gender.FEMALE] });
    await mkProfile({ userId: B, gender: Gender.FEMALE, seeking: [Gender.MALE] });

    // Dong thoi that su: Prisma cap 2 ket noi khac nhau tu pool.
    const [ra, rb] = await Promise.all([
      recordSwipe({ guildId: G, fromUserId: A, toUserId: B, action: SwipeAction.LIKE }),
      recordSwipe({ guildId: G, fromUserId: B, toUserId: A, action: SwipeAction.LIKE }),
    ]);

    const matches = await db.match.count({ where: { guildId: G } });
    if (matches === 0) noMatch++;
    if (matches > 1) dupMatch++;
    if (ra.kind !== "matched" && rb.kind !== "matched") neitherReported++;
  }

  ok(`${ROUNDS} vong dong thoi: luon tao dung 1 match (0 lan mat match)`, noMatch === 0, `mat ${noMatch} lan`);
  ok(`${ROUNDS} vong dong thoi: khong bao gio tao match trung`, dupMatch === 0, `trung ${dupMatch} lan`);
  ok(`${ROUNDS} vong dong thoi: luon co it nhat 1 ben biet la da match`, neitherReported === 0, `${neitherReported} lan khong ben nao biet`);
}

// ─────────────────────────────────────────────────────────────────────────
async function testSwipeBasics() {
  group("Swipe — nen tang");
  await wipe();
  const A = uid(101), B = uid(102);
  await mkProfile({ userId: A, gender: Gender.MALE, seeking: [Gender.FEMALE] });
  await mkProfile({ userId: B, gender: Gender.FEMALE, seeking: [Gender.MALE] });

  const r1 = await recordSwipe({ guildId: G, fromUserId: A, toUserId: B, action: SwipeAction.LIKE });
  ok("like mot chieu -> chua match", r1.kind === "recorded", r1);

  const r2 = await recordSwipe({ guildId: G, fromUserId: A, toUserId: B, action: SwipeAction.LIKE });
  ok("like lai lan 2 -> duplicate, khong tao them", r2.kind === "duplicate", r2);

  const r3 = await recordSwipe({ guildId: G, fromUserId: B, toUserId: A, action: SwipeAction.LIKE });
  ok("like nguoc lai -> match", r3.kind === "matched", r3);
  ok("chi co dung 1 match", (await db.match.count({ where: { guildId: G } })) === 1);

  // PASS khong duoc tao match du ben kia da like.
  await wipe();
  await mkProfile({ userId: A, gender: Gender.MALE, seeking: [Gender.FEMALE] });
  await mkProfile({ userId: B, gender: Gender.FEMALE, seeking: [Gender.MALE] });
  await recordSwipe({ guildId: G, fromUserId: A, toUserId: B, action: SwipeAction.LIKE });
  const r4 = await recordSwipe({ guildId: G, fromUserId: B, toUserId: A, action: SwipeAction.PASS });
  ok("like + pass -> khong match", r4.kind === "recorded" && (await db.match.count()) === 0, r4);

  // Match luon luu theo thu tu chuan.
  await wipe();
  await mkProfile({ userId: A, gender: Gender.MALE, seeking: [Gender.FEMALE] });
  await mkProfile({ userId: B, gender: Gender.FEMALE, seeking: [Gender.MALE] });
  await recordSwipe({ guildId: G, fromUserId: B, toUserId: A, action: SwipeAction.LIKE });
  await recordSwipe({ guildId: G, fromUserId: A, toUserId: B, action: SwipeAction.LIKE });
  const m = await db.match.findFirst({ where: { guildId: G } });
  ok("match luu userA < userB bat ke ai like truoc", !!m && m.userAId < m.userBId, m);
  ok("match bat dau o trang thai PENDING_OPT_IN", m?.status === MatchStatus.PENDING_OPT_IN);
}

// ─────────────────────────────────────────────────────────────────────────
async function testSuperLikeItem() {
  group("Super Like — item boost, tach khoi swipe");
  await wipe();
  const A = uid(201), B = uid(202), C = uid(203);
  await mkProfile({ userId: A, gender: Gender.MALE, seeking: [Gender.FEMALE] });
  await mkProfile({ userId: B, gender: Gender.FEMALE, seeking: [Gender.MALE] });
  await mkProfile({ userId: C, gender: Gender.FEMALE, seeking: [Gender.MALE] });

  await db.superLikeBalance.create({ data: { guildId: G, userId: A, amount: 1 } });

  // Bam that nhanh 2 super like cung luc voi so du = 1 -> chi 1 thanh cong.
  const [x, y] = await Promise.all([
    sendSuperLike({ guildId: G, fromUserId: A, toUserId: B, note: "hi" }),
    sendSuperLike({ guildId: G, fromUserId: A, toUserId: C, note: "hi" }),
  ]);
  const used = [x, y].filter((r) => r.kind === "sent").length;
  const bal = await db.superLikeBalance.findUnique({ where: { guildId_userId: { guildId: G, userId: A } } });
  ok("so du = 1, bam 2 lan dong thoi -> chi 1 lan 'sent'", used === 1, [x.kind, y.kind]);
  ok("so du ve 0, khong am", bal?.amount === 0, bal);

  // Super Like KHONG ghi swipe -> nguoi gui van thay/quyet dinh nguoi kia.
  ok("super like KHONG tao Swipe", (await db.swipe.count({ where: { guildId: G, fromUserId: A } })) === 0);
  ok("super like tao ban ghi SuperLikeSent", (await db.superLikeSent.count({ where: { guildId: G, fromUserId: A } })) === 1);

  // Super like trung nguoi -> hoan lai so du, khong tieu 2 lan.
  await db.superLikeBalance.update({ where: { guildId_userId: { guildId: G, userId: A } }, data: { amount: 5 } });
  const sent = await sendSuperLike({ guildId: G, fromUserId: A, toUserId: uid(299) });
  const before = (await db.superLikeBalance.findUnique({ where: { guildId_userId: { guildId: G, userId: A } } }))!.amount;
  const dup = await sendSuperLike({ guildId: G, fromUserId: A, toUserId: uid(299) });
  const after = (await db.superLikeBalance.findUnique({ where: { guildId_userId: { guildId: G, userId: A } } }))!.amount;
  ok("super like lan dau -> sent", sent.kind === "sent", sent);
  ok("super like trung nguoi -> already_sent + hoan so du", dup.kind === "already_sent" && before === after, { before, after, dup });

  // Sau super like B, A van LIKE B duoc (super like khong phai quyet dinh).
  const likeAfterSuper = await recordSwipe({ guildId: G, fromUserId: A, toUserId: B, action: SwipeAction.LIKE });
  ok("super like xong VAN thich duoc (recordSwipe LIKE ok)", likeAfterSuper.kind === "recorded", likeAfterSuper);
  ok("hasSuperLiked = true sau khi gui", await hasSuperLiked(G, A, B));
}

// ─────────────────────────────────────────────────────────────────────────
async function testDiscovery() {
  group("Discovery — loc ung vien");
  await wipe();

  const me = await mkProfile({
    userId: uid(301), gender: Gender.MALE, seeking: [Gender.FEMALE],
    age: 25, seekAgeMin: 22, seekAgeMax: 30,
  });

  // Hop moi dieu kien.
  await mkProfile({ userId: uid(302), gender: Gender.FEMALE, seeking: [Gender.MALE], age: 26, seekAgeMin: 20, seekAgeMax: 35 });
  // Sai gioi tinh minh tim.
  await mkProfile({ userId: uid(303), gender: Gender.MALE, seeking: [Gender.MALE], age: 26, seekAgeMin: 20, seekAgeMax: 35 });
  // Ngoai khoang tuoi minh tim.
  await mkProfile({ userId: uid(304), gender: Gender.FEMALE, seeking: [Gender.MALE], age: 40, seekAgeMin: 20, seekAgeMax: 50 });
  // Minh khong nam trong gu CUA HO -> loc 2 chieu phai loai.
  await mkProfile({ userId: uid(305), gender: Gender.FEMALE, seeking: [Gender.FEMALE], age: 26, seekAgeMin: 20, seekAgeMax: 35 });
  // Minh ngoai khoang tuoi CUA HO -> loc 2 chieu phai loai.
  await mkProfile({ userId: uid(306), gender: Gender.FEMALE, seeking: [Gender.MALE], age: 26, seekAgeMin: 30, seekAgeMax: 40 });
  // Chua hoan thanh profile.
  await mkProfile({ userId: uid(307), gender: Gender.FEMALE, seeking: [Gender.MALE], age: 26, status: ProfileStatus.DRAFT });
  // Dang bi mod xem xet.
  await mkProfile({ userId: uid(308), gender: Gender.FEMALE, seeking: [Gender.MALE], age: 26, status: ProfileStatus.UNDER_REVIEW });
  // Da tu an minh.
  await mkProfile({ userId: uid(309), gender: Gender.FEMALE, seeking: [Gender.MALE], age: 26, status: ProfileStatus.PAUSED });

  ok("chi con 1 ung vien hop le sau khi loc 2 chieu", (await countPool(me)) === 1, await countPool(me));
  const c = await nextCandidate(me);
  ok("ung vien do dung la nguoi hop moi dieu kien", c?.profile.userId === uid(302), c?.profile.userId);
  ok("chua ai super like -> superLikedYou = null", c?.superLikedYou === null);

  // Da swipe roi -> khong hien lai.
  await recordSwipe({ guildId: G, fromUserId: me.userId, toUserId: uid(302), action: SwipeAction.PASS });
  ok("da swipe -> bien khoi pool", (await countPool(me)) === 0);
  ok("het nguoi -> tra ve null (khong no)", (await nextCandidate(me)) === null);

  // Xoa profile roi tao lai KHONG duoc reset lich su swipe.
  await db.profile.delete({ where: { id: me.id } });
  const me2 = await mkProfile({
    userId: uid(301), gender: Gender.MALE, seeking: [Gender.FEMALE],
    age: 25, seekAgeMin: 22, seekAgeMax: 30,
  });
  ok("xoa profile roi tao lai KHONG reset duoc lich su swipe", (await countPool(me2)) === 0);

  // Super Like duoc uu tien len dau hang + kem note.
  await wipe();
  const viewer = await mkProfile({ userId: uid(320), gender: Gender.MALE, seeking: [Gender.FEMALE], age: 25 });
  // 3 ung vien nu hop gu. Mot nguoi (322) super like viewer.
  await mkProfile({ userId: uid(321), gender: Gender.FEMALE, seeking: [Gender.MALE], age: 24 });
  await mkProfile({ userId: uid(322), gender: Gender.FEMALE, seeking: [Gender.MALE], age: 24 });
  await mkProfile({ userId: uid(323), gender: Gender.FEMALE, seeking: [Gender.MALE], age: 24 });
  // Phai co so du moi super like duoc.
  await db.superLikeBalance.create({ data: { guildId: G, userId: uid(322), amount: 1 } });
  const sl = await sendSuperLike({ guildId: G, fromUserId: uid(322), toUserId: viewer.userId, note: "hi ban" });
  ok("super like duoc gui (co so du)", sl.kind === "sent", sl);

  const first = await nextCandidate(viewer);
  ok("nguoi super like minh duoc xep dau hang", first?.profile.userId === uid(322), first?.profile.userId);
  ok("card mang theo note super like", first?.superLikedYou?.note === "hi ban", first?.superLikedYou);
}

// ─────────────────────────────────────────────────────────────────────────
async function testBlock() {
  group("Block — hai chieu, toan cuc");
  await wipe();
  const A = uid(401), B = uid(402);
  const me = await mkProfile({ userId: A, gender: Gender.MALE, seeking: [Gender.FEMALE] });
  const them = await mkProfile({ userId: B, gender: Gender.FEMALE, seeking: [Gender.MALE] });

  ok("truoc khi block: thay nhau", (await countPool(me)) === 1);

  await blockUser(A, B);
  ok("A block B -> A khong thay B", (await countPool(me)) === 0);
  ok("A block B -> B CUNG khong thay A (loc 2 phia)", (await countPool(them)) === 0);

  await blockUser(A, B);
  ok("block lai lan 2 -> khong no", (await db.block.count()) === 1);

  await blockUser(A, A);
  ok("khong the tu block chinh minh", (await db.block.count()) === 1);
}

// ─────────────────────────────────────────────────────────────────────────
// Gia lap Guild vua du cho permissions.ts. Chi dung 3 truong: id, ownerId,
// client.user.id.
function fakeGuild(ownerId: string): Guild {
  return {
    id: G,
    ownerId,
    client: { user: { id: BOT } },
  } as unknown as Guild;
}

const OWNER = uid(601);
const BOT = uid(699);

async function testPermissions() {
  group("Phan quyen — Father / Cupid");
  await wipe();

  const guild = fakeGuild(OWNER);
  const f = uid(602);
  const c = uid(603);
  const nobody = uid(604);

  // ─── Neo tin cay ───
  const owner = await authorityOf(guild, OWNER);
  ok("chu server la Father ngam dinh, khong can dong nao trong DB", owner.isFather && owner.rank === "owner");
  ok("chu server co du moi quyen", owner.permissions.length === ALL_PERMISSIONS.length);
  ok("nguoi la khong co quyen gi", (await authorityOf(guild, nobody)).permissions.length === 0);

  // ─── Phong Father ───
  ok("phong Father thanh cong", (await promoteFather(guild, f, OWNER)).ok);
  const fa = await authorityOf(guild, f);
  ok("Father co du moi quyen", fa.isFather && fa.permissions.length === ALL_PERMISSIONS.length);
  ok("phong lai lan 2 -> tu choi", !(await promoteFather(guild, f, OWNER)).ok);
  ok("khong the phong chu server", !(await promoteFather(guild, OWNER, f)).ok);
  ok("khong the phong bot", !(await promoteFather(guild, BOT, OWNER)).ok);

  // ─── Cap quyen Cupid ───
  ok(
    "cap 2 quyen cho Cupid",
    (await setCupidPermissions(guild, c, [CupidPermission.GIVE_SUPERLIKE, CupidPermission.VIEW_STATS], OWNER)).ok
  );
  const ca = await authorityOf(guild, c);
  ok("Cupid co dung 2 quyen duoc cap", ca.rank === "cupid" && ca.permissions.length === 2, ca);
  ok("Cupid KHONG phai Father", !ca.isFather);
  ok("Cupid co quyen da cap", ca.permissions.includes(CupidPermission.GIVE_SUPERLIKE));
  ok("Cupid KHONG co quyen chua cap", !ca.permissions.includes(CupidPermission.MODERATE_PROFILE));

  // Day la bai quan trong nhat: gia tri la den tu select menu cua Discord,
  // tuc la tu client, tuc la khong duoc tin.
  await setCupidPermissions(guild, c, ["KHONG_TON_TAI", "GIVE_SUPERLIKE"] as never, OWNER);
  const filtered = await authorityOf(guild, c);
  ok(
    "quyen la bi loc bo, khong luu vao DB",
    filtered.permissions.length === 1 && filtered.permissions[0] === CupidPermission.GIVE_SUPERLIKE,
    filtered.permissions
  );

  ok("khong the cap quyen Cupid cho Father", !(await setCupidPermissions(guild, f, [CupidPermission.VIEW_STATS], OWNER)).ok);
  ok("khong the cap quyen Cupid cho chu server", !(await setCupidPermissions(guild, OWNER, [CupidPermission.VIEW_STATS], f)).ok);

  // ─── Thu hoi ───
  ok("danh sach rong = thu hoi", (await setCupidPermissions(guild, c, [], OWNER)).ok);
  ok("thu hoi roi thi khong con quyen gi", (await authorityOf(guild, c)).rank === "none");
  ok("thu hoi xoa han ban ghi, khong de lai Cupid rong", (await db.cupidGrant.count()) === 0);

  // ─── Len Father thi thoi lam Cupid ───
  await setCupidPermissions(guild, c, [CupidPermission.VIEW_STATS], OWNER);
  await promoteFather(guild, c, OWNER);
  ok("len Father -> ban ghi Cupid bi xoa, khong con trang thai roi", (await db.cupidGrant.count({ where: { userId: c } })) === 0);
  ok("len Father -> co du moi quyen", (await authorityOf(guild, c)).permissions.length === ALL_PERMISSIONS.length);

  // ─── Khoa chet ───
  ok("KHONG the go quyen chu server", !(await demoteFather(guild, OWNER, f)).ok);
  ok("KHONG the tu go quyen cua chinh minh", !(await demoteFather(guild, f, f)).ok);
  ok("Father khac go duoc", (await demoteFather(guild, f, OWNER)).ok);
  ok("go roi thi mat sach quyen", (await authorityOf(guild, f)).rank === "none");
  ok("go nguoi khong phai Father -> tu choi", !(await demoteFather(guild, nobody, OWNER)).ok);

  // ─── Dev toan cuc ───
  await testDevUser(guild);
}

async function testDevUser(guild: Guild) {
  const dev = config.devUserId;
  if (!dev) {
    ok("(bo qua test dev — DEV_USER_ID chua dat trong .env)", true);
    return;
  }

  await wipe();

  // Dev co toan quyen o server nay du KHONG phai chu, khong co dong nao trong DB.
  const auth = await authorityOf(guild, dev);
  ok("dev: rank = dev", auth.rank === "dev", auth);
  ok("dev: isFather + du moi quyen", auth.isFather && auth.permissions.length === ALL_PERMISSIONS.length);
  ok("dev: khong co dong nao trong FatherGrant", (await db.fatherGrant.count({ where: { userId: dev } })) === 0);

  // Dev co hieu luc o server KHAC ma khong can setup gi.
  const otherGuild = { id: "999000000000000009", ownerId: uid(650), client: { user: { id: BOT } } } as unknown as Guild;
  ok("dev: toan quyen o server bat ky", (await authorityOf(otherGuild, dev)).isFather);

  // Khong lot vao bang -> khong lo ID trong /father staff. Thong bao giong
  // het truong hop Father binh thuong, khong co gi dac biet.
  const p = await promoteFather(guild, dev, OWNER);
  ok("dev: promote bi tu choi, KHONG tao dong trong bang", !p.ok && (await db.fatherGrant.count({ where: { userId: dev } })) === 0);
  ok("dev: thong bao promote giong het Father da co (khong lo)", p.ok === false && /đã là Father/.test((p as { error: string }).error));

  const s = await setCupidPermissions(guild, dev, [CupidPermission.VIEW_STATS], OWNER);
  ok("dev: cap Cupid bi tu choi, KHONG tao dong trong bang", !s.ok && (await db.cupidGrant.count({ where: { userId: dev } })) === 0);

  // Neu vi ly do gi do co du lieu cu, listStaff phai loc dev ra.
  await db.fatherGrant.create({ data: { guildId: G, userId: dev, grantedBy: OWNER } });
  const staff = await listStaff(guild);
  ok("dev: bi loc khoi listStaff du co dong cu trong bang", !staff.fathers.some((f) => f.userId === dev));
  await db.fatherGrant.deleteMany({ where: { userId: dev } });
}

// ─────────────────────────────────────────────────────────────────────────
async function testSuperLikeGrants() {
  group("Cap Super Like — nhat ky va gioi han");
  await wipe();

  const admin = uid(701);
  const user = uid(702);

  const r1 = await giveSuperLikes({ guildId: G, byUserId: admin, toUserId: user, amount: 3, reason: "thi dua" });
  ok("cap 3 -> so du 3", r1.ok && r1.balance === 3, r1);
  ok("ghi nhat ky", (await db.superLikeGrant.count({ where: { guildId: G } })) === 1);

  const r2 = await giveSuperLikes({ guildId: G, byUserId: admin, toUserId: user, amount: 2 });
  ok("cap them 2 -> so du 5", r2.ok && r2.balance === 5, r2);

  // Thu hoi qua tay khong duoc phep lam so du am: so du am se lam nguoi ta
  // khong tieu duoc ke ca sau khi duoc cap lai, va khong ai hieu tai sao.
  // Dung -50 (tran duoi cua UI, setMinValue(-50)) chu khong phai -99: lenh
  // /cupid give chan cung amount trong [-50, 50] nen -99 khong bao gio toi
  // duoc code, va no se bi cap 50 tu choi truoc khi kip kep.
  const r3 = await giveSuperLikes({ guildId: G, byUserId: admin, toUserId: user, amount: -50 });
  ok("thu hoi 50 khi chi co 5 -> ve 0, KHONG am", r3.ok && r3.balance === 0, r3);
  ok("nhat ky ghi dung so thuc te bi tru (-5, khong phai -50)", r3.ok && r3.delta === -5, r3);

  ok("thu hoi khi da het -> tu choi", !(await giveSuperLikes({ guildId: G, byUserId: admin, toUserId: user, amount: -1 })).ok);
  ok("cap 0 -> tu choi", !(await giveSuperLikes({ guildId: G, byUserId: admin, toUserId: user, amount: 0 })).ok);
  ok(
    `cap qua ${MAX_GRANT_PER_CALL} -> tu choi (chan loi go nham so 0)`,
    !(await giveSuperLikes({ guildId: G, byUserId: admin, toUserId: user, amount: MAX_GRANT_PER_CALL + 1 })).ok
  );

  // So du theo guild, khong toan cuc.
  const G2 = "999000000000000002";
  await giveSuperLikes({ guildId: G2, byUserId: admin, toUserId: user, amount: 7 });
  ok("so du server A khong lan sang server B", (await getBalance(G, user)) === 0 && (await getBalance(G2, user)) === 7);
  await db.superLikeGrant.deleteMany({ where: { guildId: G2 } });
  await db.superLikeBalance.deleteMany({ where: { guildId: G2 } });

  const byStaff = await grantsByStaff(G, 30);
  ok("tong ket theo nguoi cap chi tinh luot cap, khong tinh thu hoi", byStaff[0]?._sum.amount === 5, byStaff);
}

// ─────────────────────────────────────────────────────────────────────────
async function testReportLifecycle() {
  group("Vong doi report — ho so bi to oan phai duoc go an");
  await wipe();

  const victim = uid(801);
  const mod = uid(899);
  await mkProfile({ userId: victim, gender: Gender.FEMALE, seeking: [Gender.MALE] });

  // Gia lap mod da an ho so (UNDER_REVIEW) — report KHONG con tu an nua, day
  // la trang thai chi mod moi dat. Test o day la nhanh dismiss-go-an.
  for (let n = 0; n < 3; n++) {
    await db.report.create({
      data: { guildId: G, reporterId: uid(810 + n), reportedId: victim, reason: "spam", status: ReportStatus.OPEN },
    });
  }
  await db.profile.updateMany({ where: { guildId: G, userId: victim }, data: { status: ProfileStatus.UNDER_REVIEW } });

  const hidden = await getProfile(G, victim);
  ok("ho so dang bi an -> khong con trong pool", hidden?.status === ProfileStatus.UNDER_REVIEW);

  // Mod ket luan khong co co so.
  const res = await resolveReports({ guildId: G, reportedId: victim, action: "dismiss", byUserId: mod });
  ok("dismiss thanh cong", res.ok, res);
  ok("moi report duoc dong", (await db.report.count({ where: { guildId: G, status: ReportStatus.OPEN } })) === 0);

  // Day la cai lo hong that o ban truoc: report bay vao kenh mod roi nam do
  // vinh vien, nghia la ho so bi to oan bi an MAI MAI.
  const restored = await getProfile(G, victim);
  ok("dismiss -> ho so hoat dong tro lai", restored?.status === ProfileStatus.ACTIVE, restored?.status);

  ok("khong con report mo -> resolve tu choi", !(await resolveReports({ guildId: G, reportedId: victim, action: "resolve", byUserId: mod })).ok);

  // Ban / unban.
  ok("ban thanh cong", (await banProfile({ guildId: G, userId: victim, byUserId: mod })).ok);
  ok("ban -> trang thai BANNED", (await getProfile(G, victim))?.status === ProfileStatus.BANNED);
  ok("ban lai lan 2 -> tu choi", !(await banProfile({ guildId: G, userId: victim, byUserId: mod })).ok);
  ok("unban -> hoat dong tro lai", (await unbanProfile({ guildId: G, userId: victim })).ok);
  ok("unban -> trang thai ACTIVE", (await getProfile(G, victim))?.status === ProfileStatus.ACTIVE);

  // Ho so thieu thong tin thi unban KHONG duoc bat thang len ACTIVE.
  await db.promptAnswer.deleteMany({ where: { profile: { userId: victim } } });
  await banProfile({ guildId: G, userId: victim, byUserId: mod });
  await unbanProfile({ guildId: G, userId: victim });
  ok(
    "unban ho so con thieu thong tin -> ve DRAFT chu khong phai ACTIVE",
    (await getProfile(G, victim))?.status === ProfileStatus.DRAFT
  );
}

// ─────────────────────────────────────────────────────────────────────────
async function testReportAntiGrief() {
  group("Report — khong tu khoa + gioi han tan suat (chong pha)");
  await wipe();

  // notifyMods can Client; guild test khong co config nen no return som,
  // client gia khong bao gio bi cham toi.
  const fakeClient = { channels: { fetch: async () => null } } as unknown as import("discord.js").Client;

  const victim = uid(850);
  await mkProfile({ userId: victim, gender: Gender.FEMALE, seeking: [Gender.MALE] });

  // 4 nguoi khac nhau report -> KHONG duoc tu khoa ho so.
  for (let n = 0; n < 4; n++) {
    const r = await fileReport(fakeClient, { guildId: G, reporterId: uid(860 + n), reportedId: victim, reasonKey: "spam" });
    ok(`report #${n + 1} duoc ghi`, r.kind === "filed", r);
  }
  ok("4 report van KHONG tu khoa ho so (giu ACTIVE)", (await getProfile(G, victim))?.status === ProfileStatus.ACTIVE);

  // "nghi duoi 18" cung KHONG con tu khoa (truoc day an ngay tu report dau).
  const rm = await fileReport(fakeClient, { guildId: G, reporterId: uid(870), reportedId: victim, reasonKey: "minor" });
  ok("report nghi <18 duoc ghi", rm.kind === "filed", rm);
  ok("report nghi <18 KHONG tu khoa ho so nua", (await getProfile(G, victim))?.status === ProfileStatus.ACTIVE);

  ok("report keo theo block phia nguoi report", await isBlocked(uid(860), victim));

  const dup = await fileReport(fakeClient, { guildId: G, reporterId: uid(860), reportedId: victim, reasonKey: "spam" });
  ok("report trung 1 nguoi -> already_reported", dup.kind === "already_reported", dup);

  // Gioi han tan suat: 1 nguoi report toi da N nguoi/ngay.
  await wipe();
  const spammer = uid(880);
  const N = LIMITS.reportsPerReporterPerDay;
  for (let n = 0; n < N; n++) {
    await mkProfile({ userId: uid(890 + n), gender: Gender.FEMALE, seeking: [Gender.MALE] });
    const r = await fileReport(fakeClient, { guildId: G, reporterId: spammer, reportedId: uid(890 + n), reasonKey: "spam" });
    ok(`spammer report nguoi thu ${n + 1} -> filed`, r.kind === "filed", r);
  }
  await mkProfile({ userId: uid(896), gender: Gender.FEMALE, seeking: [Gender.MALE] });
  const over = await fileReport(fakeClient, { guildId: G, reporterId: spammer, reportedId: uid(896), reasonKey: "spam" });
  ok(`report thu ${N + 1} trong ngay -> bi chan (rate_limited)`, over.kind === "rate_limited", over);
}

// ─────────────────────────────────────────────────────────────────────────
async function testResetSwipes() {
  group("Reset swipes — kham pha lai tu dau");
  await wipe();

  const A = uid(901), B = uid(902);
  const pa = await mkProfile({ userId: A, gender: Gender.MALE, seeking: [Gender.FEMALE] });
  await mkProfile({ userId: B, gender: Gender.FEMALE, seeking: [Gender.MALE] });

  // A va B like nhau -> match + 2 swipe.
  await recordSwipe({ guildId: G, fromUserId: A, toUserId: B, action: SwipeAction.LIKE });
  await recordSwipe({ guildId: G, fromUserId: B, toUserId: A, action: SwipeAction.LIKE });
  ok("truoc reset: co 1 match", (await db.match.count({ where: { guildId: G } })) === 1);
  ok("truoc reset: A da swipe B -> pool cua A trong", (await countPool(pa)) === 0);

  const r = await resetUserSwipes(G, A);
  ok("reset xoa ca 2 chieu swipe cua A (A->B va B->A)", r.swipes === 2, r);
  ok("reset xoa match cua A", r.matches === 1, r);
  ok("sau reset: khong con swipe nao", (await db.swipe.count({ where: { guildId: G } })) === 0);
  ok("sau reset: khong con match", (await db.match.count({ where: { guildId: G } })) === 0);
  ok("sau reset: A thay B lai trong pool", (await countPool(pa)) === 1);

  // KHONG dung toi block.
  await db.block.create({ data: { blockerId: A, blockedId: uid(999) } });
  await resetUserSwipes(G, A);
  ok("reset KHONG xoa block", (await db.block.count()) === 1);
}

// ─────────────────────────────────────────────────────────────────────────
async function main() {
  console.log("\n\x1b[1mIntegration test — can Postgres that\x1b[0m");
  try {
    await db.$queryRaw`SELECT 1`;
  } catch (e) {
    console.error(
      "\n\x1b[31m  Khong ket noi duoc database.\x1b[0m\n\n" +
        "  docker run --name dating-db -e POSTGRES_PASSWORD=dev -p 5432:5432 -d postgres:16\n" +
        "  npm run db:push\n"
    );
    process.exit(1);
  }

  await testRaceCondition();
  await testSwipeBasics();
  await testSuperLikeItem();
  await testDiscovery();
  await testBlock();
  await testPermissions();
  await testSuperLikeGrants();
  await testReportLifecycle();
  await testReportAntiGrief();
  await testResetSwipes();

  await wipe();
  await db.$disconnect();

  console.log(`\n${"─".repeat(56)}`);
  if (fail === 0) console.log(`\x1b[32m  ${pass} kiem tra deu qua.\x1b[0m\n`);
  else {
    console.log(`\x1b[31m  ${fail} loi\x1b[0m / ${pass + fail} kiem tra\n`);
    process.exit(1);
  }
}

await main();
