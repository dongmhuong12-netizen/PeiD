import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ContainerBuilder,
  MessageFlags,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  TextDisplayBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  type ButtonInteraction,
  type ChatInputCommandInteraction,
  type Interaction,
  type ModalSubmitInteraction,
  type StringSelectMenuInteraction,
} from "discord.js";
import { ProfileStatus, SwipeAction, MatchStatus } from "@prisma/client";
import { db, orderPair } from "../db.js";
import { LIMITS } from "../limits.js";
import { gate } from "../lib/gate.js";
import { ID, parseId } from "../lib/ids.js";
import { logger } from "../lib/logger.js";
import { sendDM } from "../lib/dm.js";
import {
  countPool,
  countSwipesToday,
  getDestinyCandidate,
  getProfile,
  nextCandidate,
  resolveSwipeLimit,
  touchActivity,
} from "../features/discovery.js";
import { getSuperLikes, hasSuperLiked, recordSwipe, sendSuperLike } from "../features/swipe.js";
import {
  announceMatch,
  activeFor,
  declineMatch,
  markReady,
  partnerOf,
  pendingFor,
  unmatch,
} from "../features/match.js";
import { fileReport } from "../features/safety.js";
import { withFreshPhoto } from "../features/photo.js";
import { handleBasics, handlePrefs, handlePrompts, handleSocial, missingFields } from "../features/onboarding.js";
import { socialDisplay, socialSpecs } from "../features/socials.js";
import { TAGS, MAX_TAGS, isValidTag } from "../features/tags.js";
import { buildQuestionCard, QUIZ_QUESTIONS } from "../features/quiz.js";
import {
  CUSTOMIZABLE_GLYPHS,
  getGlyphConfig,
  setGlyph,
  resetGlyph,
} from "../features/glyphConfig.js";
import { notice, selfCard, swipeCard, destinyCard, photo, tagsList, type FullProfile } from "../ui/profileCard.js";
import {
  basicsModal,
  prefsModal,
  promptsModal,
  reportModal,
  socialModal,
  superLikeNoteModal,
} from "../ui/modals.js";
import { COLOR, GLYPH, PLATFORM_GLYPH, PLATFORM_LABEL, GENDER_LABEL, timeAgo } from "../ui/theme.js";
import {
  handleCupid,
  handleCupidForm,
  handleCupidPermsSelect,
  handleFather,
} from "./admin.js";

const log = logger("router");

const V2 = MessageFlags.IsComponentsV2;
const V2E = MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral;

// ─────────────────────────────────────────────────────────────────────────

// Hạn chế tần suất tương tác của mỗi user (chống spam/DDoS)
const rateLimits = new Map<string, { lastRequestTime: number; count: number }>();
const RATE_LIMIT_WINDOW_MS = 3000;
const RATE_LIMIT_MAX_REQUESTS = 5;

export async function route(i: Interaction): Promise<void> {
  if (i.user) {
    const now = Date.now();

    // Tự động dọn dẹp map khi quá lớn để tránh rò rỉ bộ nhớ
    if (rateLimits.size > 10000) {
      for (const [userId, record] of rateLimits.entries()) {
        if (now - record.lastRequestTime > RATE_LIMIT_WINDOW_MS) {
          rateLimits.delete(userId);
        }
      }
    }

    const limit = rateLimits.get(i.user.id);
    if (limit) {
      if (now - limit.lastRequestTime < RATE_LIMIT_WINDOW_MS) {
        if (limit.count >= RATE_LIMIT_MAX_REQUESTS) {
          log.warn(`Rate limit exceeded for user ${i.user.id}`);
          const body = {
            components: [
              notice({
                color: COLOR.crimson,
                title: "Thao tác quá nhanh",
                body: "Bạn đang thao tác quá nhanh. Vui lòng dừng lại vài giây rồi thử lại nhé!",
              }),
            ],
            flags: V2E,
          };
          if (i.isRepliable()) {
            if (i.replied || i.deferred) await i.followUp(body).catch(() => { });
            else await i.reply(body).catch(() => { });
          }
          return;
        }
        limit.count++;
      } else {
        limit.lastRequestTime = now;
        limit.count = 1;
      }
    } else {
      rateLimits.set(i.user.id, { lastRequestTime: now, count: 1 });
    }
  }

  try {
    if (i.isChatInputCommand()) return await onCommand(i);
    if (i.isButton()) return await onButton(i);
    if (i.isModalSubmit()) return await onModal(i);
    if (i.isStringSelectMenu()) return await onSelect(i);
  } catch (err) {
    log.error("loi xu ly interaction", err);
    await fail(i);
  }
}

/// Bao loi cho user thay vi de interaction treo im lang ("This interaction
/// failed"). Loi mo ho van tot hon khong co gi.
async function fail(i: Interaction): Promise<void> {
  if (!i.isRepliable()) return;
  const body = {
    components: [
      notice({
        color: COLOR.crimson,
        title: "Có gì đó hỏng rồi",
        body: "Thử lại sau một lát. Nếu vẫn lỗi, báo cho admin.",
      }),
    ],
    flags: V2E,
  };
  try {
    if (i.replied || i.deferred) await i.followUp(body);
    else await i.reply(body);
  } catch {
    /* interaction het han — khong lam gi duoc nua */
  }
}

const denied = (reason: string) => ({
  components: [notice({ color: COLOR.slate, title: "Chưa dùng được", body: reason })],
  flags: V2E,
});

// ─────────────────────────────────────────────────────────────────────────
// Slash commands
// ─────────────────────────────────────────────────────────────────────────

async function onCommand(i: ChatInputCommandInteraction): Promise<void> {
  // /father va /cupid co he phan quyen rieng (Father/Cupid), khong di qua
  // gate() — gate kiem tra role xac minh 18+, thu khong lien quan gi den
  // quyen quan tri. Mot Father hoan toan co the chua tao ho so.
  if (i.commandName === "father") return handleFather(i);
  if (i.commandName === "cupid") return handleCupid(i);
  if (i.commandName === "cupidform") return handleCupidForm(i);

  const g = await gate(i);
  if (!g.ok) {
    await i.reply(denied(g.reason));
    return;
  }

  switch (i.commandName) {
    case "profile":
      return profileCommand(i, g.guildId);
    case "explore":
      return exploreCommand(i, g.guildId);
    case "matches":
      return matchesCommand(i, g.guildId);
    case "superlikes":
      return superLikesCommand(i, g.guildId);
    case "crush":
      return crushCommand(i, g.guildId);
    case "quiz":
      return quizStartCommand(i, g.guildId);
    case "destiny":
      return destinyCommand(i, g.guildId);
    case "custom":
      return customCommand(i, g.guildId);
    case "help":
      return helpCommand(i);
    case "cupidhelp":
      return cupidHelpCommand(i);
  }
}

async function profileCommand(i: ChatInputCommandInteraction, guildId: string): Promise<void> {
  const sub = i.options.getSubcommand();
  const me = await getProfile(guildId, i.user.id);

  switch (sub) {
    case "setup": {
      // Modal PHAI la phan hoi dau tien — khong duoc defer truoc.
      await i.showModal(basicsModal(me));
      return;
    }

    case "view": {
      if (!me) return void (await i.reply(needProfile()));
      const fresh = await withFreshPhoto(i.client, me);
      const glyphs = await getGlyphConfig(guildId);
      await i.reply({ components: [selfCard(fresh, missingFields(fresh), glyphs)], flags: V2E });
      return;
    }

    case "pause": {
      if (!me) return void (await i.reply(needProfile()));
      await db.profile.update({
        where: { id: me.id },
        data: { status: ProfileStatus.PAUSED },
      });
      await i.reply({
        components: [
          notice({
            color: COLOR.slate,
            title: "Đã ẩn hồ sơ",
            body: "Không ai thấy bạn khi lướt nữa. Các match hiện có vẫn giữ nguyên.",
            footer: "Dùng /profile resume để hiện lại.",
          }),
        ],
        flags: V2E,
      });
      return;
    }

    case "resume": {
      if (!me) return void (await i.reply(needProfile()));
      if (me.status === ProfileStatus.UNDER_REVIEW || me.status === ProfileStatus.BANNED) {
        // Tu bo an khong duoc phep la duong vong qua lenh cam cua mod.
        await i.reply(
          denied("Hồ sơ của bạn đang được mod xem xét. Liên hệ mod của server.")
        );
        return;
      }
      await db.profile.update({ where: { id: me.id }, data: { status: ProfileStatus.DRAFT } });
      const { missing } = await refreshSelf(me.id);
      await i.reply({
        components: [
          notice({
            color: missing.length ? COLOR.slate : COLOR.mint,
            title: missing.length ? "Hồ sơ chưa hoàn tất" : "Đã hiện lại hồ sơ",
            body: missing.length ? missing.map((m) => `• ${m}`).join("\n") : undefined,
            footer: missing.length ? "Dùng /profile setup để hoàn tất." : "Chúc may mắn ✿",
          }),
        ],
        flags: V2E,
      });
      return;
    }

    case "delete": {
      if (!me) return void (await i.reply(needProfile()));
      await i.reply({
        components: [
          notice({
            color: COLOR.crimson,
            title: "Xoá hồ sơ?",
            body:
              "Ảnh, câu trả lời và link MXH của bạn sẽ bị xoá.\n\n" +
              "**Lịch sử lướt và block thì không.** Người bạn đã bỏ qua sẽ " +
              "không xuất hiện lại kể cả khi bạn tạo hồ sơ mới — đây là chủ ý, " +
              "để không ai xoá hồ sơ nhằm lách block.",
            buttons: [
              new ButtonBuilder()
                .setCustomId(ID.profileModal("basics"))
                .setLabel("Thôi, để tôi sửa lại")
                .setStyle(ButtonStyle.Secondary),
              new ButtonBuilder()
                .setCustomId(`d|del|${me.id}`)
                .setLabel("Xoá vĩnh viễn")
                .setStyle(ButtonStyle.Danger),
            ],
          }),
        ],
        flags: V2E,
      });
      return;
    }
  }
}

const needProfile = () => ({
  components: [
    notice({
      color: COLOR.rose,
      title: "Bạn chưa có hồ sơ",
      body: "Tạo một cái đi — mất chưa tới một phút.",
      buttons: [
        new ButtonBuilder()
          .setCustomId(ID.profileSetup())
          .setLabel("Tạo hồ sơ")
          .setEmoji(GLYPH.sparkle)
          .setStyle(ButtonStyle.Success),
      ],
    }),
  ],
  flags: V2E,
});

async function refreshSelf(profileId: string) {
  const { syncStatus } = await import("../features/onboarding.js");
  await syncStatus(profileId);
  const p = await db.profile.findUnique({
    where: { id: profileId },
    include: { prompts: { orderBy: { position: "asc" } }, socials: true },
  });
  return { profile: p, missing: p ? missingFields(p) : [] };
}

// ─────────────────────────────────────────────────────────────────────────
// Luot ho so
// ─────────────────────────────────────────────────────────────────────────

async function exploreCommand(i: ChatInputCommandInteraction, guildId: string): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const body = await buildSwipeView(i, guildId);
  await i.editReply(body);
}

/// Dung chung boi /explore va moi lan bam Like/Pass. Mot nguon su that duy
/// nhat cho "man hinh luot dang phai hien cai gi".
async function buildSwipeView(
  i: Interaction,
  guildId: string
): Promise<{ components: any[]; flags: number }> {
  const me = await getProfile(guildId, i.user.id);
  if (!me) return needProfile();

  const missing = missingFields(me);
  if (missing.length) {
    return {
      components: [
        notice({
          color: COLOR.slate,
          title: "Hoàn tất hồ sơ trước đã",
          body: missing.map((m) => `• ${m}`).join("\n"),
          footer: "Công bằng thôi — bạn cũng đâu muốn lướt profile trống.",
          buttons: [
            new ButtonBuilder()
              .setCustomId(ID.profileSetup())
              .setLabel("Hoàn tất hồ sơ")
              .setStyle(ButtonStyle.Success),
          ],
        }),
      ],
      flags: V2E,
    };
  }

  if (me.status === ProfileStatus.UNDER_REVIEW || me.status === ProfileStatus.BANNED) {
    return denied("Hồ sơ của bạn đang được mod xem xét.");
  }
  if (me.status === ProfileStatus.PAUSED) {
    return {
      components: [
        notice({
          color: COLOR.slate,
          title: "Hồ sơ đang ẩn",
          body: "Bạn không thể lướt khi đang ẩn mình — công bằng hai chiều.",
          footer: "Dùng /profile resume để hiện lại.",
        }),
      ],
      flags: V2E,
    };
  }

  await touchActivity(guildId, i.user.id);

  const cfg = await db.guildConfig.findUnique({ where: { guildId } });
  const pool = await countPool(me);
  const limit = resolveSwipeLimit(pool, cfg?.dailySwipeLimit ?? 15);
  const used = await countSwipesToday(guildId, i.user.id);
  const left = Math.max(0, limit - used);

  if (pool === 0) {
    // Trang thai rong PHAI tu te. Ke hoach ban dau khong he nhac den no,
    // nhung o server nho day la man hinh user gap thuong xuyen nhat.
    return {
      components: [
        notice({
          color: COLOR.slate,
          title: "Hết hồ sơ rồi",
          body: "Bạn đã xem hết mọi người hợp gu ở server này.",
          footer:
            "Quay lại khi có thành viên mới. Hoặc nới bộ lọc tuổi ra một chút xem sao.",
          buttons: [
            new ButtonBuilder()
              .setCustomId(ID.profilePrefs())
              .setLabel("Sửa bộ lọc")
              .setStyle(ButtonStyle.Secondary),
          ],
        }),
      ],
      flags: V2E,
    };
  }

  if (left <= 0) {
    return {
      components: [
        notice({
          color: COLOR.slate,
          title: "Hết lượt hôm nay",
          body: `Bạn đã dùng hết ${limit} lượt.`,
          footer:
            "Đây là chủ đích: ít lượt thì đọc kỹ hơn, và người ta cũng được " +
            "đọc kỹ hơn. Mai quay lại nhé.",
        }),
      ],
      flags: V2E,
    };
  }

  const candidate = await nextCandidate(me);
  if (!candidate) {
    return {
      components: [
        notice({
          color: COLOR.slate,
          title: "Hết hồ sơ rồi",
          footer: "Quay lại sau nhé.",
        }),
      ],
      flags: V2E,
    };
  }

  const fresh = await withFreshPhoto(i.client, candidate.profile);
  const supers = await getSuperLikes(guildId, i.user.id);
  const youSL = await hasSuperLiked(guildId, i.user.id, candidate.profile.userId);
  const glyphs = await getGlyphConfig(guildId);
  return {
    components: [
      swipeCard(fresh, {
        swipesLeft: left,
        superLikes: supers,
        incomingSuperLike: candidate.superLikedYou,
        youSuperLiked: youSL,
        glyphs,
      }),
    ],
    flags: V2E,
  };
}

/// Render card cua MOT nguoi cu the (khong phai nguoi ke tiep). Dung khi
/// super like xong: hien lai chinh nguoi vua super like de nguoi gui Thich/
/// Bo qua. Neu nguoi do da roi khoi pool (vd bi block) thi ve view thuong.
async function buildCardFor(
  i: Interaction,
  guildId: string,
  targetId: string
): Promise<{ components: any[]; flags: number }> {
  const [me, them] = await Promise.all([
    getProfile(guildId, i.user.id),
    getProfile(guildId, targetId),
  ]);
  if (!me || !them) return buildSwipeView(i, guildId);

  const cfg = await db.guildConfig.findUnique({ where: { guildId } });
  const pool = await countPool(me);
  const limit = resolveSwipeLimit(pool, cfg?.dailySwipeLimit ?? 15);
  const used = await countSwipesToday(guildId, i.user.id);
  const left = Math.max(0, limit - used);

  const fresh = await withFreshPhoto(i.client, them);
  const supers = await getSuperLikes(guildId, i.user.id);
  const incoming = await db.superLikeSent.findUnique({
    where: { guildId_fromUserId_toUserId: { guildId, fromUserId: targetId, toUserId: i.user.id } },
  });
  const glyphs = await getGlyphConfig(guildId);
  return {
    components: [
      swipeCard(fresh, {
        swipesLeft: left,
        superLikes: supers,
        incomingSuperLike: incoming ? { note: incoming.note } : null,
        youSuperLiked: true,
        glyphs,
      }),
    ],
    flags: V2E,
  };
}

// ─────────────────────────────────────────────────────────────────────────
// Buttons
// ─────────────────────────────────────────────────────────────────────────

async function onButton(i: ButtonInteraction): Promise<void> {
  // Xoa ho so — customId dac biet, khong qua ID codec.
  if (i.customId.startsWith("d|del|")) {
    const id = i.customId.slice(6);
    await db.profile.deleteMany({ where: { id, userId: i.user.id } });
    await i.update({
      components: [
        notice({
          color: COLOR.slate,
          title: "Đã xoá hồ sơ",
          footer: "Muốn quay lại lúc nào cũng được — /profile setup.",
        }),
      ],
      flags: V2,
    });
    return;
  }

  const p = parseId(i.customId);
  if (!p) return;

  // Nut opt-in match nam trong DM -> khong co guild -> khong qua gate duoc.
  if (p.kind === "match_ready" || p.kind === "match_decline") {
    return matchButton(i, p);
  }

  const g = await gate(i);
  if (!g.ok) return void (await i.reply(denied(g.reason)));
  const guildId = g.guildId;

  switch (p.kind) {
    case "profile_setup":
    case "profile_modal": {
      const me = await getProfile(guildId, i.user.id);
      const section = p.kind === "profile_modal" ? p.section : "basics";
      if (section === "prompts" && !me) return void (await i.reply(needProfile()));
      await i.showModal(section === "prompts" ? promptsModal(me) : basicsModal(me));
      return;
    }

    case "profile_prefs": {
      const me = await getProfile(guildId, i.user.id);
      if (!me) return void (await i.reply(needProfile()));
      await i.showModal(prefsModal(me));
      return;
    }

    case "profile_socials": {
      const me = await getProfile(guildId, i.user.id);
      if (!me) return void (await i.reply(needProfile()));
      await i.reply({ components: [socialsPicker(me)], flags: V2E });
      return;
    }

    case "profile_tags": {
      const me = await getProfile(guildId, i.user.id);
      if (!me) return void (await i.reply(needProfile()));
      await i.reply({ components: [tagsPicker(me)], flags: V2E });
      return;
    }

    case "swipe":
      return swipeButton(i, guildId, p.action, p.targetId);

    case "report_open": {
      const them = await getProfile(guildId, p.targetId);
      await i.showModal(reportModal(p.targetId, them?.displayName ?? "người này"));
      return;
    }

    case "unmatch_ask": {
      await i.reply({
        components: [
          notice({
            color: COLOR.crimson,
            title: "Huỷ match?",
            body: "Phòng chat sẽ bị khoá và hai bạn không thấy lại nhau nữa.",
            footer: "Không thể hoàn tác.",
            buttons: [
              new ButtonBuilder()
                .setCustomId(ID.noop())
                .setLabel("Thôi")
                .setStyle(ButtonStyle.Secondary),
              new ButtonBuilder()
                .setCustomId(ID.unmatchDo(p.matchId))
                .setLabel("Huỷ match")
                .setStyle(ButtonStyle.Danger),
            ],
          }),
        ],
        flags: V2E,
      });
      return;
    }

    case "unmatch_do": {
      const ok = await unmatch(i.client, p.matchId, i.user.id);
      await i.update({
        components: [
          notice({
            color: COLOR.slate,
            title: ok ? "Đã huỷ match" : "Match này không còn nữa",
            footer: ok ? "Dùng /explore để tiếp tục." : undefined,
          }),
        ],
        flags: V2,
      });
      return;
    }

    case "quiz_start": {
      return startMatchQuiz(i, p.matchId);
    }

    case "quiz_answer": {
      return handleQuizAnswer(i, p.optionIndex);
    }

    case "destiny_like": {
      return handleDestinyLike(i, p.userId);
    }

    case "custom_glyph_list": {
      return showGlyphPanel(i, guildId, true);
    }

    case "custom_glyph_page": {
      return showEmojiPicker(i, guildId, p.key, p.page, p.search);
    }

    case "custom_glyph_search": {
      return showCustomGlyphSearchModal(i, p.key);
    }

    case "custom_glyph_clear": {
      return showEmojiPicker(i, guildId, p.key, 0, "");
    }

    case "custom_glyph_reset": {
      return handleCustomGlyphReset(i, guildId, p.key);
    }

    case "noop": {
      await i.update({
        components: [notice({ color: COLOR.slate, title: "Đã huỷ" })],
        flags: V2,
      });
      return;
    }
  }
}

async function swipeButton(
  i: ButtonInteraction,
  guildId: string,
  action: "like" | "pass" | "super",
  targetId: string
): Promise<void> {
  // Super Like mo modal xin loi nhan -> khong duoc defer truoc showModal.
  if (action === "super") {
    const supers = await getSuperLikes(guildId, i.user.id);
    if (supers <= 0) {
      await i.reply({
        components: [
          notice({
            color: COLOR.violet,
            title: "Hết Super Like",
            body:
              "Super Like do admin của server cấp — không mua được bằng gì cả.\n" +
              "Hỏi mod xem server có phát không.",
            footer: "Không có cũng chẳng sao: Thích thường vẫn match được như thường.",
          }),
        ],
        flags: V2E,
      });
      return;
    }
    if (await hasSuperLiked(guildId, i.user.id, targetId)) {
      await i.reply({
        components: [
          notice({
            color: COLOR.violet,
            title: "Bạn đã Super Like người này rồi",
            footer: "Giờ chỉ cần Thích hoặc Bỏ qua họ.",
          }),
        ],
        flags: V2E,
      });
      return;
    }
    const them = await getProfile(guildId, targetId);
    await i.showModal(superLikeNoteModal(targetId, them?.displayName ?? "họ"));
    return;
  }

  await i.deferUpdate();
  await applySwipe(i, guildId, targetId, action === "like" ? SwipeAction.LIKE : SwipeAction.PASS);
}

/// Gui Super Like (item boost) roi RE-RENDER cung card do — nguoi gui van
/// Thich/Bo qua nguoi kia. Super Like KHONG phai quyet dinh swipe.
async function applySuperLike(
  i: ModalSubmitInteraction,
  guildId: string,
  targetId: string,
  note: string | null
): Promise<void> {
  const res = await sendSuperLike({ guildId, fromUserId: i.user.id, toUserId: targetId, note });

  if (res.kind === "no_balance") {
    await i.followUp({
      components: [notice({ color: COLOR.violet, title: "Hết Super Like", body: "Số dư đã hết." })],
      flags: V2E,
    });
    return;
  }
  if (res.kind === "sent") {
    await notifySuperLikeTarget(i.client, guildId, targetId).catch(() => { });
  }

  // Re-render card cua chinh nguoi vua super like -> nut super mo di, con
  // Thich/Bo qua van con de nguoi gui quyet dinh.
  const view = await buildCardFor(i, guildId, targetId);
  await i.editReply(view as any).catch(() => { });
}

/// Ghi swipe (LIKE/PASS) roi hien ngay ho so tiep theo.
///
/// Match KHONG chen ngang man hinh luot: no den qua DM. Dung lai giua chung
/// de bao "Match!" roi bat bam nut quay lai la lam gay mach luot. Ai dang
/// luot thi cu de ho luot.
async function applySwipe(
  i: ButtonInteraction | ModalSubmitInteraction,
  guildId: string,
  targetId: string,
  action: typeof SwipeAction.LIKE | typeof SwipeAction.PASS
): Promise<void> {
  const res = await recordSwipe({ guildId, fromUserId: i.user.id, toUserId: targetId, action });

  if (res.kind === "matched") {
    await announceMatch(i.client, res.matchId).catch((e) =>
      log.error("khong bao duoc match", e)
    );
    // Bao nhe nhang, khong chan duong.
    await i
      .followUp({
        components: [
          notice({
            color: COLOR.gold,
            title: `${GLYPH.sparkle} Match!`,
            body: "Bot đã nhắn tin riêng cho cả hai.",
            footer: "Tắt DM thì xem ở /matches nhé.",
          }),
        ],
        flags: V2E,
      })
      .catch(() => { });
  }

  const next = await buildSwipeView(i, guildId);
  await i.editReply(next as any).catch(() => { });
}

/// Bao cho nguoi vua bi Super Like — qua DM, khong lo danh tinh hay loi nhan
/// (nhung thu do hien tren card noi bat khi ho mo /explore, kem nut Report
/// ngay do). DM chi la mot cu hich, khong phai kenh nhan tin truc tiep.
async function notifySuperLikeTarget(
  client: ButtonInteraction["client"],
  guildId: string,
  targetId: string
): Promise<void> {
  const [user, guild] = await Promise.all([
    client.users.fetch(targetId).catch(() => null),
    client.guilds.fetch(guildId).catch(() => null),
  ]);
  if (!user) return;
  await sendDM(user, {
    components: [
      notice({
        color: COLOR.violet,
        title: `${GLYPH.superLike} Có người vừa Super Like bạn!`,
        body: "Họ đang được xếp ở đầu hàng chờ bạn.",
        footer: `Mở /explore ở ${guild?.name ?? "server"} để xem — kèm lời nhắn của họ.`,
      }),
    ],
    flags: V2,
  });
}

async function matchButton(
  i: ButtonInteraction,
  p: { kind: "match_ready" | "match_decline"; matchId: string }
): Promise<void> {
  if (p.kind === "match_decline") {
    await declineMatch(p.matchId, i.user.id);
    await i.update({
      components: [
        notice({
          color: COLOR.slate,
          title: "Đã bỏ qua",
          footer: "Người kia không được báo là bạn từ chối.",
        }),
      ],
      flags: V2,
    });
    return;
  }

  await i.deferUpdate();
  const res = await markReady(i.client, p.matchId, i.user.id);

  const card = {
    waiting: notice({
      color: COLOR.gold,
      title: "Đã ghi nhận",
      body: "Đang chờ người kia bấm nút. Bot sẽ mở phòng ngay khi cả hai sẵn sàng.",
      footer: `Lời mời hết hạn sau ${LIMITS.optInHours} giờ.`,
    }),
    opened: notice({
      color: COLOR.mint,
      title: `${GLYPH.chat} Phòng đã mở!`,
      body: "Cả hai đã sẵn sàng. Vào phòng riêng để bắt đầu.",
    }),
    expired: notice({
      color: COLOR.slate,
      title: "Lời mời đã hết hạn",
      footer: "Tiếc thật. Dùng /explore để tiếp tục.",
    }),
    gone: notice({ color: COLOR.slate, title: "Match này không còn nữa" }),
    full: notice({
      color: COLOR.rose,
      title: "Bạn đang có đủ 5 phòng chat rồi",
      body: "Hãy unmatch hoặc để một phòng tự hết hạn trước khi mở thêm.",
      footer: "Giới hạn 5 phòng là có chủ ý — chất hơn là lượng nhé.",
    }),
  }[res.kind];

  await i.editReply({ components: [card], flags: V2 });

  if (res.kind === "opened") {
    await i.followUp({
      content: `Phòng của bạn: <#${res.threadId}>`,
      flags: MessageFlags.Ephemeral,
    });
  }
}

// ─────────────────────────────────────────────────────────────────────────
// Modals
// ─────────────────────────────────────────────────────────────────────────

async function onModal(i: ModalSubmitInteraction): Promise<void> {
  const p = parseId(i.customId);
  if (!p) return;

  const g = await gate(i);
  if (!g.ok) return void (await i.reply(denied(g.reason)));
  const guildId = g.guildId;

  switch (p.kind) {
    case "profile_modal": {
      const res =
        p.section === "basics" ? await handleBasics(i, guildId) : await handlePrompts(i, guildId);
      if (!res.ok) return void (await i.reply(problem(res.error)));

      const me = await getProfile(guildId, i.user.id);
      if (!me) return void (await i.reply(problem("Không lưu được. Thử lại.")));
      const missing = missingFields(me);

      // Vua xong phan co ban ma chua tra loi cau hoi -> dan thang toi buoc
      // ke tiep bang mot nut. Khong bat user tu doan phai lam gi.
      if (p.section === "basics" && missing.length) {
        await i.reply({
          components: [
            notice({
              color: COLOR.rose,
              title: "Xong phần thông tin ✿",
              body: missing.map((m) => `• ${m}`).join("\n"),
              buttons: [
                new ButtonBuilder()
                  .setCustomId(ID.profileModal("prompts"))
                  .setLabel("Trả lời câu hỏi")
                  .setStyle(ButtonStyle.Success),
              ],
            }),
          ],
          flags: V2E,
        });
        return;
      }

      const fresh = await withFreshPhoto(i.client, me);
      // KHONG dat nut o notice o day: selfCard ben duoi da co san nut "Link
      // MXH" cung custom_id (ID.profileSocials). Hai nut cung custom_id trong
      // MOT message -> Discord tu choi (COMPONENT_CUSTOM_ID_DUPLICATED).
      const glyphs = await getGlyphConfig(guildId);
      await i.reply({
        components: [
          notice({
            color: missing.length ? COLOR.slate : COLOR.mint,
            title: missing.length ? "Đã lưu — vẫn còn thiếu" : "Hồ sơ đã sẵn sàng ✿",
            body: missing.length ? missing.map((m) => `• ${m}`).join("\n") : undefined,
            footer: missing.length
              ? undefined
              : "Dùng /explore để bắt đầu lướt. Nút bên dưới để thêm link MXH.",
          }),
          selfCard(fresh, missing, glyphs),
        ],
        flags: V2E,
      });
      return;
    }

    case "profile_prefs": {
      const res = await handlePrefs(i, guildId);
      await i.reply(
        res.ok
          ? {
            components: [
              notice({
                color: COLOR.mint,
                title: "Đã lưu bộ lọc",
                footer: "Dùng /explore để xem kết quả.",
              }),
            ],
            flags: V2E,
          }
          : problem(res.error)
      );
      return;
    }

    case "profile_socials_modal": {
      const res = await handleSocial(i, guildId, p.platform);
      await i.reply(
        res.ok
          ? {
            components: [
              notice({
                color: COLOR.mint,
                title: "Đã lưu",
                footer: "Chỉ người đã match với bạn nhìn thấy link này.",
              }),
            ],
            flags: V2E,
          }
          : problem(res.error)
      );
      return;
    }

    case "superlike_note": {
      const note = i.fields.getTextInputValue("note")?.trim() || null;
      if (i.isFromMessage()) {
        // Modal mo tu card dang luot -> super like xong re-render chinh card do.
        await i.deferUpdate();
        await applySuperLike(i, guildId, p.targetId, note);
      } else {
        await i.deferReply({ flags: MessageFlags.Ephemeral });
        const res = await sendSuperLike({
          guildId,
          fromUserId: i.user.id,
          toUserId: p.targetId,
          note,
        });
        if (res.kind === "sent") await notifySuperLikeTarget(i.client, guildId, p.targetId).catch(() => { });
        await i.editReply({
          components: [
            notice({
              color: COLOR.violet,
              title:
                res.kind === "no_balance"
                  ? "Hết Super Like"
                  : res.kind === "already_sent"
                    ? "Bạn đã Super Like người này rồi"
                    : `${GLYPH.superLike} Đã gửi Super Like`,
            }),
          ],
          flags: V2,
        });
      }
      return;
    }

    case "report_submit": {
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const reason = i.fields.getStringSelectValues("reason")[0];
      const details = i.fields.getTextInputValue("details")?.trim() || null;
      if (!reason) return void (await i.editReply(problem("Chưa chọn lý do.")));

      const res = await fileReport(i.client, {
        guildId,
        reporterId: i.user.id,
        reportedId: p.targetId,
        reasonKey: reason,
        details,
      });

      const card =
        res.kind === "already_reported"
          ? notice({
            color: COLOR.slate,
            title: "Bạn đã báo cáo người này rồi",
            footer: "Mod đang xem xét.",
          })
          : res.kind === "no_profile"
            ? notice({ color: COLOR.slate, title: "Không tìm thấy hồ sơ này" })
            : res.kind === "rate_limited"
              ? notice({
                color: COLOR.slate,
                title: "Bạn đã báo cáo quá nhiều hôm nay",
                body: `Tối đa ${res.perDay} báo cáo mỗi ngày.`,
                footer: "Giới hạn này để chống lạm dụng báo cáo. Thử lại sau.",
              })
              : notice({
                color: COLOR.mint,
                title: "Đã gửi báo cáo",
                body:
                  "Mod đã nhận được và sẽ xem xét.\n" +
                  "Bạn cũng đã chặn người này — bạn sẽ không thấy họ nữa.",
                footer:
                  "Hồ sơ của họ KHÔNG tự bị khoá — mod quyết định. " +
                  "Cảm ơn bạn đã giúp giữ server an toàn.",
              });

      await i.editReply({ components: [card], flags: V2 });
      return;
    }

    case "custom_glyph_search_submit": {
      const query = i.fields.getTextInputValue("query");
      return showEmojiPicker(i, guildId, p.key, 0, query);
    }
  }
}

const problem = (msg: string) => ({
  components: [notice({ color: COLOR.crimson, title: "Chưa lưu được", body: msg })],
  flags: V2E,
});

/// Bang chon nen tang MXH. Select menu nam TRONG container, khong phai
/// message thu hai — de khoi vo mach thi giac.
function socialsPicker(me: FullProfile): ContainerBuilder {
  const c = new ContainerBuilder().setAccentColor(COLOR.rose);
  c.addTextDisplayComponents(new TextDisplayBuilder().setContent("### Link mạng xã hội"));
  c.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      "**Chỉ người đã match với bạn mới thấy.** Người đang lướt thì không —\n" +
      "vậy nên không ai lướt để lấy Instagram của bạn được."
    )
  );

  const linked = new Map(me.socials.map((s) => [s.platform as string, s.value]));
  c.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      socialSpecs()
        .map((s) => {
          const v = linked.get(s.platform);
          return v
            ? `${PLATFORM_GLYPH[s.platform] ?? "🔗"} ${PLATFORM_LABEL[s.platform]} — ${socialDisplay(s.platform, v)}`
            : `${PLATFORM_GLYPH[s.platform] ?? "🔗"} ${PLATFORM_LABEL[s.platform]} — *chưa gắn*`;
        })
        .join("\n")
    )
  );

  c.addActionRowComponents(
    new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(ID.profileSocials())
        .setPlaceholder("Chọn nền tảng để thêm hoặc sửa")
        .addOptions(
          socialSpecs().map((s) =>
            new StringSelectMenuOptionBuilder()
              .setLabel(PLATFORM_LABEL[s.platform] ?? s.label)
              .setValue(s.platform)
              .setDescription(linked.has(s.platform) ? "Đã gắn — bấm để sửa" : s.hint.slice(0, 100))
          )
        )
    )
  );

  return c;
}

function tagsPicker(me: FullProfile): ContainerBuilder {
  const c = new ContainerBuilder().setAccentColor(COLOR.rose);
  c.addTextDisplayComponents(new TextDisplayBuilder().setContent("### Sở thích của bạn"));
  c.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      "**Chọn tối đa 8 sở thích.** Sở thích này sẽ hiển thị trên hồ sơ của bạn\n" +
      "và giúp ưu tiên ghép cặp với những người có cùng mối quan tâm."
    )
  );

  const selected = me.tags || [];
  if (selected.length > 0) {
    const list = selected
      .map((t) => {
        const spec = TAGS.find((tag) => tag.key === t);
        return spec ? `\`${spec.emoji} ${spec.label}\`` : `\`${t}\``;
      })
      .join("  ");
    c.addTextDisplayComponents(new TextDisplayBuilder().setContent(list));
  } else {
    c.addTextDisplayComponents(
      new TextDisplayBuilder().setContent("*Chưa chọn sở thích nào — hãy chọn ở bên dưới.*")
    );
  }

  c.addActionRowComponents(
    new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(ID.profileTagsSelect())
        .setPlaceholder("Chọn sở thích (tối đa 8)")
        .setMinValues(0)
        .setMaxValues(Math.min(TAGS.length, MAX_TAGS))
        .addOptions(
          TAGS.map((t) => {
            const opt = new StringSelectMenuOptionBuilder()
              .setLabel(t.label)
              .setValue(t.key)
              .setEmoji(t.emoji);
            if (selected.includes(t.key)) {
              opt.setDefault(true);
            }
            return opt;
          })
        )
    )
  );

  return c;
}

// ─────────────────────────────────────────────────────────────────────────
// Select menus
// ─────────────────────────────────────────────────────────────────────────

async function onSelect(i: StringSelectMenuInteraction): Promise<void> {
  const p = parseId(i.customId);
  if (!p) return;

  if (p.kind === "cupid_perms") return handleCupidPermsSelect(i, p.targetId);

  if (p.kind === "custom_glyph_list") {
    const g = await gate(i);
    if (!g.ok) return void (await i.reply(denied(g.reason)));
    const key = i.values[0];
    if (!key) return;
    return showEmojiPicker(i, g.guildId, key, 0, "");
  }

  if (p.kind === "custom_glyph_pick") {
    const g = await gate(i);
    if (!g.ok) return void (await i.reply(denied(g.reason)));
    return handleCustomGlyphPick(i, g.guildId, p.key);
  }

  if (p.kind === "profile_tags_select") {
    const g = await gate(i);
    if (!g.ok) return void (await i.reply(denied(g.reason)));

    const selectedTags = i.values;
    const valid = selectedTags.every(isValidTag);
    if (!valid || selectedTags.length > MAX_TAGS) {
      return void (await i.reply(problem(`Sở thích không hợp lệ hoặc vượt quá ${MAX_TAGS} sở thích.`)));
    }

    const me = await getProfile(g.guildId, i.user.id);
    if (!me) return void (await i.reply(problem("Chưa có hồ sơ.")));

    await db.profile.update({
      where: { id: me.id },
      data: { tags: selectedTags, lastActiveAt: new Date() },
    });

    const { syncStatus } = await import("../features/onboarding.js");
    await syncStatus(me.id);

    const fresh = await getProfile(g.guildId, i.user.id);
    if (fresh) {
      await i.update({
        components: [tagsPicker(fresh)],
        flags: V2,
      });
    }
    return;
  }

  if (p.kind !== "profile_socials") return;

  const g = await gate(i);
  if (!g.ok) return void (await i.reply(denied(g.reason)));

  const platform = i.values[0];
  if (!platform) return;

  const me = await getProfile(g.guildId, i.user.id);
  const current = me?.socials.find((s) => s.platform === platform);
  await i.showModal(socialModal(platform, current?.value));
}

// ─────────────────────────────────────────────────────────────────────────
// /superlikes
// ─────────────────────────────────────────────────────────────────────────

async function superLikesCommand(
  i: ChatInputCommandInteraction,
  guildId: string
): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const n = await getSuperLikes(guildId, i.user.id);

  await i.editReply({
    components: [
      notice({
        color: n > 0 ? COLOR.violet : COLOR.slate,
        title: n > 0 ? `${GLYPH.superLike} Bạn có ${n} Super Like` : "Bạn chưa có Super Like nào",
        body:
          n > 0
            ? "Dùng khi lướt — nút ⭐ trên hồ sơ. Gửi kèm được một lời nhắn ngắn, " +
            "nhưng họ chỉ đọc được nếu match."
            : "Super Like do admin server cấp. Không mua được bằng gì cả.",
        footer:
          n > 0
            ? `Chỉ dùng được ở ${i.guild?.name ?? "server này"}.`
            : "Thích thường vẫn match được như thường — Super Like chỉ là thêm một lời nhắn.",
      }),
    ],
    flags: V2,
  });
}

// ─────────────────────────────────────────────────────────────────────────
// /matches — duong lui khi user tat DM
// ─────────────────────────────────────────────────────────────────────────

async function matchesCommand(i: ChatInputCommandInteraction, guildId: string): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });

  const [pending, active] = await Promise.all([
    pendingFor(guildId, i.user.id),
    activeFor(guildId, i.user.id),
  ]);

  // Phan tach pending thanh 2 nhom: can bam va dang cho doi phuong
  const needsMyAction = pending.filter((m) =>
    m.userAId === i.user.id ? !m.userAReady : !m.userBReady
  );
  const waitingForThem = pending.filter((m) =>
    m.userAId === i.user.id ? m.userAReady : m.userBReady
  );

  if (!pending.length && !active.length) {
    await i.editReply({
      components: [
        notice({
          color: COLOR.slate,
          title: "Chưa có match nào",
          body: "Hãy dùng /explore để lướt và thích ai đó.",
          footer: "Khi cả hai cùng thích nhau thì bot sẽ báo ở đây.",
        }),
      ],
      flags: V2,
    });
    return;
  }

  const cards = [];

  // ── Phan 1: Loi moi cho ban phan hoi ────────────────────────────────────
  if (needsMyAction.length) {
    cards.push(
      notice({
        color: COLOR.violet,
        title: `📥 Lời mời đang chờ bạn (${needsMyAction.length})`,
        body: "Những người này cũng thích bạn. Bấm Đồng ý để mở phòng chat, hoặc Bỏ qua.",
      })
    );

    for (const m of needsMyAction.slice(0, 5)) {
      const them = await getProfile(guildId, partnerOf(m, i.user.id));
      if (!them) continue;
      const tags = tagsList(them);
      const hoursLeft = Math.max(0, Math.round((m.optInExpiresAt.getTime() - Date.now()) / 3600_000));

      const card = notice({
        color: COLOR.gold,
        title: `${GLYPH.sparkle} ${them.displayName} · ${them.age}`,
        body: [
          `Giới tính: ${GENDER_LABEL[them.gender] ?? them.gender}`,
          tags ? `Sở thích: ${tags}` : "",
          `Còn ${hoursLeft} giờ để quyết định.`,
        ].filter(Boolean).join("\n"),
        buttons: [
          new ButtonBuilder()
            .setCustomId(ID.matchReady(m.id))
            .setLabel("Đồng ý chat")
            .setEmoji(GLYPH.chat)
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId(ID.matchDecline(m.id))
            .setLabel("Bỏ qua")
            .setStyle(ButtonStyle.Secondary),
        ],
      });

      const img = photo(them);
      if (img) card.addMediaGalleryComponents(img);
      cards.push(card);
    }
  }

  // ── Phan 2: Ban da dong y, dang cho doi phuong ──────────────────────────
  if (waitingForThem.length) {
    cards.push(
      notice({
        color: COLOR.slate,
        title: `⏳ Đang chờ họ đồng ý (${waitingForThem.length})`,
        body: "Bạn đã đồng ý. Bot sẽ tự mở phòng khi họ cũng bấm vào.",
      })
    );

    for (const m of waitingForThem.slice(0, 3)) {
      const them = await getProfile(guildId, partnerOf(m, i.user.id));
      if (!them) continue;
      const hoursLeft = Math.max(0, Math.round((m.optInExpiresAt.getTime() - Date.now()) / 3600_000));

      const card = notice({
        color: COLOR.slate,
        title: `${them.displayName} · ${them.age}`,
        body: `Còn ${hoursLeft} giờ trước khi lời mời hết hạn.`,
        buttons: [
          new ButtonBuilder()
            .setCustomId(`waiting_${m.id}`)
            .setLabel("Đang chờ... ⏳")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(true),
          new ButtonBuilder()
            .setCustomId(ID.matchDecline(m.id))
            .setLabel("Huỷ")
            .setStyle(ButtonStyle.Danger),
        ],
      });
      cards.push(card);
    }
  }

  // ── Phan 3: Phong chat dang hoat dong ───────────────────────────────────
  if (active.length) {
    cards.push(
      notice({
        color: COLOR.mint,
        title: `💬 Phòng chat đang hoạt động (${active.length}/5)`,
        body: active.length >= 5
          ? "Bạn đang ở đủ 5 phòng. Hãy unmatch một phòng để nhận match mới."
          : "Bấm \"Vào Chat\" để mở phòng riêng trong server.",
      })
    );

    for (const m of active) {
      const them = await getProfile(guildId, partnerOf(m, i.user.id));
      if (!them) continue;
      const tags = tagsList(them);

      const card = notice({
        color: COLOR.mint,
        title: `${GLYPH.chat} ${them.displayName} · ${them.age}`,
        body: [
          `Giới tính: ${GENDER_LABEL[them.gender] ?? them.gender}`,
          tags ? `Sở thích: ${tags}` : "",
          m.threadId ? `Hoạt động: ${timeAgo(m.lastActivityAt)}` : "Đang khởi tạo phòng...",
        ].filter(Boolean).join("\n"),
        buttons: m.threadId ? [
          new ButtonBuilder()
            .setLabel("Vào Chat")
            .setEmoji(GLYPH.chat)
            .setStyle(ButtonStyle.Link)
            .setURL(`https://discord.com/channels/${guildId}/${m.threadId}`),
        ] : [],
      });

      const img = photo(them);
      if (img) card.addMediaGalleryComponents(img);
      cards.push(card);
    }
  }

  await i.editReply({ components: cards.slice(0, 10), flags: V2 });
}




// ─────────────────────────────────────────────────────────────────────────
// /quiz & quiz button interactions
// ─────────────────────────────────────────────────────────────────────────

async function quizStartCommand(i: ChatInputCommandInteraction, guildId: string): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });

  // Kiem tra xem co phai dang trong private thread cua active match khong
  const match = await db.match.findFirst({
    where: {
      guildId,
      threadId: i.channelId || "",
      status: MatchStatus.ACTIVE,
    },
  });

  if (!match) {
    await i.editReply({
      components: [
        notice({
          color: COLOR.crimson,
          title: "Không khả dụng",
          body: "Lệnh này chỉ có thể sử dụng bên trong phòng chat riêng (Lounge Thread) của một Match đang hoạt động!",
        }),
      ],
      flags: V2,
    });
    return;
  }

  await startMatchQuiz(i, match.id);
}

async function startMatchQuiz(
  i: ChatInputCommandInteraction | ButtonInteraction,
  matchId: string
): Promise<void> {
  // Check if QuizState already exists
  let quiz = await db.quizState.findUnique({ where: { matchId } });
  if (quiz) {
    const replyContent = {
      components: [
        notice({
          color: COLOR.slate,
          title: "Quiz đang diễn ra",
          body: `Trò chơi trắc nghiệm đang được tiến hành ở câu hỏi số ${quiz.currentRound + 1}/5. Hãy trả lời câu hỏi hiện tại nhé!`,
        }),
      ],
      flags: V2 as any,
    };
    if (i.isButton()) {
      await i.reply({ ...replyContent, flags: MessageFlags.Ephemeral }).catch(() => { });
    } else {
      await (i as ChatInputCommandInteraction).editReply(replyContent);
    }
    return;
  }

  // Create QuizState
  quiz = await db.quizState.create({
    data: {
      matchId,
      currentRound: 0,
      questions: [0, 1, 2, 3, 4],
      answersA: [],
      answersB: [],
    },
  });

  // Reply acknowledging starting
  const qCard = buildQuestionCard(0);
  const channel = i.channel as any;
  if (i.isButton()) {
    await i.reply({ content: "Đang khởi động quiz...", flags: MessageFlags.Ephemeral }).catch(() => { });
    if (channel && typeof channel.send === "function") {
      await channel.send({
        content: "🎮 **Hẹn hò Minigame: Trắc nghiệm Duyên Số**\nCả hai hãy cùng trả lời câu hỏi dưới đây:",
        components: [qCard],
        flags: MessageFlags.IsComponentsV2,
      }).catch(() => { });
    }
  } else {
    await (i as ChatInputCommandInteraction).editReply({
      content: "Đã khởi động quiz thành công! Hãy xem và trả lời tin nhắn ở thread này.",
    });
    if (channel && typeof channel.send === "function") {
      await channel.send({
        content: "🎮 **Hẹn hò Minigame: Trắc nghiệm Duyên Số**\nCả hai hãy cùng trả lời câu hỏi dưới đây:",
        components: [qCard],
        flags: MessageFlags.IsComponentsV2,
      }).catch(() => { });
    }
  }
}

async function handleQuizAnswer(i: ButtonInteraction, optionIndex: number): Promise<void> {
  const match = await db.match.findFirst({
    where: {
      threadId: i.channelId || "",
      status: MatchStatus.ACTIVE,
    },
  });

  if (!match) {
    await i.reply({ content: "Không tìm thấy Match hoạt động ở kênh này.", flags: MessageFlags.Ephemeral }).catch(() => { });
    return;
  }

  const quiz = await db.quizState.findUnique({
    where: { matchId: match.id },
  });

  if (!quiz) {
    await i.reply({ content: "Minigame quiz chưa được bắt đầu hoặc đã kết thúc.", flags: MessageFlags.Ephemeral }).catch(() => { });
    return;
  }

  let isUserA = false;
  if (i.user.id === match.userAId) {
    isUserA = true;
  } else if (i.user.id === match.userBId) {
    isUserA = false;
  } else {
    await i.reply({ content: "Bạn không tham gia vào Match này nên không thể chơi quiz!", flags: MessageFlags.Ephemeral }).catch(() => { });
    return;
  }

  const ansChar = optionIndex.toString();
  const currentRound = quiz.currentRound;
  const oldAns = isUserA ? quiz.answersA : quiz.answersB;

  if (oldAns.length > currentRound) {
    await i.reply({ content: "Bạn đã trả lời câu hỏi này rồi. Đang đợi đối phương trả lời...", flags: MessageFlags.Ephemeral }).catch(() => { });
    return;
  }

  const newAns = [...oldAns, ansChar];
  const updateData = isUserA ? { answersA: newAns } : { answersB: newAns };

  const updatedQuiz = await db.quizState.update({
    where: { matchId: match.id },
    data: updateData,
  });

  const letterStr = ["A", "B", "C", "D"][optionIndex]!;
  await i.reply({
    content: `Bạn đã chọn đáp án **${letterStr}**. Đang đợi đối phương trả lời...`,
    flags: MessageFlags.Ephemeral,
  }).catch(() => { });

  // Check if both have answered
  const answersAClean = updatedQuiz.answersA;
  const answersBClean = updatedQuiz.answersB;
  const channel = i.channel as any;

  if (answersAClean.length === currentRound + 1 && answersBClean.length === currentRound + 1) {
    // Reveal answers
    const questionsArr = updatedQuiz.questions as number[];
    const qIdx = questionsArr[currentRound] ?? currentRound;
    const q = QUIZ_QUESTIONS[qIdx]!;
    const choiceA = parseInt(answersAClean[currentRound]!, 10);
    const choiceB = parseInt(answersBClean[currentRound]!, 10);

    const profileA = await getProfile(match.guildId, match.userAId);
    const profileB = await getProfile(match.guildId, match.userBId);
    const nameA = profileA?.displayName || `<@${match.userAId}>`;
    const nameB = profileB?.displayName || `<@${match.userBId}>`;

    const explainA = q.options[choiceA]!;
    const explainB = q.options[choiceB]!;
    const letterA = ["A", "B", "C", "D"][choiceA]!;
    const letterB = ["A", "B", "C", "D"][choiceB]!;

    const lines = [
      `🌟 **Câu ${currentRound + 1}: ${q.text}**`,
      `👤 **${nameA}** chọn: **${letterA}**. *${explainA}*`,
      `👤 **${nameB}** chọn: **${letterB}**. *${explainB}*`,
    ];

    let commentary = "";
    if (choiceA === choiceB) {
      commentary = "✨ **Tâm đầu ý hợp!** Hai bạn có lối suy nghĩ cực kỳ đồng điệu.";
    } else {
      commentary = "⚡ **Sự khác biệt thú vị!** Nhưng bù trừ lẫn nhau cũng rất dễ thương.";
    }

    const nextRound = currentRound + 1;
    if (nextRound < 5) {
      await db.quizState.update({
        where: { matchId: match.id },
        data: { currentRound: nextRound },
      });

      if (channel && typeof channel.send === "function") {
        await channel.send({
          embeds: [{
            color: choiceA === choiceB ? 0x2ecc71 : 0xe67e22,
            description: lines.join("\n") + `\n\n${commentary}`,
          }],
        }).catch(() => { });

        // Send next question card after a short delay
        setTimeout(async () => {
          const nextQIdx = questionsArr[nextRound] ?? nextRound;
          const nextQCard = buildQuestionCard(nextQIdx);
          await channel.send({
            content: `⏩ **Câu hỏi tiếp theo:**`,
            components: [nextQCard],
            flags: MessageFlags.IsComponentsV2,
          }).catch(() => { });
        }, 2500);
      }
    } else {
      // Quiz finished
      let matchesCount = 0;
      for (let j = 0; j < 5; j++) {
        if (answersAClean[j] === answersBClean[j]) {
          matchesCount++;
        }
      }
      const pct = matchesCount * 20;

      let resultColor: number = COLOR.slate;
      let resultTitle = "";
      let resultComment = "";

      if (pct >= 80) {
        resultColor = COLOR.gold;
        resultTitle = "🏆 Định Mệnh Sắp Đặt!";
        resultComment = "Hai bạn ăn ý đến khó tin! Thực sự rất hợp nhau.";
      } else if (pct >= 40) {
        resultColor = COLOR.mint;
        resultTitle = "🌸 Khá Hợp Nhau Đó!";
        resultComment = "Có nhiều điểm chung để bắt đầu trò chuyện sâu sắc hơn rồi.";
      } else {
        resultColor = COLOR.rose;
        resultTitle = "⚡ Khác Biệt Tạo Sức Hút!";
        resultComment = "Tuy lựa chọn khác biệt nhiều, nhưng chính sự đối lập lại là khởi nguồn thu hút!";
      }

      if (channel && typeof channel.send === "function") {
        await channel.send({
          embeds: [{
            color: resultColor,
            title: `${resultTitle} (Độ ăn ý: ${pct}%)`,
            description: lines.join("\n") + `\n\n${commentary}\n\n🏆 **Kết quả chung cuộc:**\n- Trùng khớp: \`${matchesCount}/5\` câu trả lời\n- Nhận xét: *${resultComment}*`,
          }],
        }).catch(() => { });
      }

      // Delete QuizState
      await db.quizState.delete({
        where: { matchId: match.id },
      });
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────
// /destiny & destiny cards
// ─────────────────────────────────────────────────────────────────────────

async function destinyCommand(i: ChatInputCommandInteraction, guildId: string): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const me = await getProfile(guildId, i.user.id);
  if (!me) return void (await i.editReply(needProfile()));

  const missing = missingFields(me);
  if (missing.length) {
    await i.editReply({
      components: [
        notice({
          color: COLOR.slate,
          title: "Hoàn tất hồ sơ trước đã",
          body: missing.map((m) => `• ${m}`).join("\n"),
          footer: "Công bằng thôi — bạn cũng cần có hồ sơ hoàn chỉnh.",
          buttons: [
            new ButtonBuilder()
              .setCustomId(ID.profileSetup())
              .setLabel("Hoàn tất hồ sơ")
              .setStyle(ButtonStyle.Success),
          ],
        }),
      ],
      flags: V2,
    });
    return;
  }

  if (me.status === ProfileStatus.UNDER_REVIEW || me.status === ProfileStatus.BANNED) {
    await i.editReply(denied("Hồ sơ của bạn đang được mod xem xét."));
    return;
  }
  if (me.status === ProfileStatus.PAUSED) {
    await i.editReply({
      components: [
        notice({
          color: COLOR.slate,
          title: "Hồ sơ đang ẩn",
          body: "Bạn không thể xem quẻ bói duyên phận khi đang ẩn mình.",
          footer: "Dùng /profile resume để hiện lại.",
        }),
      ],
      flags: V2,
    });
    return;
  }

  // Cooldown check (24 hours) - we can store it in me.lastDestinyAt
  const now = new Date();
  if (me.lastDestinyAt) {
    const msDiff = now.getTime() - me.lastDestinyAt.getTime();
    const cooldownMs = 24 * 3600 * 1000;
    if (msDiff < cooldownMs) {
      const remainMs = cooldownMs - msDiff;
      const hours = Math.floor(remainMs / (3600 * 1000));
      const mins = Math.ceil((remainMs % (3600 * 1000)) / (60 * 1000));
      await i.editReply({
        components: [
          notice({
            color: COLOR.slate,
            title: "Quẻ Duyên đã rút hôm nay",
            body: `Bạn đã xem quẻ bói duyên phận của ngày hôm nay rồi.\n⏳ Hãy quay lại sau **${hours} giờ ${mins} phút** nữa để rút quẻ tiếp theo!`,
          }),
        ],
        flags: V2,
      });
      return;
    }
  }

  await touchActivity(guildId, i.user.id);

  const candidate = await getDestinyCandidate(me);
  if (!candidate) {
    await i.editReply({
      components: [
        notice({
          color: COLOR.slate,
          title: "Hôm nay chưa có duyên",
          body: "Hệ thống hôm nay chưa tìm thấy quẻ bói phù hợp cho bạn. Hãy thử nới rộng bộ lọc tìm kiếm tuổi/giới tính hoặc quay lại sau nhé!",
        }),
      ],
      flags: V2,
    });
    return;
  }

  // Update lastDestinyAt
  await db.profile.update({
    where: { id: me.id },
    data: { lastDestinyAt: now },
  });

  const fresh = await withFreshPhoto(i.client, candidate.profile);
  const shared = fresh.tags.filter((t) => me.tags.includes(t));

  await i.editReply({
    components: [destinyCard(fresh, shared)],
    flags: V2,
  });
}

async function handleDestinyLike(i: ButtonInteraction, themId: string): Promise<void> {
  const guildId = i.guildId!;
  const me = await getProfile(guildId, i.user.id);
  if (!me) return;

  const outcome = await recordSwipe({
    guildId,
    fromUserId: i.user.id,
    toUserId: themId,
    action: SwipeAction.LIKE,
  });

  if (outcome.kind === "matched") {
    await i.reply({
      components: [
        notice({
          color: COLOR.mint,
          title: "🎉 Match Duyên Phận!",
          body: "Hai bạn đã quẹt thích nhau! Phòng chat của hai bạn đã được tạo tự động.",
        }),
      ],
      flags: V2,
    });
    await announceMatch(i.client, outcome.matchId!);
  } else {
    const them = await getProfile(guildId, themId);
    if (them) {
      const recipient = await i.client.users.fetch(themId).catch(() => null);
      if (recipient) {
        await sendDM(recipient, {
          embeds: [{
            color: COLOR.gold,
            title: "✨ Quẻ Bói Duyên Số",
            description: "Bạn chính là Quẻ Bói Duyên Số ngày hôm nay của một ai đó trong server! Hãy vào `/explore` ngay để tìm kiếm họ nhé! 😉",
          }]
        });
      }
    }

    await i.reply({
      components: [
        notice({
          color: COLOR.mint,
          title: "💖 Đã gửi ngỏ ý Duyên Phận",
          body: "Đã gửi ý định kết duyên tới đối phương thành công! Chúc bạn may mắn.",
        }),
      ],
      flags: V2,
    });
  }
}

// ─────────────────────────────────────────────────────────────────────────
// /crush
// ─────────────────────────────────────────────────────────────────────────

async function crushCommand(i: ChatInputCommandInteraction, guildId: string): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const sub = i.options.getSubcommand();

  const me = await getProfile(guildId, i.user.id);
  if (!me) {
    await i.editReply(needProfile());
    return;
  }

  if (sub === "add") {
    const targetUser = i.options.getUser("user", true);
    if (targetUser.id === i.user.id) {
      await i.editReply({
        components: [
          notice({
            color: COLOR.crimson,
            title: "Không hợp lệ",
            body: "Bạn không thể tự crush chính mình! Hãy chọn một thành viên khác nhé.",
          }),
        ],
        flags: V2,
      });
      return;
    }

    const them = await getProfile(guildId, targetUser.id);
    if (!them) {
      await i.editReply({
        components: [
          notice({
            color: COLOR.slate,
            title: "Người này chưa có hồ sơ",
            body: "Đối phương chưa tạo hồ sơ dating trên server này nên không thể thêm làm Crush ẩn danh. Hãy rủ họ tạo hồ sơ nhé!",
          }),
        ],
        flags: V2,
      });
      return;
    }

    // Check existing crush
    const existing = await db.secretCrush.findUnique({
      where: {
        guildId_fromUserId_toUserId: {
          guildId,
          fromUserId: i.user.id,
          toUserId: targetUser.id,
        },
      },
    });

    if (existing) {
      await i.editReply({
        components: [
          notice({
            color: COLOR.slate,
            title: "Đã có trong danh sách",
            body: `Bạn đã thêm ${them.displayName} làm Crush ẩn danh rồi.`,
          }),
        ],
        flags: V2,
      });
      return;
    }

    // Check count
    const count = await db.secretCrush.count({
      where: { guildId, fromUserId: i.user.id },
    });

    if (count >= 3) {
      await i.editReply({
        components: [
          notice({
            color: COLOR.crimson,
            title: "Đạt giới hạn",
            body: "Bạn chỉ được đặt tối đa 3 Crush ẩn danh cùng lúc. Vui lòng gỡ bớt để thêm người mới.",
          }),
        ],
        flags: V2,
      });
      return;
    }

    // Create Secret Crush
    await db.secretCrush.create({
      data: { guildId, fromUserId: i.user.id, toUserId: targetUser.id },
    });

    // Check reciprocal crush
    const reciprocal = await db.secretCrush.findUnique({
      where: {
        guildId_fromUserId_toUserId: {
          guildId,
          fromUserId: targetUser.id,
          toUserId: i.user.id,
        },
      },
    });

    if (reciprocal) {
      // mutual match!
      // Delete crush records
      await db.secretCrush.deleteMany({
        where: {
          guildId,
          OR: [
            { fromUserId: i.user.id, toUserId: targetUser.id },
            { fromUserId: targetUser.id, toUserId: i.user.id },
          ],
        },
      });

      // Create match
      const pair = orderPair(i.user.id, targetUser.id);
      const expires = new Date(Date.now() + LIMITS.optInHours * 3_600_000);
      const match = await db.match.create({
        data: { guildId, ...pair, status: MatchStatus.PENDING_OPT_IN, optInExpiresAt: expires },
      });

      // Create mutual swipes
      await db.swipe.upsert({
        where: { guildId_fromUserId_toUserId: { guildId, fromUserId: i.user.id, toUserId: targetUser.id } },
        create: { guildId, fromUserId: i.user.id, toUserId: targetUser.id, action: "LIKE" },
        update: { action: "LIKE" },
      });
      await db.swipe.upsert({
        where: { guildId_fromUserId_toUserId: { guildId, fromUserId: targetUser.id, toUserId: i.user.id } },
        create: { guildId, fromUserId: targetUser.id, toUserId: i.user.id, action: "LIKE" },
        update: { action: "LIKE" },
      });

      // Announce match via DM
      await announceMatch(i.client, match.id);

      await i.editReply({
        components: [
          notice({
            color: COLOR.gold,
            title: "🎉 Match lập tức!",
            body: `Thật vi diệu! **${them.displayName}** cũng đã đặt bạn làm Crush ẩn danh từ trước. Bot đã tạo match và gửi DM riêng cho cả hai.`,
            footer: "Hãy kiểm tra hộp thư DM nhé!",
          }),
        ],
        flags: V2,
      });
      return;
    }

    // Normal crush added -> Send hint notification to targetUser
    const common = me.tags.filter((t) => them.tags.includes(t));
    let hint = "";
    if (common.length > 0) {
      const tagSpecs = common.map((t) => {
        const spec = TAGS.find((tag) => tag.key === t);
        return spec ? `${spec.emoji} ${spec.label}` : t;
      });
      hint = `Gợi ý: Người này có những sở thích chung: ${tagSpecs.join(", ")}`;
    } else {
      hint = `Gợi ý: Người này có độ tuổi ${me.age} và mong muốn kết đôi trùng khớp với bạn.`;
    }

    const targetMember = await i.client.users.fetch(targetUser.id).catch(() => null);
    if (targetMember) {
      await sendDM(targetMember, {
        components: [
          notice({
            color: COLOR.rose,
            title: "❤️ Ai đó đã thêm bạn làm Crush ẩn danh!",
            body: `Một thành viên trong server vừa đặt bạn làm Crush ẩn danh.\n\n${hint}`,
            footer: "Hãy sử dụng lệnh /explore để lướt và thích lại họ nhé!",
          }),
        ],
        flags: V2,
      });
    }

    await i.editReply({
      components: [
        notice({
          color: COLOR.mint,
          title: "🤫 Đã gửi tình cảm ẩn danh",
          body: `Đã thêm **${them.displayName}** vào danh sách Crush và gửi gợi ý ẩn danh đến họ.\nNếu họ cũng đặt bạn làm Crush ẩn danh, bot sẽ tạo Match ngay lập tức.`,
        }),
      ],
      flags: V2,
    });
  }
  else if (sub === "remove") {
    const targetUser = i.options.getUser("user", true);
    const deleted = await db.secretCrush.deleteMany({
      where: { guildId, fromUserId: i.user.id, toUserId: targetUser.id },
    });

    if (deleted.count > 0) {
      await i.editReply({
        components: [
          notice({
            color: COLOR.mint,
            title: "Đã gỡ Crush",
            body: `Đã xóa thành viên khỏi danh sách Crush ẩn danh của bạn.`,
          }),
        ],
        flags: V2,
      });
    } else {
      await i.editReply({
        components: [
          notice({
            color: COLOR.slate,
            title: "Không tìm thấy",
            body: `Thành viên này không nằm trong danh sách Crush của bạn.`,
          }),
        ],
        flags: V2,
      });
    }
  }
  else if (sub === "list") {
    const crushes = await db.secretCrush.findMany({
      where: { guildId, fromUserId: i.user.id },
    });

    if (crushes.length === 0) {
      await i.editReply({
        components: [
          notice({
            color: COLOR.slate,
            title: "Chưa có Crush ẩn danh",
            body: "Bạn chưa đặt ai làm Crush ẩn danh cả. Hãy dùng `/crush add` để bắt đầu.",
          }),
        ],
        flags: V2,
      });
      return;
    }

    const lines = [];
    for (const c of crushes) {
      const p = await getProfile(guildId, c.toUserId);
      lines.push(`- **${p?.displayName ?? `<@${c.toUserId}>`}** (Thêm vào ${timeAgo(c.createdAt)})`);
    }

    await i.editReply({
      components: [
        notice({
          color: COLOR.rose,
          title: `Danh sách Crush ẩn danh (${crushes.length}/3)`,
          body: lines.join("\n"),
          footer: "Nếu đối phương đặt bạn làm Crush ẩn danh, hai bạn sẽ Match ngay.",
        }),
      ],
      flags: V2,
    });
  }
}

// ─────────────────────────────────────────────────────────────────────────
// /custom — Cho phép Father/Cupid tuỳ chỉnh icon giao diện bot theo guild
// ─────────────────────────────────────────────────────────────────────────

async function customCommand(i: ChatInputCommandInteraction, guildId: string): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });

  if (!i.guild) {
    await i.editReply({ components: [notice({ color: COLOR.crimson, title: "Lỗi", body: "Lệnh này chỉ dùng được trong server." })], flags: V2 });
    return;
  }

  const { authorityOf } = await import("../features/admin/permissions.js");
  const auth = await authorityOf(i.guild, i.user.id);
  if (!auth.isFather && auth.rank !== "cupid") {
    await i.editReply({
      components: [notice({ color: COLOR.crimson, title: "Không có quyền", body: "Chỉ Father hoặc Cupid mới chỉnh sửa được icon." })],
      flags: V2,
    });
    return;
  }

  await showGlyphPanel(i, guildId, false);
}

async function showGlyphPanel(
  i: ChatInputCommandInteraction | StringSelectMenuInteraction | ButtonInteraction,
  guildId: string,
  update: boolean
): Promise<void> {
  const cfg = await getGlyphConfig(guildId);

  const parseEmoji = (emojiStr: string): string | { id: string } => {
    const match = emojiStr.match(/<a?:[a-zA-Z0-9_]+:([0-9]+)>/);
    return match ? { id: match[1] ?? "" } : emojiStr;
  };

  const options = (Object.entries(CUSTOMIZABLE_GLYPHS) as [string, { label: string; description: string }][]).map(
    ([key, info]) => {
      const current = cfg.get(key) ?? GLYPH[key as keyof typeof GLYPH] ?? "";
      const opt = new StringSelectMenuOptionBuilder()
        .setValue(key)
        .setLabel(info.label)
        .setDescription(info.description);

      try {
        opt.setEmoji(parseEmoji(current));
      } catch {
        // Fallback
      }
      return opt;
    }
  );

  const selectRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(ID.customGlyphList())
      .setPlaceholder("Chọn icon muốn thay đổi...")
      .addOptions(options)
  );

  const card = notice({
    color: COLOR.violet,
    title: "Tuỳ chỉnh icon giao diện bot",
    body: "Chọn 1 icon từ danh sách để thay bằng emoji khác.\nBot sẽ áp dụng cho toàn bộ giao diện của server này.",
    footer: "Cả emoji Unicode và emoji server đều được hỗ trợ.",
  });

  if (update) {
    await (i as StringSelectMenuInteraction | ButtonInteraction).update({ components: [card, selectRow as any], flags: V2 });
  } else {
    await (i as ChatInputCommandInteraction).editReply({ components: [card, selectRow as any], flags: V2 });
  }
}

async function showEmojiPicker(
  i: StringSelectMenuInteraction | ButtonInteraction | ModalSubmitInteraction,
  guildId: string,
  key: string,
  page: number = 0,
  searchQuery: string = ""
): Promise<void> {
  const cfg = await getGlyphConfig(guildId);
  const current = cfg.get(key) ?? GLYPH[key as keyof typeof GLYPH];
  const info = CUSTOMIZABLE_GLYPHS[key as keyof typeof CUSTOMIZABLE_GLYPHS];
  if (!info) return;

  const guild = i.guild;
  const allServerEmojis = guild ? [...(await guild.emojis.fetch()).values()] : [];

  const filteredEmojis = searchQuery
    ? allServerEmojis.filter(e => e.name?.toLowerCase().includes(searchQuery.toLowerCase()))
    : allServerEmojis;

  const SUGGESTED: Record<string, string[]> = {
    like: ["💗", "❤️", "💖", "💝", "🩷", "💘"],
    pass: ["❌", "⛔", "🚫", "👎", "💨"],
    superLike: ["⭐", "🌟", "✨", "💫", "🏆", "👑"],
    report: ["🚩", "⚠️", "🔴", "🛑"],
    chat: ["💬", "🗨️", "📩", "💌", "👋"],
    edit: ["📝", "✏️", "🖊️"],
    photo: ["🖼", "📷", "🎨"],
    sparkle: ["✨", "🌈", "🎉", "💫", "🌟"],
  };

  const unicodeOptions = (!searchQuery && page === 0)
    ? (SUGGESTED[key] ?? []).map(e =>
      new StringSelectMenuOptionBuilder()
        .setValue(e)
        .setLabel("Unicode")
        .setEmoji(e)
        .setDefault(e === current)
    )
    : [];

  const pageSize = 20;
  const totalPages = Math.max(1, Math.ceil(filteredEmojis.length / pageSize));
  const normalizedPage = Math.max(0, Math.min(page, totalPages - 1));
  const startIdx = normalizedPage * pageSize;
  const pageEmojis = filteredEmojis.slice(startIdx, startIdx + pageSize);

  const serverEmojiOptions = pageEmojis.map(e =>
    new StringSelectMenuOptionBuilder()
      .setValue(`<:${e.name}:${e.id}>`)
      .setLabel(`:${e.name}:`)
      .setEmoji(e.id)
  );

  const allOptions = [...unicodeOptions, ...serverEmojiOptions].slice(0, 25);
  if (!allOptions.length) {
    allOptions.push(
      new StringSelectMenuOptionBuilder()
        .setValue("__none__")
        .setLabel("(Không tìm thấy emoji phù hợp)")
        .setDefault(true)
    );
  }

  const selectRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(ID.customGlyphPick(key))
      .setPlaceholder("Chọn emoji thay thế...")
      .addOptions(allOptions)
  );

  const buttons: ButtonBuilder[] = [];

  if (normalizedPage > 0) {
    buttons.push(
      new ButtonBuilder()
        .setCustomId(`d|cgp_page|${key}|${normalizedPage - 1}|${searchQuery}`)
        .setLabel("Trang trước")
        .setEmoji("◀")
        .setStyle(ButtonStyle.Secondary)
    );
  }

  if (totalPages > 1) {
    buttons.push(
      new ButtonBuilder()
        .setCustomId("d|noop")
        .setLabel(`Trang ${normalizedPage + 1}/${totalPages}`)
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true)
    );
  }

  if (normalizedPage < totalPages - 1) {
    buttons.push(
      new ButtonBuilder()
        .setCustomId(`d|cgp_page|${key}|${normalizedPage + 1}|${searchQuery}`)
        .setLabel("Trang sau")
        .setEmoji("▶")
        .setStyle(ButtonStyle.Secondary)
    );
  }

  buttons.push(
    new ButtonBuilder()
      .setCustomId(`d|cgp_search|${key}`)
      .setLabel("Tìm kiếm")
      .setEmoji("🔍")
      .setStyle(ButtonStyle.Primary)
  );

  if (searchQuery) {
    buttons.push(
      new ButtonBuilder()
        .setCustomId(`d|cgp_clear|${key}`)
        .setLabel("Xem tất cả")
        .setStyle(ButtonStyle.Secondary)
    );
  }

  buttons.push(
    new ButtonBuilder()
      .setCustomId(ID.customGlyphReset(key))
      .setLabel("Đặt lại")
      .setStyle(ButtonStyle.Danger)
  );

  const buttonRows: ActionRowBuilder<ButtonBuilder>[] = [];
  for (let currentStart = 0; currentStart < buttons.length; currentStart += 5) {
    buttonRows.push(
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        ...buttons.slice(currentStart, currentStart + 5)
      )
    );
  }

  const searchStatusText = searchQuery ? `Kết quả tìm kiếm cho: '${searchQuery}'\n` : "";

  const card = notice({
    color: COLOR.gold,
    title: `Thay đổi icon: ${info.label}`,
    body: `${searchStatusText}Hiện tại: **${current}**\nHãy chọn một emoji mới từ menu bên dưới.`,
    footer: "Emoji từ server cần đảm bảo bot có quyền sử dụng.",
  });

  const components = [card, selectRow as any, ...buttonRows];
  if (i.isRepliable()) {
    if (i.replied || i.deferred) {
      await i.editReply({ components, flags: V2 });
    } else if ("update" in i) {
      await (i as any).update({ components, flags: V2 });
    } else {
      await i.reply({ components, flags: V2E });
    }
  }
}

async function showCustomGlyphSearchModal(i: ButtonInteraction, key: string): Promise<void> {
  const modal = new ModalBuilder()
    .setCustomId(`d|cgs_submit|${key}`)
    .setTitle("Tìm kiếm Emoji trong Server")
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("query")
          .setLabel("Nhập tên emoji cần tìm")
          .setPlaceholder("Ví dụ: heart, ...")
          .setStyle(TextInputStyle.Short)
          .setMaxLength(30)
          .setRequired(true)
      )
    );
  await i.showModal(modal);
}

async function handleCustomGlyphPick(i: StringSelectMenuInteraction, guildId: string, key: string): Promise<void> {
  const chosen = i.values[0];
  if (!chosen || chosen === "__none__") return void (await i.deferUpdate());

  await setGlyph(guildId, key, chosen);
  const info = CUSTOMIZABLE_GLYPHS[key as keyof typeof CUSTOMIZABLE_GLYPHS];

  await i.update({
    components: [
      notice({
        color: COLOR.mint,
        title: `Đã cập nhật icon: ${info?.label ?? key}`,
        body: `Icon mới: **${chosen}**\nThay đổi sẽ áp dụng ngay cho toàn bộ giao diện server.`,
        buttons: [
          new ButtonBuilder()
            .setCustomId(ID.customGlyphList())
            .setLabel("Chỉnh sửa icon khác")
            .setStyle(ButtonStyle.Secondary),
        ],
      }),
    ],
    flags: V2,
  });
}

async function handleCustomGlyphReset(i: ButtonInteraction, guildId: string, key: string): Promise<void> {
  await resetGlyph(guildId, key);
  const info = CUSTOMIZABLE_GLYPHS[key as keyof typeof CUSTOMIZABLE_GLYPHS];
  const defaultVal = GLYPH[key as keyof typeof GLYPH];

  await i.update({
    components: [
      notice({
        color: COLOR.slate,
        title: `Đã đặt lại icon: ${info?.label ?? key}`,
        body: `Icon mặc định: **${defaultVal}**`,
        buttons: [
          new ButtonBuilder()
            .setCustomId(ID.customGlyphList())
            .setLabel("Chỉnh sửa icon khác")
            .setStyle(ButtonStyle.Secondary),
        ],
      }),
    ],
    flags: V2,
  });
}

// ─────────────────────────────────────────────────────────────────────────
// /help — Xem danh sách các lệnh và hướng dẫn sử dụng
// ─────────────────────────────────────────────────────────────────────────

async function helpCommand(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });

  const commandList = [
    "**CÁC LỆNH HẸN HÒ CHO THÀNH VIÊN**",
    "`/profile setup` - Thiết lập hoặc chỉnh sửa hồ sơ (Basics, Prompts, mạng xã hội, sở thích...).",
    "`/profile view` - Xem hiển thị hồ sơ cá nhân hiện tại.",
    "`/profile pause` - Tạm thời ẩn hồ sơ (sẽ không xuất hiện khi người khác lướt).",
    "`/profile resume` - Kích hoạt lại hiển thị hồ sơ để tiếp tục hẹn hò.",
    "`/profile delete` - Xóa vĩnh viễn toàn bộ hồ sơ hẹn hò khỏi cơ sở dữ liệu.",
    "`/explore` - Bắt đầu lướt tìm kiếm các mảnh ghép phù hợp trong server.",
    "`/matches` - Xem danh sách phòng chat, các lời mời chờ duyệt, hoặc trạng thái chờ.",
    "`/crush` - Thiết lập hoặc quản lý người thương ẩn danh.",
    "`/quiz` - Kích hoạt minigame Trắc nghiệm Duyên số ngay tại thread chat.",
    "`/destiny` - Rút quẻ Tarot Duyên Phận tìm mảnh ghép ăn ý nhất hôm nay.",
    "`/superlikes` - Xem số lượng Super Like mà bạn đang sở hữu."
  ];

  const card = notice({
    color: COLOR.rose,
    title: "Dating Bot Help",
    body: commandList.join("\n"),
  });
  await i.editReply({ components: [card], flags: V2 });
}

// ─────────────────────────────────────────────────────────────────────────
// /cupidhelp — Xem danh sách các lệnh quản trị và cấu hình
// ─────────────────────────────────────────────────────────────────────────

async function cupidHelpCommand(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });

  const { authorityOf } = await import("../features/admin/permissions.js");
  const auth = await authorityOf(i.guild!, i.user.id);
  if (!auth.isFather && auth.rank !== "cupid") {
    await i.editReply({
      components: [
        notice({
          color: COLOR.crimson,
          title: "Không có quyền",
          body: "Bạn cần có quyền Cupid hoặc Father để xem danh sách lệnh dành cho Mod/Admin.",
        }),
      ],
      flags: V2,
    });
    return;
  }

  const commandList = [
    "**CÁC LỆNH DÀNH CHO MOD / ADMIN (CUPID & FATHER)**",
    "`/cupid status` - Xem cấu hình và số liệu thống kê lượt quẹt của server.",
    "`/cupid give` - Cấp hoặc thu hồi Super Like cho người dùng.",
    "`/cupid balance` - Xem số dư Super Like hiện tại của người dùng.",
    "`/cupid reports` - Hiển thị danh sách các báo cáo vi phạm đang chờ xử lý.",
    "`/cupid resolve` - Giải quyết (đóng hoặc bỏ qua báo cáo vi phạm.",
    "`/cupid ban` - Quản trị viên cấm một tài khoản khỏi hệ thống.",
    "`/cupid unban` - Hủy bỏ lệnh cấm cho tài khoản.",
    "`/custom` - Tùy chỉnh icon giao diện hiển thị của bot cho server.",
    "`/cupidform` - Bổ nhiệm nhanh một người làm Cupid với đầy đủ các quyền (chỉ Father).",
    "`/father promote` - Tiến cử một thành viên làm Father quản trị (chỉ Father).",
    "`/father demote` - Gỡ bỏ quyền quản trị Father (chỉ Father).",
    "`/father reset-swipes` - Thiết lập lại số lượt thích hàng ngày (chỉ Father)."
  ];

  const card = notice({
    color: COLOR.violet,
    title: "Cupid & Father Help",
    body: commandList.join("\n"),
  });
  await i.editReply({ components: [card], flags: V2 });
}
