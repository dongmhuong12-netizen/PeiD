import {
  ActionRowBuilder,
  ContainerBuilder,
  MessageFlags,
  PermissionFlagsBits,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  TextDisplayBuilder,
  type ChatInputCommandInteraction,
  type Role,
  type StringSelectMenuInteraction,
  type TextChannel,
} from "discord.js";
import { CupidPermission, ProfileStatus, ReportStatus } from "@prisma/client";
import { db } from "../db.js";
import { LIMITS } from "../limits.js";
import { ID } from "../lib/ids.js";
import { notice } from "../ui/profileCard.js";
import { COLOR, GLYPH, sub } from "../ui/theme.js";
import { getGlyphConfig } from "../features/glyphConfig.js";
import { reasonLabel } from "../features/reportReasons.js";
import {
  ALL_PERMISSIONS,
  PERMISSION_HINT,
  PERMISSION_LABEL,
  RANK_LABEL,
  authorityOf,
  demoteFather,
  listStaff,
  makeFullCupid,
  promoteFather,
  setCupidPermissions,
} from "../features/admin/permissions.js";
import {
  getBalance,
  giveSuperLikes,
  grantsByStaff,
  recentGrants,
} from "../features/admin/superlikes.js";
import { CUPID_REQUIRED } from "../features/admin/cupidCommands.js";
import {
  banProfile,
  openReports,
  resetUserSwipes,
  resolveReports,
  unbanProfile,
} from "../features/admin/moderation.js";

const V2 = MessageFlags.IsComponentsV2;
const V2E = MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral;

const text = (s: string) => new TextDisplayBuilder().setContent(s);

const nope = (msg: string) => ({
  components: [notice({ color: COLOR.crimson, title: "Không đủ quyền", body: msg })],
  flags: V2E,
});
const bad = (msg: string) => ({
  components: [notice({ color: COLOR.crimson, title: "Không được", body: msg })],
  flags: V2E,
});
const done = (title: string, body?: string, footer?: string) => ({
  components: [notice({ color: COLOR.mint, title, body, footer })],
  flags: V2E,
});

// ─────────────────────────────────────────────────────────────────────────
// /father — chi Father
// ─────────────────────────────────────────────────────────────────────────

export async function handleFather(i: ChatInputCommandInteraction): Promise<void> {
  if (!i.inGuild() || !i.guild) {
    await i.reply({ content: "Chỉ dùng trong server.", flags: MessageFlags.Ephemeral });
    return;
  }

  const auth = await authorityOf(i.guild, i.user.id);
  if (!auth.isFather) {
    await i.reply(
      nope(
        auth.rank === "cupid"
          ? "Lệnh này chỉ dành cho Father. Bạn là Cupid — dùng `/cupid`."
          : "Lệnh này chỉ dành cho Father. Chủ server luôn là Father và có thể phong cho bạn."
      )
    );
    return;
  }

  switch (i.options.getSubcommand()) {
    case "setup":
      return setup(i);
    case "promote":
      return promote(i);
    case "demote":
      return demote(i);
    case "cupid":
      return cupidPicker(i);
    case "staff":
      return staff(i);
    case "audit":
      return audit(i);
    case "reset-swipes":
      return resetSwipes(i);
  }
}

/// Xoa lich su luot + match cua mot nguoi trong server nay -> ho (va nhung
/// nguoi lien quan) kham pha lai tu dau. Huu ich nhat khi test voi it tai
/// khoan: khong phai tao acc moi de luot lai.
///
/// KHONG dung toi Block (an toan, khong duoc xoa bang lenh test) va so du
/// Super Like (do admin cap, khong phai trang thai luot).
async function resetSwipes(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const target = i.options.getUser("user", true);
  const guildId = i.guildId!;

  const { swipes, matches } = await resetUserSwipes(guildId, target.id);

  await i.editReply({
    components: [
      notice({
        color: COLOR.mint,
        title: "Đã reset",
        body: `${target} — xoá **${swipes}** lượt lướt và **${matches}** match.`,
        footer:
          "Họ và những người liên quan sẽ khám phá lại nhau từ đầu. " +
          "Thread match cũ (nếu có) không bị xoá — dọn tay nếu cần.",
      }),
    ],
    flags: V2,
  });
}

/// /cupidform — loi tat cap/go toan bo quyen Cupid. Chi Father tro len.
///
/// Tach khoi /father lam lenh top-level rieng vi day la thao tac hay dung
/// nhat (bien mot mod thanh admin day du), dang le no mot lenh la tien.
export async function handleCupidForm(i: ChatInputCommandInteraction): Promise<void> {
  if (!i.inGuild() || !i.guild) {
    await i.reply({ content: "Chỉ dùng trong server.", flags: MessageFlags.Ephemeral });
    return;
  }

  const auth = await authorityOf(i.guild, i.user.id);
  if (!auth.isFather) {
    await i.reply(nope("Lệnh này chỉ dành cho Father."));
    return;
  }

  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const target = i.options.getUser("user", true);
  const remove = i.options.getBoolean("remove") ?? false;

  if (remove) {
    const res = await setCupidPermissions(i.guild, target.id, [], i.user.id);
    if (!res.ok) return void (await i.editReply(bad(res.error)));
    await i.editReply(done("Đã gỡ quyền", `${target} không còn quyền Cupid nào.`));
    return;
  }

  const res = await makeFullCupid(i.guild, target.id, i.user.id);
  if (!res.ok) return void (await i.editReply(bad(res.error)));

  await i.editReply(
    done(
      "Đã cấp toàn quyền Cupid",
      `${target} giờ dùng được mọi lệnh /cupid: cấp Super Like, xử lý báo cáo, cấm hồ sơ, xem số liệu.`,
      "Muốn cấp từng quyền lẻ thì dùng /father cupid. Gỡ: /cupidform remove:true."
    )
  );

  const glyphs = await getGlyphConfig(i.guild.id);
  const gp = (key: keyof typeof GLYPH) => glyphs.get(key) ?? GLYPH[key];

  await target
    .send({
      components: [
        notice({
          color: COLOR.mint,
          title: `${gp("sparkle")} Bạn được cấp quyền Cupid`,
          body: `Ở **${i.guild.name}**. Dùng /cupid để xem các lệnh quản trị.`,
        }),
      ],
      flags: V2,
    })
    .catch(() => { });
}

async function setup(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const guild = i.guild!;

  const role = i.options.getRole("verified-role", true) as Role;
  const lounge = i.options.getChannel("lounge", true) as TextChannel;
  const mod = i.options.getChannel("mod-channel", true) as TextChannel;
  const limit = i.options.getInteger("daily-swipes") ?? 15;

  const problems: string[] = [];

  // @everyone khong phai la mot cong. Chap nhan no thi toan bo lop phong ve
  // tuoi bien mat trong im lang — nguy hiem hon la khong co gi, vi admin se
  // tuong minh da bao ve.
  if (role.id === guild.id) {
    problems.push(
      "Không thể dùng `@everyone` làm role xác minh — như vậy là không có lớp bảo vệ nào."
    );
  }

  const me = await guild.members.fetchMe();

  // Tu cap cho bot cac quyen no can tren 2 kenh — admin khoi phai set tay.
  // Can bot co Manage Roles (Administrator la du). Tu cap that bai thi buoc
  // kiem ben duoi bat va bao admin.
  //
  // Vi sao PHAI co: Discord tinh cac quyen doc lap. Bot co the co SendMessages
  // nhung thieu ViewChannel -> luc gui report bi 50001 Missing Access (dung
  // loi da gap). Cap ca ViewChannel tranh cai bay do.
  let autoConfigured = true;
  try {
    await lounge.permissionOverwrites.edit(me.id, {
      ViewChannel: true,
      SendMessages: true,
      SendMessagesInThreads: true,
      CreatePrivateThreads: true,
      ManageThreads: true,
    });
    await mod.permissionOverwrites.edit(me.id, {
      ViewChannel: true,
      SendMessages: true,
    });
  } catch {
    autoConfigured = false;
  }

  const loungePerms = lounge.permissionsFor(me);
  if (!loungePerms?.has(PermissionFlagsBits.ViewChannel)) {
    problems.push(`Bot không **nhìn thấy** ${lounge} (thiếu View Channel).`);
  }
  if (!loungePerms?.has(PermissionFlagsBits.CreatePrivateThreads)) {
    problems.push(`Bot thiếu quyền **Create Private Threads** ở ${lounge}.`);
  }
  if (!loungePerms?.has(PermissionFlagsBits.SendMessagesInThreads)) {
    problems.push(`Bot thiếu quyền **Send Messages in Threads** ở ${lounge}.`);
  }
  if (!loungePerms?.has(PermissionFlagsBits.ManageThreads)) {
    problems.push(`Bot thiếu quyền **Manage Threads** ở ${lounge} (cần để dọn phòng cũ).`);
  }

  const modPerms = mod.permissionsFor(me);
  if (!modPerms?.has(PermissionFlagsBits.ViewChannel)) {
    problems.push(`Bot không **nhìn thấy** ${mod} — báo cáo sẽ không gửi được (lỗi Missing Access).`);
  }
  if (!modPerms?.has(PermissionFlagsBits.SendMessages)) {
    problems.push(`Bot không gửi được tin nhắn vào ${mod}.`);
  }

  // Thieu quyen ma tu cap that bai -> chi cho admin cach xu ly.
  if (problems.length && !autoConfigured) {
    problems.push(
      "_Bot không tự cấu hình được 2 kênh (thiếu Manage Roles). Cấp cho bot " +
      "quyền Manage Roles rồi chạy lại, hoặc tự thêm bot vào 2 kênh._"
    );
  }

  // Kenh mod ma @everyone doc duoc = report cong khai = khong ai dam report.
  if (mod.permissionsFor(guild.roles.everyone)?.has(PermissionFlagsBits.ViewChannel)) {
    problems.push(
      `${mod} đang cho @everyone xem được. Báo cáo chứa thông tin nhạy cảm — hãy dùng kênh riêng của mod.`
    );
  }

  if (problems.length) {
    await i.editReply({
      components: [
        notice({
          color: COLOR.crimson,
          title: "Chưa bật được",
          body: problems.map((p) => `• ${p}`).join("\n"),
          footer: "Sửa xong rồi chạy lại lệnh này.",
        }),
      ],
      flags: V2,
    });
    return;
  }

  await db.guildConfig.upsert({
    where: { guildId: guild.id },
    create: {
      guildId: guild.id,
      enabled: true,
      verifiedRoleId: role.id,
      loungeChannelId: lounge.id,
      modChannelId: mod.id,
      dailySwipeLimit: limit,
    },
    update: {
      enabled: true,
      verifiedRoleId: role.id,
      loungeChannelId: lounge.id,
      modChannelId: mod.id,
      dailySwipeLimit: limit,
    },
  });

  const glyphs = await getGlyphConfig(guild.id);
  const gp = (key: keyof typeof GLYPH) => glyphs.get(key) ?? GLYPH[key];

  await i.editReply({
    components: [
      notice({
        color: COLOR.mint,
        title: `${gp("sparkle")} Đã bật`,
        body: [
          `**Role xác minh:** ${role}`,
          `**Phòng match:** ${lounge}`,
          `**Kênh báo cáo:** ${mod}`,
          `**Trần lướt/ngày:** ${limit} (tự co giãn theo số người trong server)`,
        ].join("\n"),
        footer:
          `Chỉ người có ${role.name} dùng được bot. Việc xác minh 18+ và cấp role là ` +
          `trách nhiệm của bạn — bot không tự xác minh tuổi được.\n` +
          `Cấp quyền cho mod bằng /father cupid.`,
      }),
    ],
    flags: V2,
  });
}

async function promote(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const target = i.options.getUser("user", true);

  const res = await promoteFather(i.guild!, target.id, i.user.id);
  if (!res.ok) return void (await i.editReply(bad(res.error)));

  await i.editReply(
    done(
      "Đã phong Father",
      `${target} giờ có **toàn quyền**: sửa cấu hình, phong Father khác, cấp quyền Cupid.`,
      "Father không tự gỡ quyền của mình được — phải nhờ một Father khác."
    )
  );
}

async function demote(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const target = i.options.getUser("user", true);

  const res = await demoteFather(i.guild!, target.id, i.user.id);
  if (!res.ok) return void (await i.editReply(bad(res.error)));

  await i.editReply(done("Đã gỡ quyền Father", `${target} không còn quyền quản trị nào.`));
}

/// Bang chon quyen Cupid.
///
/// Dung select menu chu khong phai 4 option boolean trong slash command:
/// select cho thay ca danh sach quyen kem mo ta, va tich san nhung quyen ho
/// dang co — nen Father thay duoc trang thai hien tai truoc khi doi.
async function cupidPicker(i: ChatInputCommandInteraction): Promise<void> {
  const target = i.options.getUser("user", true);
  const guild = i.guild!;

  const auth = await authorityOf(guild, target.id);
  if (auth.rank === "owner") return void (await i.reply(bad("Chủ server đã có toàn quyền.")));
  if (auth.rank === "father") {
    return void (await i.reply(bad("Người này là Father — đã có toàn quyền sẵn.")));
  }
  if (target.bot) return void (await i.reply(bad("Không thể cấp quyền cho bot.")));

  const current = new Set(auth.permissions);

  const c = new ContainerBuilder().setAccentColor(COLOR.rose);
  c.addTextDisplayComponents(text(`### Quyền Cupid cho ${target.username}`));
  c.addTextDisplayComponents(
    text(
      current.size
        ? `Đang có **${current.size}** quyền. Chọn lại để thay đổi.`
        : "Người này chưa có quyền nào. Chọn những quyền muốn cấp."
    )
  );
  c.addTextDisplayComponents(
    text(sub("Bỏ chọn hết rồi lưu = thu hồi toàn bộ quyền Cupid."))
  );
  c.addActionRowComponents(
    new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(ID.cupidPerms(target.id))
        .setPlaceholder("Chọn quyền")
        .setMinValues(0)
        .setMaxValues(ALL_PERMISSIONS.length)
        .addOptions(
          ALL_PERMISSIONS.map((p) =>
            new StringSelectMenuOptionBuilder()
              .setLabel(PERMISSION_LABEL[p])
              .setDescription(PERMISSION_HINT[p].slice(0, 100))
              .setValue(p)
              .setDefault(current.has(p))
          )
        )
    )
  );

  await i.reply({ components: [c], flags: V2E });
}

/// Xu ly select menu quyen Cupid. Goi tu router.
export async function handleCupidPermsSelect(i: StringSelectMenuInteraction, targetId: string) {
  if (!i.guild) return;

  // Kiem tra quyen LAI o day. Nut duoc gui cho mot Father, nhung customId
  // nam trong message — va message ephemeral van co the bi phat lai neu ai
  // do lay duoc id. Khong bao gio tin rang nguoi bam la nguoi da duoc gui.
  const auth = await authorityOf(i.guild, i.user.id);
  if (!auth.isFather) return void (await i.reply(nope("Chỉ Father cấp được quyền Cupid.")));

  const perms = i.values.filter((v): v is CupidPermission =>
    (ALL_PERMISSIONS as string[]).includes(v)
  );

  const res = await setCupidPermissions(i.guild, targetId, perms, i.user.id);
  if (!res.ok) return void (await i.update(bad(res.error)));

  await i.update({
    components: [
      notice({
        color: perms.length ? COLOR.mint : COLOR.slate,
        title: perms.length ? "Đã cấp quyền Cupid" : "Đã thu hồi quyền Cupid",
        body: perms.length
          ? `<@${targetId}> giờ có thể:\n` +
          perms.map((p) => `• ${PERMISSION_LABEL[p]}`).join("\n")
          : `<@${targetId}> không còn quyền quản trị nào.`,
        footer: perms.length ? "Họ dùng /cupid để thao tác." : undefined,
      }),
    ],
    flags: V2,
  });
}

async function staff(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const { ownerId, fathers, cupids } = await listStaff(i.guild!);

  const lines = [`**Chủ server** — toàn quyền, không gỡ được`, `<@${ownerId}>`, ""];

  lines.push(`**Father** — toàn quyền  (${fathers.length})`);
  lines.push(fathers.length ? fathers.map((f) => `<@${f.userId}>`).join("  ") : "_chưa có ai_");
  lines.push("");

  lines.push(`**Cupid** — quyền được cấp  (${cupids.length})`);
  if (cupids.length) {
    for (const c of cupids) {
      lines.push(
        `<@${c.userId}> — ${c.permissions.map((p) => PERMISSION_LABEL[p]).join(", ")}`
      );
    }
  } else {
    lines.push("_chưa có ai_");
  }

  await i.editReply({
    components: [
      notice({
        color: COLOR.slate,
        title: "Nhân sự",
        body: lines.join("\n").slice(0, 3800),
        footer: "Cấp quyền: /father cupid  ·  Phong Father: /father promote",
      }),
    ],
    flags: V2,
  });
}

async function audit(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const guildId = i.guildId!;

  const [recent, byStaff] = await Promise.all([
    recentGrants(guildId, 15),
    grantsByStaff(guildId, 30),
  ]);

  if (!recent.length) {
    await i.editReply({
      components: [
        notice({
          color: COLOR.slate,
          title: "Chưa có ai cấp Super Like",
          footer: "Cấp bằng /cupid give.",
        }),
      ],
      flags: V2,
    });
    return;
  }

  const staffLines = byStaff.map(
    (s) => `<@${s.byUserId}> — **${s._sum.amount ?? 0}** qua ${s._count._all} lần`
  );

  const recentLines = recent.map((g) => {
    const when = `<t:${Math.floor(g.createdAt.getTime() / 1000)}:R>`;
    const amt = g.amount > 0 ? `+${g.amount}` : `${g.amount}`;
    return `${when} · <@${g.byUserId}> → <@${g.toUserId}> **${amt}**${g.reason ? ` — ${g.reason}` : ""}`;
  });

  await i.editReply({
    components: [
      notice({
        color: COLOR.slate,
        title: "Nhật ký cấp Super Like",
        body:
          `**Theo người cấp (30 ngày qua)**\n${staffLines.join("\n")}\n\n` +
          `**Gần đây**\n${recentLines.join("\n")}`.slice(0, 3800),
        footer:
          "Super Like được tạo ra từ hư không bởi một con người. Đây là cách duy nhất " +
          "phát hiện một Cupid đang cấp quá tay.",
      }),
    ],
    flags: V2,
  });
}

// ─────────────────────────────────────────────────────────────────────────
// /cupid — Cupid va Father. Moi lenh doi mot quyen cu the.
// ─────────────────────────────────────────────────────────────────────────


export async function handleCupid(i: ChatInputCommandInteraction): Promise<void> {
  if (!i.inGuild() || !i.guild) {
    await i.reply({ content: "Chỉ dùng trong server.", flags: MessageFlags.Ephemeral });
    return;
  }

  const cmd = i.options.getSubcommand();
  const need = CUPID_REQUIRED[cmd];
  if (!need) return;

  const auth = await authorityOf(i.guild, i.user.id);
  if (!auth.permissions.includes(need)) {
    await i.reply(
      nope(
        auth.rank === "none"
          ? "Bạn không có quyền quản trị. Nhờ Father cấp bằng `/father cupid`."
          : `Bạn là ${RANK_LABEL[auth.rank]} nhưng chưa được cấp quyền **${PERMISSION_LABEL[need]}**.`
      )
    );
    return;
  }

  switch (cmd) {
    case "give":
      return give(i);
    case "balance":
      return balance(i);
    case "reports":
      return reports(i);
    case "resolve":
      return resolve(i);
    case "ban":
      return ban(i);
    case "unban":
      return unban(i);
    case "status":
      return status(i);
  }
}

async function give(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const target = i.options.getUser("user", true);
  const amount = i.options.getInteger("amount", true);
  const reason = i.options.getString("reason");

  if (target.bot) return void (await i.editReply((bad("Không thể cấp cho bot."))));

  // Ho so khong bat buoc: co the cap truoc roi ho tao ho so sau. So du van
  // nam do cho. Chan o day chi lam admin phai canh me thoi diem.

  const res = await giveSuperLikes({
    guildId: i.guildId!,
    byUserId: i.user.id,
    toUserId: target.id,
    amount,
    reason,
  });
  if (!res.ok) return void (await i.editReply(bad(res.error)));

  const glyphs = await getGlyphConfig(i.guildId!);
  const gp = (key: keyof typeof GLYPH) => glyphs.get(key) ?? GLYPH[key];

  await i.editReply(
    done(
      res.delta > 0
        ? `${gp("superLike")} Đã cấp ${res.delta} Super Like`
        : `Đã thu hồi ${-res.delta}`,
      `${target} — số dư giờ là **${res.balance}**.`,
      "Đã ghi vào nhật ký. Father xem được bằng /father audit."
    )
  );

  // Bao cho nguoi nhan. That bai (tat DM) thi thoi — ho van thay o /superlikes.
  if (res.delta > 0) {
    await target
      .send({
        components: [
          notice({
            color: COLOR.violet,
            title: `${gp("superLike")} Bạn nhận được ${res.delta} Super Like`,
            body: reason ? `> ${reason}` : undefined,
            footer: `Từ ${i.guild!.name}  ${GLYPH.dot}  số dư: ${res.balance}. Dùng khi lướt bằng /explore.`,
          }),
        ],
        flags: V2,
      })
      .catch(() => { });
  }
}

async function balance(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const target = i.options.getUser("user", true);
  const n = await getBalance(i.guildId!, target.id);

  const granted = await db.superLikeGrant.findMany({
    where: { guildId: i.guildId!, toUserId: target.id },
    orderBy: { createdAt: "desc" },
    take: 5,
  });

  await i.editReply({
    components: [
      notice({
        color: COLOR.violet,
        title: `${target.username} có ${n} Super Like`,
        body: granted.length
          ? "**Gần đây**\n" +
          granted
            .map(
              (g) =>
                `<t:${Math.floor(g.createdAt.getTime() / 1000)}:R> · <@${g.byUserId}> ` +
                `**${g.amount > 0 ? "+" : ""}${g.amount}**${g.reason ? ` — ${g.reason}` : ""}`
            )
            .join("\n")
          : "_Chưa từng được cấp lần nào._",
      }),
    ],
    flags: V2,
  });
}

async function reports(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const open = await openReports(i.guildId!, 10);

  if (!open.length) {
    await i.editReply({
      components: [
        notice({ color: COLOR.mint, title: "Không có báo cáo nào đang mở", footer: "Yên bình." }),
      ],
      flags: V2,
    });
    return;
  }

  // Gom theo nguoi bi to: 5 nguoi to cung mot nguoi la tin hieu khac han
  // 5 nguoi bi to moi nguoi mot lan.
  const byTarget = new Map<string, typeof open>();
  for (const r of open) {
    const arr = byTarget.get(r.reportedId) ?? [];
    arr.push(r);
    byTarget.set(r.reportedId, arr);
  }

  const lines: string[] = [];
  for (const [userId, rs] of byTarget) {
    const snap = rs[0]!.snapshot as { displayName?: string; age?: number } | null;
    lines.push(
      `**<@${userId}>** — ${snap?.displayName ?? "?"}, ${snap?.age ?? "?"}  ` +
      `${GLYPH.dot}  **${rs.length}** báo cáo`
    );
    for (const r of rs) {
      lines.push(
        `  ${GLYPH.dot} ${reasonLabel(r.reason)} — <@${r.reporterId}>` +
        (r.details ? `\n    _${r.details.slice(0, 120)}_` : "")
      );
    }
    lines.push("");
  }

  const glyphs = await getGlyphConfig(i.guildId!);
  const gp = (key: keyof typeof GLYPH) => glyphs.get(key) ?? GLYPH[key];

  await i.editReply({
    components: [
      notice({
        color: COLOR.crimson,
        title: `${gp("report")} ${open.length} báo cáo đang mở`,
        body: lines.join("\n").slice(0, 3800),
        footer:
          "Đóng bằng /cupid resolve. Chọn 'không có cơ sở' sẽ bỏ ẩn hồ sơ — " +
          "hồ sơ bị ẩn sẽ nằm ẩn mãi nếu không ai đóng báo cáo.",
      }),
    ],
    flags: V2,
  });
}

async function resolve(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const target = i.options.getUser("user", true);
  const action = i.options.getString("action", true) as "resolve" | "dismiss";

  const res = await resolveReports({
    guildId: i.guildId!,
    reportedId: target.id,
    action,
    byUserId: i.user.id,
  });
  if (!res.ok) return void (await i.editReply(bad(res.error)));

  await i.editReply(done("Đã xử lý", `${target} — ${res.note}`));
}

async function ban(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const target = i.options.getUser("user", true);

  const res = await banProfile({ guildId: i.guildId!, userId: target.id, byUserId: i.user.id });
  if (!res.ok) return void (await i.editReply(bad(res.error)));

  await i.editReply({
    components: [
      notice({
        color: COLOR.crimson,
        title: "Đã cấm hồ sơ",
        body: `${target} — ${res.note}`,
        footer: "Họ không tự bỏ cấm được bằng /profile resume. Bỏ cấm bằng /cupid unban.",
      }),
    ],
    flags: V2,
  });
}

async function unban(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const target = i.options.getUser("user", true);

  const res = await unbanProfile({ guildId: i.guildId!, userId: target.id });
  if (!res.ok) return void (await i.editReply(bad(res.error)));

  await i.editReply(done("Đã bỏ cấm", `${target} — ${res.note}`));
}

async function status(i: ChatInputCommandInteraction): Promise<void> {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  const guildId = i.guildId!;

  const cfg = await db.guildConfig.findUnique({ where: { guildId } });
  if (!cfg?.enabled) {
    await i.editReply({
      components: [
        notice({
          color: COLOR.slate,
          title: "Bot chưa được bật",
          footer: "Father chạy /father setup.",
        }),
      ],
      flags: V2,
    });
    return;
  }

  const [active, draft, review, banned, openR, matches, swipes24h, supers, likesCount, passesCount] = await Promise.all([
    db.profile.count({ where: { guildId, status: ProfileStatus.ACTIVE } }),
    db.profile.count({ where: { guildId, status: ProfileStatus.DRAFT } }),
    db.profile.count({ where: { guildId, status: ProfileStatus.UNDER_REVIEW } }),
    db.profile.count({ where: { guildId, status: ProfileStatus.BANNED } }),
    db.report.count({ where: { guildId, status: ReportStatus.OPEN } }),
    db.match.count({ where: { guildId } }),
    db.swipe.count({ where: { guildId, createdAt: { gte: new Date(Date.now() - 86_400_000) } } }),
    db.superLikeBalance.aggregate({ where: { guildId }, _sum: { amount: true } }),
    db.swipe.count({ where: { guildId, action: "LIKE" } }),
    db.swipe.count({ where: { guildId, action: "PASS" } }),
  ]);

  const totalSwipes = likesCount + passesCount;
  const likeRatioPct = totalSwipes > 0 ? Math.round((likesCount / totalSwipes) * 100) : 0;

  const needsAttention = review > 0 || openR > 0;

  await i.editReply({
    components: [
      notice({
        color: needsAttention ? COLOR.crimson : COLOR.slate,
        title: "Tình trạng",
        body: [
          `**Hồ sơ hoạt động:** ${active}`,
          `**Hồ sơ chưa xong:** ${draft}`,
          `**Chờ xem xét:** ${review}${review > 0 ? "  ⚠" : ""}`,
          `**Bị cấm:** ${banned}`,
          `**Báo cáo đang mở:** ${openR}${openR > 0 ? "  ⚠" : ""}`,
          `**Tổng match:** ${matches}`,
          `**Tỷ lệ thích (Like ratio):** ${likeRatioPct}% (${likesCount} thích / ${passesCount} bỏ qua)`,
          `**Lượt lướt 24h qua:** ${swipes24h}`,
          `**Super Like đang lưu hành:** ${supers._sum.amount ?? 0}`,
          "",
          `**Role xác minh:** <@&${cfg.verifiedRoleId}>`,
          `**Phòng match:** <#${cfg.loungeChannelId}>`,
          `**Kênh báo cáo:** <#${cfg.modChannelId}>`,
          `**Trần lướt/ngày:** ${cfg.dailySwipeLimit}`,
        ].join("\n"),
        footer:
          active < LIMITS.minDailySwipes * 4
            ? `Dưới ${LIMITS.minDailySwipes * 4} hồ sơ thì trần lướt tự hạ xuống mức tối thiểu ` +
            `(${LIMITS.minDailySwipes}/ngày) — không đủ người để lướt.`
            : undefined,
      }),
    ],
    flags: V2,
  });
}
