import {
  Client,
  Events,
  GatewayIntentBits,
  Partials,
  Routes,
  type Client as DiscordClient,
  type Guild,
} from "discord.js";
import { config } from "./config.js";
import { db } from "./db.js";
import { logger } from "./lib/logger.js";
import { route } from "./interactions/router.js";
import { startJobs, trackThreadActivity } from "./jobs/maintenance.js";
import { commandJSON } from "./commands/definitions.js";

const log = logger("bot");

/// Tu dang ky slash command khi khoi dong va khi vao server moi.
///
/// Vi sao can: Railway chay `npm start` (con bot) chu KHONG chay
/// `npm run deploy`. Thieu buoc nay thi them/sua lenh xong, handler co tren
/// Railway nhung Discord van hien danh sach lenh cu -> lenh moi khong xuat
/// hien. Dang ky theo GUILD (khong phai global) de hien ra ngay lap tuc.
///
/// `put` thay toan bo tap lenh cua guild -> idempotent, chay lai bao nhieu
/// lan cung duoc.
async function registerGuildCommands(c: DiscordClient<true>, guildId: string): Promise<void> {
  try {
    await c.rest.put(Routes.applicationGuildCommands(c.user.id, guildId), {
      body: commandJSON,
    });
    log.info(`da dang ky ${commandJSON.length} lenh cho guild ${guildId}`);
  } catch (e) {
    log.error(`dang ky lenh that bai cho guild ${guildId}`, e);
  }
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    // Chi can de biet phong chat con song (jobs/maintenance.ts). KHONG can
    // MessageContent: MessageCreate van ban ra binh thuong, chi rieng truong
    // content la rong — ma ta khong doc no.
    //
    // Bo duoc MessageContent la mot cai loi that: no la privileged intent,
    // va tren 100 server thi phai xin Discord duyet tung cai.
    GatewayIntentBits.GuildMessages,
  ],
  // Nut opt-in match nam trong DM. Khong co partial nay thi discord.js bo
  // qua su kien tu kenh DM chua nam trong cache.
  partials: [Partials.Channel, Partials.Message],
});

client.once(Events.ClientReady, async (c) => {
  log.info(`dang nhap voi ten ${c.user.tag}`);
  log.info(`dang o ${c.guilds.cache.size} server`);
  // Dang ky lenh cho moi server dang o -> moi lan deploy code la lenh tu cap
  // nhat, khong phai chay `npm run deploy` tay nua.
  for (const guildId of c.guilds.cache.keys()) {
    await registerGuildCommands(c, guildId);
  }
  startJobs(c);
});

// Vao server moi -> dang ky lenh cho no luon.
client.on(Events.GuildCreate, (guild: Guild) => {
  if (guild.client.isReady()) void registerGuildCommands(guild.client, guild.id);
});

client.on(Events.InteractionCreate, (i) => void route(i));

trackThreadActivity(client);

client.on(Events.Error, (e) => log.error("loi client", e));
client.rest.on("rateLimited", (info) =>
  log.warn(`bi rate limit ${info.timeToReset}ms — ${info.route}`)
);

// Thoat sach: dong ket noi DB, dong gateway. Thieu doan nay thi moi lan
// restart se de lai ket noi Postgres treo cho den khi timeout.
async function shutdown(signal: string): Promise<void> {
  log.info(`nhan ${signal}, dang tat...`);
  try {
    await client.destroy();
    await db.$disconnect();
  } finally {
    process.exit(0);
  }
}
process.on("SIGINT", () => void shutdown("SIGINT"));
process.on("SIGTERM", () => void shutdown("SIGTERM"));

process.on("unhandledRejection", (e) => log.error("promise chua bat loi", e));

await client.login(config.discord.token);
