import { ChannelType, PermissionFlagsBits, SlashCommandBuilder } from "discord.js";

/// ─── Ve viec KHONG dung setDefaultMemberPermissions ─────────────────────
///
/// Cach thong thuong la gan `.setDefaultMemberPermissions(ManageGuild)` de
/// Discord tu an lenh admin. O day khong lam vay, vi:
///
///   1. Father/Cupid la he phan quyen RIENG cua bot, khong anh xa sang bat
///      ky quyen nao cua Discord. Mot Cupid co the la thanh vien thuong
///      khong co quyen Discord nao ca — gan ManageGuild se an lenh khoi mat
///      ho.
///   2. Nguoc lai, ai co ManageGuild cung KHONG duoc tu dong thanh Father.
///
/// Kiem tra quyen that nam trong interactions/admin.ts. Lenh hien ra voi moi
/// nguoi nhung tu choi nguoi khong co quyen — danh doi co y: mot dong "bạn
/// không có quyền" ro rang hon la mot lenh bien mat khong ly do.

export const commands = [
  new SlashCommandBuilder()
    .setName("profile")
    .setDescription("Hồ sơ hẹn hò của bạn")
    .addSubcommand((s) => s.setName("setup").setDescription("Tạo hoặc sửa hồ sơ"))
    .addSubcommand((s) => s.setName("view").setDescription("Xem hồ sơ của bạn"))
    .addSubcommand((s) =>
      s.setName("pause").setDescription("Tạm ẩn hồ sơ — không ai thấy bạn nữa")
    )
    .addSubcommand((s) => s.setName("resume").setDescription("Hiện lại hồ sơ"))
    .addSubcommand((s) => s.setName("delete").setDescription("Xoá hồ sơ vĩnh viễn")),

  new SlashCommandBuilder().setName("explore").setDescription("Bắt đầu lướt hồ sơ"),

  // Loi tat: bien mot nguoi thanh Cupid voi TOAN BO quyen trong mot lenh.
  // Chi Father tro len dung duoc. Muon cap tung quyen le thi dung /father cupid.
  new SlashCommandBuilder()
    .setName("cupidform")
    .setDescription("Biến một người thành Cupid với toàn quyền (chỉ Father)")
    .setContexts(0)
    .addUserOption((o) =>
      o.setName("user").setDescription("Người được cấp quyền").setRequired(true)
    )
    .addBooleanOption((o) =>
      o
        .setName("remove")
        .setDescription("Bật để gỡ toàn bộ quyền Cupid thay vì cấp")
    ),

  new SlashCommandBuilder().setName("matches").setDescription("Xem các match của bạn"),

  new SlashCommandBuilder()
    .setName("custom")
    .setDescription("Tuỳ chỉnh biểu tượng giao diện bot cho server này (chỉ Father/Cupid)"),

  new SlashCommandBuilder()
    .setName("superlikes")
    .setDescription("Xem số Super Like của bạn"),

  new SlashCommandBuilder()
    .setName("destiny")
    .setDescription("Rút quẻ bói Duyên Phận hàng ngày để tìm người tương hợp nhất hôm nay"),

  new SlashCommandBuilder()
    .setName("help")
    .setDescription("Xem danh sách các lệnh và hướng dẫn sử dụng"),

  new SlashCommandBuilder()
    .setName("cupidhelp")
    .setDescription("Xem hướng dẫn sử dụng các lệnh cho Mod và Admin (Cupid/Father)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setContexts(0),


  new SlashCommandBuilder()
    .setName("crush")
    .setDescription("Quản lý Crush ẩn danh của bạn")
    .addSubcommand((s) =>
      s
        .setName("add")
        .setDescription("Thêm một thành viên làm Crush ẩn danh (tối đa 3 người)")
        .addUserOption((o) => o.setName("user").setDescription("Thành viên bạn crush").setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName("remove")
        .setDescription("Bỏ Crush ẩn danh với một thành viên")
        .addUserOption((o) => o.setName("user").setDescription("Thành viên muốn bỏ").setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName("list")
        .setDescription("Xem danh sách các Crush ẩn danh của bạn")
    ),

  new SlashCommandBuilder()
    .setName("quiz")
    .setDescription("Bắt đầu minigame Quiz trắc nghiệm ăn ý trong phòng chat (chỉ dùng trong phòng Match)"),

  // ───────────────────────────────────────────────────────────────────────
  // /father — chi Father. Cau hinh + nhan su. Khong uy quyen duoc.
  // ───────────────────────────────────────────────────────────────────────
  new SlashCommandBuilder()
    .setName("father")
    .setDescription("Quản trị cấp cao (chỉ Father)")
    .setContexts(0)
    .addSubcommand((s) =>
      s
        .setName("setup")
        .setDescription("Bật bot cho server này")
        .addRoleOption((o) =>
          o
            .setName("verified-role")
            .setDescription("Role bắt buộc để dùng bot — bạn tự cấp cho thành viên 18+")
            .setRequired(true)
        )
        .addChannelOption((o) =>
          o
            .setName("lounge")
            .setDescription("Kênh chứa các phòng riêng sau khi match")
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)
        )
        .addChannelOption((o) =>
          o
            .setName("mod-channel")
            .setDescription("Kênh nhận báo cáo — nên là kênh riêng của mod")
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)
        )
        .addIntegerOption((o) =>
          o
            .setName("daily-swipes")
            .setDescription("Trần lượt lướt mỗi ngày (mặc định 15)")
            .setMinValue(5)
            .setMaxValue(30)
        )
    )
    .addSubcommand((s) =>
      s
        .setName("promote")
        .setDescription("Phong một người làm Father — toàn quyền, không thu hồi được bởi chính họ")
        .addUserOption((o) => o.setName("user").setDescription("Người được phong").setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName("demote")
        .setDescription("Gỡ quyền Father của một người")
        .addUserOption((o) => o.setName("user").setDescription("Người bị gỡ").setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName("cupid")
        .setDescription("Cấp hoặc sửa quyền Cupid cho một người")
        .addUserOption((o) => o.setName("user").setDescription("Người được cấp").setRequired(true))
    )
    .addSubcommand((s) =>
      s.setName("staff").setDescription("Xem danh sách Father và Cupid")
    )
    .addSubcommand((s) =>
      s.setName("audit").setDescription("Nhật ký cấp Super Like — ai đã cấp cho ai")
    )
    .addSubcommand((s) =>
      s
        .setName("reset-swipes")
        .setDescription("Xoá lịch sử lướt & match của một người để họ khám phá lại từ đầu")
        .addUserOption((o) =>
          o.setName("user").setDescription("Người cần reset").setRequired(true)
        )
    ),

  // ───────────────────────────────────────────────────────────────────────
  // /cupid — Cupid (va Father). Moi lenh doi mot quyen cu the.
  // ───────────────────────────────────────────────────────────────────────
  new SlashCommandBuilder()
    .setName("cupid")
    .setDescription("Công cụ quản trị (Cupid / Father)")
    .setContexts(0)
    .addSubcommand((s) =>
      s
        .setName("give")
        .setDescription("Cấp Super Like cho một người")
        .addUserOption((o) => o.setName("user").setDescription("Người nhận").setRequired(true))
        .addIntegerOption((o) =>
          o
            .setName("amount")
            .setDescription("Số lượng. Số âm để thu hồi.")
            .setMinValue(-50)
            .setMaxValue(50)
            .setRequired(true)
        )
        .addStringOption((o) =>
          o.setName("reason").setDescription("Lý do — hiện trong nhật ký").setMaxLength(200)
        )
    )
    .addSubcommand((s) =>
      s
        .setName("balance")
        .setDescription("Xem số Super Like của một người")
        .addUserOption((o) => o.setName("user").setDescription("Người cần xem").setRequired(true))
    )
    .addSubcommand((s) => s.setName("reports").setDescription("Xem các báo cáo đang mở"))
    .addSubcommand((s) =>
      s
        .setName("resolve")
        .setDescription("Đóng báo cáo về một người")
        .addUserOption((o) =>
          o.setName("user").setDescription("Người bị báo cáo").setRequired(true)
        )
        .addStringOption((o) =>
          o
            .setName("action")
            .setDescription("Kết luận")
            .setRequired(true)
            .addChoices(
              { name: "Có vi phạm — đã xử lý", value: "resolve" },
              { name: "Không có cơ sở — bỏ qua và bỏ ẩn hồ sơ", value: "dismiss" }
            )
        )
    )
    .addSubcommand((s) =>
      s
        .setName("ban")
        .setDescription("Cấm hồ sơ của một người")
        .addUserOption((o) => o.setName("user").setDescription("Người bị cấm").setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName("unban")
        .setDescription("Bỏ cấm hồ sơ của một người")
        .addUserOption((o) => o.setName("user").setDescription("Người được bỏ cấm").setRequired(true))
    )
    .addSubcommand((s) => s.setName("status").setDescription("Xem cấu hình và số liệu server")),
] as const;

export const commandJSON = commands.map((c) => c.toJSON());
