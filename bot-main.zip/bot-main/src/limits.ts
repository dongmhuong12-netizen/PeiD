/// Cac nguong dieu chinh duoc.
///
/// Tach khoi config.ts CO CHU DICH: config.ts validate .env va thoat chuong
/// trinh neu thieu bien. Nhung mot hang so nhu "bio dai toi da 300 ky tu"
/// khong lien quan gi den viec co DISCORD_TOKEN hay khong.
///
/// Gop chung lai thi khong the test logic thuan neu khong dung mot token
/// gia — va token gia trong repo la thu roi se co nguoi vo tinh commit.

export const LIMITS = {
  /// Tran cung, du admin dat cao hon.
  maxDailySwipes: 30,
  /// San: duoi muc nay thi gioi han swipe khong con y nghia, chi gay buc boi.
  minDailySwipes: 5,

  /// Match het han neu mot ben khong bam "Bat dau chat" trong khoang nay.
  optInHours: 48,
  /// Phong im lang qua lau -> tu dong khep.
  idleThreadHours: 72,

  /// So nguoi mot nguoi report duoc trong 24h. Chong di pha hang loat.
  /// Report KHONG tu khoa ho so ai — chi bao mod (xem safety.ts).
  reportsPerReporterPerDay: 5,

  superLikeNoteMaxLength: 100,
  bioMaxLength: 300,
  promptAnswerMaxLength: 150,

  /// Xoa profile DRAFT neu khong active sau tung nay ngay.
  draftProfileCleanupDays: 30,
} as const;

/// Tran swipe/ngay, co gian theo so nguoi thuc su ghep duoc.
///
/// Ly do phai co gian: "slow dating" chi co y nghia khi con nguoi de luot.
/// Server 40 nguoi ma tran 15/ngay -> user xem het pool sau 3 ngay, va tu
/// do tran swipe khong con han che gi ca, no chi lam phien. Nguoc lai server
/// 2000 nguoi thi 15 luot/ngay la con so co suc nang that.
///
/// Chia 4: tinh ra khoang mot tuan de xem het pool.
export function resolveSwipeLimit(poolSize: number, configured: number): number {
  const scaled = Math.floor(poolSize / 4);
  return Math.max(LIMITS.minDailySwipes, Math.min(configured, LIMITS.maxDailySwipes, scaled));
}
