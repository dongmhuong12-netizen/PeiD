import { SwipeAction, MatchStatus } from "@prisma/client";
import { db, isUniqueViolation, orderPair } from "../db.js";
import { LIMITS } from "../limits.js";

export type SwipeOutcome =
  | { kind: "recorded" }
  | { kind: "matched"; matchId: string; theirNote: string | null }
  | { kind: "duplicate" };

/// Chi con LIKE/PASS di qua recordSwipe. Super Like la item boost rieng
/// (sendSuperLike), khong phai mot huong swipe.
export type SwipeDecision = typeof SwipeAction.LIKE | typeof SwipeAction.PASS;

/// Ghi 1 luot swipe va phat hien match.
///
/// ─── Ve race condition ───────────────────────────────────────────────────
/// Kich ban: A va B bam Like nhau dung cung mot khoanh khac.
///
/// Cach lam SAI (va la cach ai cung viet dau tien) — boc ca hai buoc trong
/// 1 transaction:
///
///     tx: INSERT swipe(A->B);  SELECT swipe(B->A);   -- khong thay
///     tx: INSERT swipe(B->A);  SELECT swipe(A->B);   -- cung khong thay
///     -> ca hai commit, KHONG CO MATCH. Hai nguoi vinh vien mat nhau.
///
/// Ly do: o muc isolation READ COMMITTED (mac dinh cua Postgres), transaction
/// nay khong doc duoc dong chua commit cua transaction kia. Boc chung vao
/// transaction lam van de TE HON, khong phai tot hon.
///
/// Cach lam o day — INSERT va commit TRUOC, roi moi doc:
///
///     INSERT swipe(A->B) commit @ tA
///     SELECT swipe(B->A)  @ tA'  (tA' > tA)
///
/// Gia su tA < tB. Vi B doc sau khi B commit, ma tB > tA, nen B CHAC CHAN
/// nhin thay dong cua A. It nhat mot ben luon phat hien duoc match.
///
/// Neu ca hai cung phat hien (tA' > tB va tB' > tA), ca hai se cung tao
/// Match -> @@unique(guildId, userAId, userBId) chan ban sao, ben thua nhan
/// P2002 va doc lai ban ghi da co. Ket qua giong het nhau. Idempotent.
export async function recordSwipe(args: {
  guildId: string;
  fromUserId: string;
  toUserId: string;
  action: SwipeDecision;
}): Promise<SwipeOutcome> {
  const { guildId, fromUserId, toUserId, action } = args;

  // Buoc 1: ghi va commit.
  try {
    await db.swipe.create({ data: { guildId, fromUserId, toUserId, action } });
  } catch (err) {
    // Da swipe nguoi nay roi (double-click, hoac card cu).
    if (isUniqueViolation(err)) return { kind: "duplicate" };
    throw err;
  }

  if (action === SwipeAction.PASS) return { kind: "recorded" };

  // Buoc 2: gio moi doc. Xem chi tiet ly do o comment tren.
  const reciprocal = await db.swipe.findUnique({
    where: {
      guildId_fromUserId_toUserId: { guildId, fromUserId: toUserId, toUserId: fromUserId },
    },
  });

  if (!reciprocal || reciprocal.action === SwipeAction.PASS) {
    return { kind: "recorded" };
  }

  // Buoc 3: tao match. Unique constraint lo phan chong trung. Note (neu co)
  // lay tu super like ben kia da gui — de hien khi bao match.
  const pair = orderPair(fromUserId, toUserId);
  const expires = new Date(Date.now() + LIMITS.optInHours * 3_600_000);
  const theirNote = await superLikeNoteFrom(guildId, toUserId, fromUserId);

  try {
    const match = await db.match.create({
      data: { guildId, ...pair, status: MatchStatus.PENDING_OPT_IN, optInExpiresAt: expires },
    });
    return { kind: "matched", matchId: match.id, theirNote };
  } catch (err) {
    if (isUniqueViolation(err)) {
      const existing = await db.match.findUnique({
        where: { guildId_userAId_userBId: { guildId, ...pair } },
      });
      if (existing) return { kind: "matched", matchId: existing.id, theirNote };
    }
    throw err;
  }
}

async function superLikeNoteFrom(
  guildId: string,
  fromUserId: string,
  toUserId: string
): Promise<string | null> {
  const sl = await db.superLikeSent.findUnique({
    where: { guildId_fromUserId_toUserId: { guildId, fromUserId, toUserId } },
  });
  return sl?.note ?? null;
}

// ─────────────────────────────────────────────────────────────────────────
// Super Like — item boost, tach roi khoi swipe
// ─────────────────────────────────────────────────────────────────────────

export type SuperLikeOutcome =
  | { kind: "sent" }
  | { kind: "no_balance" }
  | { kind: "already_sent" };

/// Gui Super Like (item boost) toi mot nguoi. KHONG ghi swipe — nguoi gui
/// van Thich/Bo qua nguoi kia sau do nhu binh thuong.
export async function sendSuperLike(args: {
  guildId: string;
  fromUserId: string;
  toUserId: string;
  note?: string | null;
}): Promise<SuperLikeOutcome> {
  const { guildId, fromUserId, toUserId } = args;
  const note = args.note?.trim().slice(0, LIMITS.superLikeNoteMaxLength) || null;

  // Tru so du atomic (dieu kien amount>=1 trong WHERE, khong doc-roi-ghi).
  const spent = await db.superLikeBalance.updateMany({
    where: { guildId, userId: fromUserId, amount: { gte: 1 } },
    data: { amount: { decrement: 1 } },
  });
  if (spent.count === 0) return { kind: "no_balance" };

  try {
    await db.superLikeSent.create({ data: { guildId, fromUserId, toUserId, note } });
    return { kind: "sent" };
  } catch (err) {
    if (isUniqueViolation(err)) {
      // Da super like nguoi nay roi -> hoan lai so du (khong tieu 2 lan).
      await db.superLikeBalance
        .update({
          where: { guildId_userId: { guildId, userId: fromUserId } },
          data: { amount: { increment: 1 } },
        })
        .catch(() => {});
      return { kind: "already_sent" };
    }
    throw err;
  }
}

/// Da super like nguoi nay chua? (de disable nut + hien "da super like").
export async function hasSuperLiked(
  guildId: string,
  fromUserId: string,
  toUserId: string
): Promise<boolean> {
  const sl = await db.superLikeSent.findUnique({
    where: { guildId_fromUserId_toUserId: { guildId, fromUserId, toUserId } },
  });
  return sl !== null;
}

/// So du Super Like theo tung server.
///
/// Truoc day so du la toan cuc (mua bang OwO cash thi tieu o dau cung duoc).
/// Gio Super Like do admin CUA MOT SERVER cap, nen no chi co gia tri o server
/// do — server khac dau co cho gi ma tieu.
export { getBalance as getSuperLikes } from "./admin/superlikes.js";
