import type { ModalSubmitInteraction } from "discord.js";
import { Gender, ProfileStatus, SocialPlatform } from "@prisma/client";
import { db } from "../db.js";
import { validatePhoto } from "./photo.js";
import { isValidPromptKey, REQUIRED_PROMPTS } from "./prompts.js";
import { parseSocial } from "./socials.js";
import type { FullProfile } from "../ui/profileCard.js";

export const MIN_AGE = 18;
export const MAX_AGE = 99;

export type SubmitResult = { ok: true } | { ok: false; error: string };

/// Nhung thu con thieu de profile duoc bat len ACTIVE.
/// Tra ve chuoi doc duoc cho user, khong phai ma loi.
export function missingFields(p: FullProfile): string[] {
  const out: string[] = [];
  if (!p.photoUrl) out.push("Chưa có ảnh đại diện");
  if (p.prompts.length < REQUIRED_PROMPTS) {
    out.push(`Cần trả lời ${REQUIRED_PROMPTS} câu hỏi (mới có ${p.prompts.length})`);
  }
  if (p.seeking.length === 0) out.push("Chưa chọn đối tượng muốn tìm");
  if (!p.consentAt) out.push("Chưa xác nhận điều khoản");
  return out;
}

/// Bat/tat trang thai ACTIVE theo do hoan chinh.
/// KHONG dung den profile dang UNDER_REVIEW hay BANNED — sua profile khong
/// duoc phep la duong thoat khoi lenh cam cua mod.
export async function syncStatus(profileId: string): Promise<void> {
  const p = await db.profile.findUnique({
    where: { id: profileId },
    include: { prompts: true, socials: true },
  });
  if (!p) return;
  if (p.status === ProfileStatus.UNDER_REVIEW || p.status === ProfileStatus.BANNED) return;
  if (p.status === ProfileStatus.PAUSED) return;

  const next = missingFields(p).length === 0 ? ProfileStatus.ACTIVE : ProfileStatus.DRAFT;
  if (p.status !== next) {
    await db.profile.update({ where: { id: profileId }, data: { status: next } });
  }
}

export async function handleBasics(
  i: ModalSubmitInteraction,
  guildId: string
): Promise<SubmitResult> {
  const name = i.fields.getTextInputValue("name").trim();
  const ageRaw = i.fields.getTextInputValue("age").trim();
  const gender = i.fields.getStringSelectValues("gender")[0];
  const seeking = i.fields.getStringSelectValues("seeking");

  const age = Number.parseInt(ageRaw, 10);
  if (!Number.isInteger(age)) return { ok: false, error: "Tuổi phải là số." };
  if (age < MIN_AGE) {
    return {
      ok: false,
      error:
        `Bot này chỉ dành cho người từ ${MIN_AGE} tuổi trở lên.\n` +
        "Đây là giới hạn cứng, không có ngoại lệ.",
    };
  }
  if (age > MAX_AGE) return { ok: false, error: "Tuổi không hợp lệ." };

  if (!gender || !(gender in Gender)) return { ok: false, error: "Giới tính không hợp lệ." };
  const seek = seeking.filter((s): s is Gender => s in Gender);
  if (seek.length === 0) return { ok: false, error: "Chọn ít nhất một đối tượng." };

  // Anh: khong bat buoc khi sua, bat buoc khi tao moi.
  // getUploadedFiles tra ve Collection cua discord.js, khong phai mang.
  let photoUrl: string | undefined;
  const file = i.fields.getUploadedFiles("photo")?.first();
  if (file) {
    const res = validatePhoto(file);
    if (!res.ok) return { ok: false, error: res.error };
    photoUrl = res.url;
  }

  const existing = await db.profile.findUnique({
    where: { guildId_userId: { guildId, userId: i.user.id } },
  });

  if (!existing && !photoUrl) {
    return { ok: false, error: "Cần một ảnh đại diện để tạo hồ sơ." };
  }

  const profile = await db.profile.upsert({
    where: { guildId_userId: { guildId, userId: i.user.id } },
    create: {
      guildId,
      userId: i.user.id,
      displayName: name,
      age,
      gender: gender as Gender,
      seeking: seek,
      photoUrl,
      // Dien form tuc la da doc dong "chi danh cho 18+" tren o Tuoi.
      consentAt: new Date(),
      lastActiveAt: new Date(),
    },
    update: {
      displayName: name,
      age,
      gender: gender as Gender,
      seeking: seek,
      ...(photoUrl ? { photoUrl } : {}),
      consentAt: existing?.consentAt ?? new Date(),
      lastActiveAt: new Date(),
    },
  });

  await syncStatus(profile.id);
  return { ok: true };
}

export async function handlePrompts(
  i: ModalSubmitInteraction,
  guildId: string
): Promise<SubmitResult> {
  const profile = await db.profile.findUnique({
    where: { guildId_userId: { guildId, userId: i.user.id } },
  });
  if (!profile) return { ok: false, error: "Bạn chưa có hồ sơ. Dùng /profile setup trước." };

  const picked: { key: string; answer: string }[] = [];
  for (let n = 0; n < REQUIRED_PROMPTS; n++) {
    const key = i.fields.getStringSelectValues(`prompt${n}`)[0];
    const answer = i.fields.getTextInputValue(`answer${n}`).trim();
    if (!key || !isValidPromptKey(key)) return { ok: false, error: "Câu hỏi không hợp lệ." };
    if (!answer) return { ok: false, error: "Chưa trả lời đủ." };
    if (picked.some((p) => p.key === key)) {
      return { ok: false, error: "Chọn hai câu hỏi khác nhau nhé." };
    }
    picked.push({ key, answer });
  }

  const bio = i.fields.getTextInputValue("bio")?.trim() || null;

  // Ghi de toan bo: xoa het roi tao lai. Don gian hon dieu chinh tung cai,
  // va tranh sot lai prompt cu khi user doi cau hoi.
  await db.$transaction([
    db.promptAnswer.deleteMany({ where: { profileId: profile.id } }),
    db.promptAnswer.createMany({
      data: picked.map((p, idx) => ({
        profileId: profile.id,
        promptKey: p.key,
        answer: p.answer,
        position: idx,
      })),
    }),
    db.profile.update({
      where: { id: profile.id },
      data: { bio, lastActiveAt: new Date() },
    }),
  ]);

  await syncStatus(profile.id);
  return { ok: true };
}

export async function handlePrefs(
  i: ModalSubmitInteraction,
  guildId: string
): Promise<SubmitResult> {
  const seeking = i.fields.getStringSelectValues("seeking").filter((s): s is Gender => s in Gender);
  const min = Number.parseInt(i.fields.getTextInputValue("min").trim(), 10);
  const max = Number.parseInt(i.fields.getTextInputValue("max").trim(), 10);

  if (seeking.length === 0) return { ok: false, error: "Chọn ít nhất một đối tượng." };
  if (!Number.isInteger(min) || !Number.isInteger(max)) {
    return { ok: false, error: "Tuổi phải là số." };
  }
  // Chan cung o 18: khong the dat bo loc de tim nguoi duoi tuoi, ke ca khi
  // ho khai gian tuoi khi dang ky.
  if (min < MIN_AGE) return { ok: false, error: `Tuổi tối thiểu không thể dưới ${MIN_AGE}.` };
  if (max > MAX_AGE) return { ok: false, error: "Tuổi tối đa không hợp lệ." };
  if (min > max) return { ok: false, error: "Tuổi tối thiểu phải nhỏ hơn tuổi tối đa." };

  const res = await db.profile.updateMany({
    where: { guildId, userId: i.user.id },
    data: { seeking, seekAgeMin: min, seekAgeMax: max, lastActiveAt: new Date() },
  });
  if (res.count === 0) return { ok: false, error: "Bạn chưa có hồ sơ." };
  return { ok: true };
}

export async function handleSocial(
  i: ModalSubmitInteraction,
  guildId: string,
  platform: string
): Promise<SubmitResult> {
  if (!(platform in SocialPlatform)) return { ok: false, error: "Nền tảng không hợp lệ." };

  const profile = await db.profile.findUnique({
    where: { guildId_userId: { guildId, userId: i.user.id } },
  });
  if (!profile) return { ok: false, error: "Bạn chưa có hồ sơ." };

  const raw = i.fields.getTextInputValue("value").trim();

  // De trong = go link.
  if (!raw) {
    await db.socialLink.deleteMany({
      where: { profileId: profile.id, platform: platform as SocialPlatform },
    });
    return { ok: true };
  }

  const parsed = parseSocial(platform, raw);
  if (!parsed.ok) return { ok: false, error: parsed.error };

  await db.socialLink.upsert({
    where: {
      profileId_platform: { profileId: profile.id, platform: platform as SocialPlatform },
    },
    create: {
      profileId: profile.id,
      platform: platform as SocialPlatform,
      value: parsed.handle,
    },
    update: { value: parsed.handle },
  });

  return { ok: true };
}
