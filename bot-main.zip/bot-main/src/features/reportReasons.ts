/// Danh sach ly do report — du lieu thuan, khong dung database.
///
/// Tach khoi safety.ts vi ui/modals.ts can danh sach nay de dung modal.
/// De chung thi import mot cai modal se keo theo ca ket noi Postgres.

export interface ReportReason {
  key: string;
  label: string;
  /// An profile NGAY tu report dau tien, khong doi du nguong.
  severe?: boolean;
}

export const REPORT_REASONS: readonly ReportReason[] = [
  {
    key: "minor",
    label: "Nghi ngờ dưới 18 tuổi",
    // An ngay tu 1 report. Chi phi hai chieu khong he can bang: de sot mot
    // nguoi duoi tuoi tren app hen ho la thiet hai khong sua duoc; an nham
    // mot nguoi lon trong mot tieng cho mod duyet thi sua duoc trong mot nut
    // bam. Khi mot ben nang hon ben kia nhieu den vay, chon ben nhe.
    severe: true,
  },
  { key: "fake", label: "Profile giả / ảnh không phải của họ" },
  { key: "nsfw", label: "Ảnh hoặc nội dung phản cảm" },
  { key: "harassment", label: "Quấy rối, xúc phạm" },
  { key: "spam", label: "Spam, quảng cáo, bán hàng" },
  { key: "other", label: "Khác" },
] as const;

const BY_KEY = new Map(REPORT_REASONS.map((r) => [r.key, r]));

export function getReason(key: string): ReportReason | undefined {
  return BY_KEY.get(key);
}

export function reasonLabel(key: string): string {
  return BY_KEY.get(key)?.label ?? key;
}
