/// Danh sach prompt co san.
///
/// Ly do khong dung o "Bio" trong tron: ~95% user se de trong hoac go
/// "hỏi đi". Prompt co san cho user mot cho bat dau cu the, va cau tra loi
/// tu no da la ice-breaker cho nguoi luot. Hinge dung cach nay va ty le
/// hoan thanh profile cao hon han.
///
/// key KHONG duoc doi sau khi da co user tra loi (no la khoa trong DB).
/// Muon sua chu -> doi `text`, giu nguyen `key`.

export interface Prompt {
  key: string;
  text: string;
}

export const PROMPTS: readonly Prompt[] = [
  { key: "cook_worst", text: "Món tôi nấu dở nhất là..." },
  { key: "weekend", text: "Cuối tuần lý tưởng của tôi là..." },
  { key: "irrational", text: "Nỗi sợ vô lý nhất của tôi..." },
  { key: "rant", text: "Chủ đề tôi có thể nói liên tục 2 tiếng..." },
  { key: "green_flag", text: "Green flag tôi để ý đầu tiên ở người khác..." },
  { key: "3am", text: "3 giờ sáng bạn sẽ thấy tôi đang..." },
  { key: "convince", text: "Cho tôi 30 giây để thuyết phục bạn rằng..." },
  { key: "guilty", text: "Sở thích tôi hơi ngại thừa nhận..." },
  { key: "last_search", text: "Thứ gần nhất tôi google lúc 2h sáng..." },
  { key: "game", text: "Game/phim/nhạc tôi sẽ bắt bạn thử cho bằng được..." },
  { key: "unpopular", text: "Quan điểm không được lòng ai của tôi..." },
  { key: "perfect_date", text: "Buổi hẹn đầu hoàn hảo với tôi là..." },
] as const;

const BY_KEY = new Map(PROMPTS.map((p) => [p.key, p]));

export function getPrompt(key: string): Prompt | undefined {
  return BY_KEY.get(key);
}

export function isValidPromptKey(key: string): boolean {
  return BY_KEY.has(key);
}

/// So prompt user phai tra loi de profile duoc coi la hoan chinh.
export const REQUIRED_PROMPTS = 2;
/// Toi da hien thi tren card. Nhieu hon nua thi card dai qua, nguoi luot
/// se khong doc.
export const MAX_PROMPTS = 3;
