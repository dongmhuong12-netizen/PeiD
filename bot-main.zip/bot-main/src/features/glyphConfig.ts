import { db } from "../db.js";
import { GLYPH } from "../ui/theme.js";

export type GlyphKey = keyof typeof GLYPH;

// dot la ky tu text thuan tuy, khong phai emoji — khong cho custom.
export type CustomizableGlyphKey = Exclude<GlyphKey, "dot">;

/// Danh sach cac icon co the tuy chinh.
export const CUSTOMIZABLE_GLYPHS: Record<CustomizableGlyphKey, { label: string; description: string }> = {
    like: { label: "Thich", description: "Nut quet Thich khi luot ho so" },
    pass: { label: "Bo qua", description: "Nut quet Bo qua khi luot ho so" },
    superLike: { label: "Super Like", description: "Bieu tuong Super Like" },
    report: { label: "Bao cao", description: "Nut bao cao ho so vi pham" },
    chat: { label: "Chat", description: "Nut Bat dau chat / Vao Chat" },
    edit: { label: "Chinh sua", description: "Nut chinh sua ho so" },
    photo: { label: "Anh", description: "Nhan anh ho so" },
    sparkle: { label: "Noi bat", description: "Bieu tuong Match / tua sang" },
};

// Cache theo guildId de tranh query DB moi khi hien thi.
const cache = new Map<string, Map<string, string>>();

/// Lay tat ca glyph override cho 1 guild, dung cache.
export async function getGlyphConfig(guildId: string): Promise<Map<string, string>> {
    if (cache.has(guildId)) return cache.get(guildId)!;

    const rows = await db.guildGlyphOverride.findMany({ where: { guildId } });
    const map = new Map<string, string>(rows.map((r): [string, string] => [r.key, r.value]));
    cache.set(guildId, map);
    return map;
}

/// Lay gia tri dong bo sau khi da co cache.
export function getGlyphSync(config: Map<string, string>, key: GlyphKey): string {
    return config.get(key) ?? GLYPH[key];
}

/// Luu 1 glyph override cho guild, cap nhat cache.
export async function setGlyph(guildId: string, key: string, value: string): Promise<void> {
    await db.guildGlyphOverride.upsert({
        where: { guildId_key: { guildId, key } },
        create: { guildId, key, value },
        update: { value },
    });

    const cfg = cache.get(guildId) ?? new Map<string, string>();
    cfg.set(key, value);
    cache.set(guildId, cfg);
}

/// Reset 1 glyph ve mac dinh.
export async function resetGlyph(guildId: string, key: string): Promise<void> {
    await db.guildGlyphOverride.deleteMany({ where: { guildId, key } }).catch(() => { });
    const cfg = cache.get(guildId);
    if (cfg) cfg.delete(key);
}

/// Xoa cache de force reload lan sau.
export function invalidateGlyphCache(guildId: string): void {
    cache.delete(guildId);
}
