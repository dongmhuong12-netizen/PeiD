import { CupidPermission } from "@prisma/client";
import type { Guild } from "discord.js";
import { db } from "../../db.js";
import { config } from "../../config.js";

/// ─── Mo hinh phan quyen ─────────────────────────────────────────────────
///
///   Chu server  →  luon la Father, khong ai go duoc
///        │
///   Father      →  toan quyen. Phong Father khac, cap quyen cho Cupid.
///        │
///   Cupid       →  chi lam duoc dung nhung gi Father cap cho.
///
/// ─── Vi sao luu theo userId chu khong dung role ─────────────────────────
///
/// Cach hien nhien la tao role @Father va @Cupid roi check role. Cach do
/// HONG, vi Discord da co san mot he phan quyen chay song song: bat ky ai co
/// quyen "Manage Roles" deu tu gan role cho chinh minh duoc.
///
/// Tuc la mot mod quyen thap co the tu bien minh thanh Father trong hai cu
/// bam, va toan bo phan tang nay chi con la trang tri.
///
/// Luu theo userId trong DB thi duong duy nhat de thanh Father la duoc mot
/// Father khac phong.
///
/// ─── Neo tin cay ────────────────────────────────────────────────────────
///
/// Father dau tien tu dau ra? Chu server. Quyen so huu la du kien cua
/// Discord — khong tu cap duoc, khong gia mao duoc. Moi quyen luc trong bot
/// deu truy nguoc ve day.
///
/// Vi vay chu server la Father NGAM DINH: khong co dong nao trong DB, va
/// khong ai go duoc ho. Neu go duoc thi mot server co the roi vao trang thai
/// khong con ai quan tri — khong sua duoc bang chinh bot.
///
/// ─── Dev toan cuc (tren ca chu server) ──────────────────────────────────
///
/// config.devUserId: mot ID co dinh luon co toan quyen o MOI server. Quyen
/// nay den tu phep so sanh cung ngay dau authorityOf, KHONG tu bang nao —
/// nen khong lenh nao trong bot go duoc no, va no co hieu luc du sang server
/// bat ky ma khong can setup gi.
///
/// ID nay khong bao gio duoc lo: no o .env (gitignore), khong o source; va
/// moi ham quan ly nhan su o duoi deu doi xu voi no y het mot Father binh
/// thuong (khong co thong bao rieng nao lam lo rang no dac biet), dong thoi
/// chan no lot vao bang FatherGrant de khoi hien ra trong /father staff.
export function isDevUser(userId: string): boolean {
  return config.devUserId !== undefined && userId === config.devUserId;
}

// Metadata quyen (thuan) song o cupidCommands.ts de selftest dung duoc ma
// khong keo theo db. Re-export de noi khac chi import tu mot cho.
export {
  ALL_PERMISSIONS,
  PERMISSION_LABEL,
  PERMISSION_HINT,
} from "./cupidCommands.js";
import { ALL_PERMISSIONS } from "./cupidCommands.js";

export type Rank = "dev" | "owner" | "father" | "cupid" | "none";

export interface Authority {
  rank: Rank;
  /// Quyen thuc te. Dev/Father/owner luon co du.
  permissions: CupidPermission[];
  /// Chi Father tro len moi sua duoc cau hinh va quan ly nhan su.
  isFather: boolean;
}

/// Doc quyen thuc te cua mot nguoi trong server.
///
/// Nhan `guild` chu khong nhan `guildId`: can doc ownerId, va khong duoc
/// phep tin vao mot ownerId do noi khac truyen vao.
export async function authorityOf(guild: Guild, userId: string): Promise<Authority> {
  // Dev toan cuc dung truoc moi thu — khong phu thuoc guild, khong doc DB.
  if (isDevUser(userId)) {
    return { rank: "dev", permissions: [...ALL_PERMISSIONS], isFather: true };
  }

  if (guild.ownerId === userId) {
    return { rank: "owner", permissions: [...ALL_PERMISSIONS], isFather: true };
  }

  const father = await db.fatherGrant.findUnique({
    where: { guildId_userId: { guildId: guild.id, userId } },
  });
  if (father) {
    return { rank: "father", permissions: [...ALL_PERMISSIONS], isFather: true };
  }

  const cupid = await db.cupidGrant.findUnique({
    where: { guildId_userId: { guildId: guild.id, userId } },
  });
  if (cupid && cupid.permissions.length > 0) {
    return { rank: "cupid", permissions: cupid.permissions, isFather: false };
  }

  return { rank: "none", permissions: [], isFather: false };
}

export async function isFather(guild: Guild, userId: string): Promise<boolean> {
  return (await authorityOf(guild, userId)).isFather;
}

export async function hasPermission(
  guild: Guild,
  userId: string,
  perm: CupidPermission
): Promise<boolean> {
  return (await authorityOf(guild, userId)).permissions.includes(perm);
}

export const RANK_LABEL: Record<Rank, string> = {
  // Dev co du quyen nen nhan nay thuc te khong bao gio hien trong nhanh
  // "ban la X nhung thieu quyen Y". Van dat de Record day du khoa.
  dev: "Dev",
  owner: "Chủ server",
  father: "Father",
  cupid: "Cupid",
  none: "Không có quyền",
};

// ─────────────────────────────────────────────────────────────────────────
// Quan ly nhan su — chi Father goi duoc. Ham o day KHONG tu kiem tra quyen;
// tang goi (interactions/admin.ts) phai chan truoc.
// ─────────────────────────────────────────────────────────────────────────

export type GrantResult =
  | { ok: true }
  | { ok: false; error: string };

export async function promoteFather(
  guild: Guild,
  targetId: string,
  byUserId: string
): Promise<GrantResult> {
  if (targetId === guild.ownerId) {
    return { ok: false, error: "Chủ server đã là Father sẵn rồi." };
  }
  // Dev khong duoc lot vao bang FatherGrant — neu vao, no se hien trong
  // /father staff va lo ID. Tra ve dung thong bao nhu voi mot Father da co,
  // de khong ai doan duoc ID nay dac biet.
  if (isDevUser(targetId)) return { ok: false, error: "Người này đã là Father." };
  const bot = guild.client.user?.id;
  if (targetId === bot) return { ok: false, error: "Không thể phong cho bot." };

  const existing = await db.fatherGrant.findUnique({
    where: { guildId_userId: { guildId: guild.id, userId: targetId } },
  });
  if (existing) return { ok: false, error: "Người này đã là Father." };

  // Len Father thi khong con la Cupid nua — Father co san toan quyen, giu
  // lai ban ghi Cupid chi lam roi trang thai.
  await db.$transaction([
    db.fatherGrant.create({
      data: { guildId: guild.id, userId: targetId, grantedBy: byUserId },
    }),
    db.cupidGrant.deleteMany({ where: { guildId: guild.id, userId: targetId } }),
  ]);
  return { ok: true };
}

export async function demoteFather(
  guild: Guild,
  targetId: string,
  byUserId: string
): Promise<GrantResult> {
  // Chu server la Father ngam dinh — khong co dong nao de xoa, va go duoc ho
  // thi server co the roi vao canh khong con ai quan tri.
  if (targetId === guild.ownerId) {
    return { ok: false, error: "Không thể gỡ quyền của chủ server." };
  }
  // Tu go chinh minh de lai mot server co the khong con Father nao. Bat ho
  // nho nguoi khac go — cham hon mot phut, doi lai khong bao gio khoa chet.
  if (targetId === byUserId) {
    return {
      ok: false,
      error: "Không thể tự gỡ quyền của mình. Nhờ một Father khác hoặc chủ server.",
    };
  }

  const res = await db.fatherGrant.deleteMany({
    where: { guildId: guild.id, userId: targetId },
  });
  if (res.count === 0) return { ok: false, error: "Người này không phải Father." };
  return { ok: true };
}

export async function setCupidPermissions(
  guild: Guild,
  targetId: string,
  permissions: CupidPermission[],
  byUserId: string
): Promise<GrantResult> {
  if (targetId === guild.ownerId) {
    return { ok: false, error: "Chủ server đã có toàn quyền." };
  }
  // Dev da co toan quyen — va khong duoc lot vao bang CupidGrant (se lo ID
  // trong /father staff). Thong bao giong het truong hop Father.
  if (isDevUser(targetId)) {
    return { ok: false, error: "Người này là Father — đã có toàn quyền sẵn." };
  }
  const bot = guild.client.user?.id;
  if (targetId === bot) return { ok: false, error: "Không thể cấp quyền cho bot." };

  const father = await db.fatherGrant.findUnique({
    where: { guildId_userId: { guildId: guild.id, userId: targetId } },
  });
  if (father) {
    return { ok: false, error: "Người này là Father — đã có toàn quyền sẵn." };
  }

  // Danh sach rong = thu hoi. Giu mot ban ghi khong quyen nao thi
  // authorityOf tra ve "none" nhung /father list van hien ho nhu Cupid —
  // gay hieu nham. Xoa han cho ro rang.
  if (permissions.length === 0) {
    await db.cupidGrant.deleteMany({ where: { guildId: guild.id, userId: targetId } });
    return { ok: true };
  }

  // Loc gia tri la — danh sach den tu select menu cua Discord, tuc la tu
  // client, tuc la khong duoc tin.
  const clean = [...new Set(permissions)].filter((p) => ALL_PERMISSIONS.includes(p));
  if (clean.length === 0) return { ok: false, error: "Quyền không hợp lệ." };

  await db.cupidGrant.upsert({
    where: { guildId_userId: { guildId: guild.id, userId: targetId } },
    create: {
      guildId: guild.id,
      userId: targetId,
      permissions: clean,
      grantedBy: byUserId,
    },
    update: { permissions: clean, grantedBy: byUserId },
  });
  return { ok: true };
}

export async function listStaff(guild: Guild) {
  const [fathers, cupids] = await Promise.all([
    db.fatherGrant.findMany({ where: { guildId: guild.id }, orderBy: { createdAt: "asc" } }),
    db.cupidGrant.findMany({ where: { guildId: guild.id }, orderBy: { createdAt: "asc" } }),
  ]);
  // Phong thu tang cuoi: cac guard o tren da chan dev vao bang, nhung neu
  // co du lieu cu tu truoc, van loc bo khoi danh sach de khong lo ID.
  return {
    ownerId: guild.ownerId,
    fathers: fathers.filter((f) => !isDevUser(f.userId)),
    cupids: cupids.filter((c) => !isDevUser(c.userId)),
  };
}

/// Cap toan bo quyen Cupid trong mot lenh (dung cho /cupidform).
export async function makeFullCupid(
  guild: Guild,
  targetId: string,
  byUserId: string
): Promise<GrantResult> {
  return setCupidPermissions(guild, targetId, [...ALL_PERMISSIONS], byUserId);
}
