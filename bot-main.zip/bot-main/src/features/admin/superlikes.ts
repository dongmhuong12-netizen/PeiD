import { db } from "../../db.js";

/// Cap / thu hoi Super Like bang tay.
///
/// Thay cho module OwO cu. Doi lai: khong con phai doan cau chu cua bot
/// khac, khong con be mat gia mao webhook, khong con vuong dieu khoan cua
/// ho, va khong con can intent MessageContent.
///
/// Danh doi: co nguoi that phai bam. Voi mot server thi day khong phai van
/// de — va no con la mot loi the: admin biet ai xung dang duoc cho, con mot
/// con bot doc log giao dich thi khong.

/// Tran mot lan cap. Khong phai vi 500 super like se lam hong gi — ma vi go
/// nham mot so 0 la chuyen xay ra that, va thu hoi sau khi nguoi ta da tieu
/// het thi khong thu hoi duoc.
export const MAX_GRANT_PER_CALL = 50;

export type GiveResult =
  | { ok: true; balance: number; delta: number }
  | { ok: false; error: string };

export async function giveSuperLikes(args: {
  guildId: string;
  byUserId: string;
  toUserId: string;
  amount: number;
  reason?: string | null;
}): Promise<GiveResult> {
  const { guildId, byUserId, toUserId } = args;
  const amount = Math.trunc(args.amount);

  if (!Number.isFinite(amount) || amount === 0) {
    return { ok: false, error: "Số lượng phải khác 0." };
  }
  if (Math.abs(amount) > MAX_GRANT_PER_CALL) {
    return {
      ok: false,
      error: `Tối đa ${MAX_GRANT_PER_CALL} mỗi lần. Cần nhiều hơn thì chạy lệnh vài lần.`,
    };
  }

  const current = await db.superLikeBalance.findUnique({
    where: { guildId_userId: { guildId, userId: toUserId } },
  });
  const before = current?.amount ?? 0;

  // Thu hoi nhieu hon so du -> ve 0, khong am. So du am se lam nguoi ta khong
  // dung duoc super like ke ca sau khi duoc cap lai, va khong ai hieu tai sao.
  const delta = amount < 0 ? -Math.min(before, -amount) : amount;
  if (delta === 0) {
    return { ok: false, error: "Người này không còn Super Like nào để thu hồi." };
  }

  // Ghi so du va nhat ky trong CUNG mot transaction. Tach ra thi mot lan
  // crash dung giua se de lai super like khong co nguon goc — dung thu ma
  // nhat ky sinh ra de phat hien.
  const [balance] = await db.$transaction([
    db.superLikeBalance.upsert({
      where: { guildId_userId: { guildId, userId: toUserId } },
      create: { guildId, userId: toUserId, amount: Math.max(0, delta) },
      update: { amount: { increment: delta } },
    }),
    db.superLikeGrant.create({
      data: {
        guildId,
        byUserId,
        toUserId,
        amount: delta,
        reason: args.reason?.trim().slice(0, 200) || null,
      },
    }),
  ]);

  return { ok: true, balance: balance.amount, delta };
}

export async function getBalance(guildId: string, userId: string): Promise<number> {
  const row = await db.superLikeBalance.findUnique({
    where: { guildId_userId: { guildId, userId } },
  });
  return row?.amount ?? 0;
}

/// Nhat ky cap gan day. Father dung de soat xem Cupid nao dang cap cho ai.
export async function recentGrants(guildId: string, limit = 15) {
  return db.superLikeGrant.findMany({
    where: { guildId },
    orderBy: { createdAt: "desc" },
    take: limit,
  });
}

/// Tong ket theo tung nguoi cap — de lo ra Cupid dang cap qua tay.
export async function grantsByStaff(guildId: string, sinceDays = 30) {
  const since = new Date(Date.now() - sinceDays * 86_400_000);
  return db.superLikeGrant.groupBy({
    by: ["byUserId"],
    where: { guildId, createdAt: { gte: since }, amount: { gt: 0 } },
    _sum: { amount: true },
    _count: { _all: true },
    orderBy: { _sum: { amount: "desc" } },
  });
}
