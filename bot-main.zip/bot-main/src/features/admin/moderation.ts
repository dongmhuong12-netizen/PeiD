import { ProfileStatus, ReportStatus } from "@prisma/client";
import { db } from "../../db.js";

/// Xu ly report va cam ho so.
///
/// Lan truoc bo report co mot lo hong that: report bay vao kenh mod roi nam
/// do vinh vien — khong co cach nao danh dau da xu ly, va nguong tu an
/// (3 report dang mo) khong bao gio giam xuong duoc. Nghia la mot ho so bi
/// 3 report oan se bi an vinh vien. Day la phan bi thieu.

/// Xoa lich su luot + match cua mot nguoi trong server -> ho va nhung nguoi
/// lien quan kham pha lai tu dau. KHONG dung toi Block (an toan) va so du
/// Super Like (do admin cap, khong phai trang thai luot).
///
/// Xoa ca hai chieu swipe: neu chi xoa swipe cua X thi nguoi da pass X van
/// khong thay X. Xoa ca match: giu match ma xoa swipe se cho re-swipe nguoi
/// da match, thanh trang thai la.
export async function resetUserSwipes(
  guildId: string,
  userId: string
): Promise<{ swipes: number; matches: number }> {
  const [swipes, matches] = await db.$transaction([
    db.swipe.deleteMany({
      where: { guildId, OR: [{ fromUserId: userId }, { toUserId: userId }] },
    }),
    db.match.deleteMany({
      where: { guildId, OR: [{ userAId: userId }, { userBId: userId }] },
    }),
  ]);
  return { swipes: swipes.count, matches: matches.count };
}

export async function openReports(guildId: string, limit = 10) {
  return db.report.findMany({
    where: { guildId, status: ReportStatus.OPEN },
    orderBy: { createdAt: "asc" },
    take: limit,
  });
}

/// Gom report theo nguoi bi to. Mot nguoi bi 5 nguoi khac to la mot tin
/// hieu hoan toan khac voi 5 nguoi bi to moi nguoi mot lan.
export async function reportsAgainst(guildId: string, userId: string) {
  return db.report.findMany({
    where: { guildId, reportedId: userId },
    orderBy: { createdAt: "desc" },
    take: 20,
  });
}

export type ModResult = { ok: true; note?: string } | { ok: false; error: string };

/// Dong report.
///
/// `dismiss` = to cao khong co co so. Quan trong: no PHAI go luon trang thai
/// an, neu khong thi ho so bi to oan van bi an mai du mod da ket luan la
/// khong sao.
export async function resolveReports(args: {
  guildId: string;
  reportedId: string;
  action: "resolve" | "dismiss";
  byUserId: string;
}): Promise<ModResult> {
  const { guildId, reportedId, byUserId } = args;

  const open = await db.report.count({
    where: { guildId, reportedId, status: ReportStatus.OPEN },
  });
  if (open === 0) return { ok: false, error: "Người này không có báo cáo nào đang mở." };

  const status = args.action === "resolve" ? ReportStatus.RESOLVED : ReportStatus.DISMISSED;

  await db.report.updateMany({
    where: { guildId, reportedId, status: ReportStatus.OPEN },
    data: { status, resolvedBy: byUserId, resolvedAt: new Date() },
  });

  if (args.action === "dismiss") {
    // Bo an. Chi dung khi dang UNDER_REVIEW — khong dung tay vao ho so da
    // bi BANNED (bo cam la viec cua /cupid unban, co chu dich ro rang).
    const profile = await db.profile.findUnique({
      where: { guildId_userId: { guildId, userId: reportedId } },
    });
    if (profile?.status === ProfileStatus.UNDER_REVIEW) {
      const { syncStatus } = await import("../onboarding.js");
      await db.profile.update({
        where: { id: profile.id },
        data: { status: ProfileStatus.DRAFT },
      });
      // Bat lai ACTIVE neu ho so con day du. Dat thang ACTIVE se hoi sinh ca
      // nhung ho so dang thieu anh/cau tra loi.
      await syncStatus(profile.id);
      return { ok: true, note: `Đã bỏ ẩn hồ sơ (${open} báo cáo được đánh dấu không có cơ sở).` };
    }
  }

  return { ok: true, note: `Đã đóng ${open} báo cáo.` };
}

export async function banProfile(args: {
  guildId: string;
  userId: string;
  byUserId: string;
}): Promise<ModResult> {
  const profile = await db.profile.findUnique({
    where: { guildId_userId: { guildId: args.guildId, userId: args.userId } },
  });
  if (!profile) return { ok: false, error: "Người này không có hồ sơ." };
  if (profile.status === ProfileStatus.BANNED) {
    return { ok: false, error: "Hồ sơ này đã bị cấm rồi." };
  }

  await db.$transaction([
    db.profile.update({ where: { id: profile.id }, data: { status: ProfileStatus.BANNED } }),
    // Dong luon cac report dang mo — da cam thi khong con gi de xem xet.
    db.report.updateMany({
      where: { guildId: args.guildId, reportedId: args.userId, status: ReportStatus.OPEN },
      data: { status: ReportStatus.RESOLVED, resolvedBy: args.byUserId, resolvedAt: new Date() },
    }),
  ]);

  return { ok: true, note: "Hồ sơ đã bị cấm và biến khỏi phần lướt của mọi người." };
}

export async function unbanProfile(args: {
  guildId: string;
  userId: string;
}): Promise<ModResult> {
  const profile = await db.profile.findUnique({
    where: { guildId_userId: { guildId: args.guildId, userId: args.userId } },
  });
  if (!profile) return { ok: false, error: "Người này không có hồ sơ." };
  if (profile.status !== ProfileStatus.BANNED && profile.status !== ProfileStatus.UNDER_REVIEW) {
    return { ok: false, error: "Hồ sơ này không bị cấm." };
  }

  const { syncStatus } = await import("../onboarding.js");
  await db.profile.update({ where: { id: profile.id }, data: { status: ProfileStatus.DRAFT } });
  await syncStatus(profile.id);

  const fresh = await db.profile.findUnique({ where: { id: profile.id } });
  return {
    ok: true,
    note:
      fresh?.status === ProfileStatus.ACTIVE
        ? "Hồ sơ đã hoạt động trở lại."
        : "Đã bỏ cấm. Hồ sơ chưa hiện lại vì còn thiếu thông tin — họ cần tự hoàn tất.",
  };
}
