import { Client, MessageFlags, type TextChannel } from "discord.js";
import { ReportStatus } from "@prisma/client";
import { db, isUniqueViolation } from "../db.js";
import { LIMITS } from "../limits.js";
import { getReason } from "./reportReasons.js";

// REPORT_REASONS song o reportReasons.ts (du lieu thuan) — ui/modals.ts can
// no de dung modal, ma mot cai modal thi khong nen keo theo ket noi Postgres.
export { REPORT_REASONS, reasonLabel, type ReportReason } from "./reportReasons.js";
import type { ReportReason } from "./reportReasons.js";
import { logger } from "../lib/logger.js";
import { notice } from "../ui/profileCard.js";
import { COLOR } from "../ui/theme.js";

const log = logger("safety");

export type ReportOutcome =
  | { kind: "filed" }
  | { kind: "already_reported" }
  | { kind: "no_profile" }
  | { kind: "rate_limited"; perDay: number };

/// Nhan mot report.
///
/// ─── Vi sao report KHONG tu khoa ho so ──────────────────────────────────
///
/// Ban dau mot report "nghi duoi 18" an ho so ngay lap tuc, va 3 report an
/// bat ke ai. Nhung nhu vay bien report thanh vu khi: mot nguoi (hoac vai
/// nguoi ban be) co the ha bat ky ai bang report gia. Do la "tro di pha".
///
/// Gio report KHONG dung toi trang thai ho so. No chi:
///   1. Ghi lai (kem snapshot ho so luc bi to — user sua/xoa sau do khong
///      thoat).
///   2. Bao mod (canh bao urgent neu nghi duoi 18) — mod tu quyet dinh khoa
///      bang /cupid ban.
///   3. Block phia nguoi report (tu bao ve minh, KHONG phat nguoi kia:
///      nguoi khac van thay ho binh thuong).
///
/// Chong pha them: moi nguoi chi report duoc N nguoi/ngay (gioi han tan
/// suat) va 1 nguoi chi report duoc 1 lan (unique constraint).
export async function fileReport(
  client: Client,
  args: {
    guildId: string;
    reporterId: string;
    reportedId: string;
    reasonKey: string;
    details?: string | null;
  }
): Promise<ReportOutcome> {
  const reason = getReason(args.reasonKey);
  if (!reason) return { kind: "no_profile" };

  const target = await db.profile.findUnique({
    where: { guildId_userId: { guildId: args.guildId, userId: args.reportedId } },
    include: { prompts: true, socials: true },
  });
  if (!target) return { kind: "no_profile" };

  // Gioi han tan suat: mot nguoi chi report duoc N nguoi trong 24h. Unique
  // constraint da chan report TRUNG 1 nguoi; cai nay chan report NHIEU nguoi
  // trong thoi gian ngan (di pha hang loat).
  const since = new Date(Date.now() - 24 * 3_600_000);
  const recent = await db.report.count({
    where: { guildId: args.guildId, reporterId: args.reporterId, createdAt: { gte: since } },
  });
  if (recent >= LIMITS.reportsPerReporterPerDay) {
    return { kind: "rate_limited", perDay: LIMITS.reportsPerReporterPerDay };
  }

  // Chup lai profile ngay luc bi report. User co the sua/xoa profile ngay
  // sau do — mod can thay cai da bi to cao, khong phai ban da duoc don dep.
  const snapshot = {
    displayName: target.displayName,
    age: target.age,
    gender: target.gender,
    bio: target.bio,
    photoUrl: target.photoUrl,
    prompts: target.prompts.map((p) => ({ key: p.promptKey, answer: p.answer })),
    socials: target.socials.map((s) => ({ platform: s.platform, value: s.value })),
    capturedAt: new Date().toISOString(),
  };

  try {
    await db.report.create({
      data: {
        guildId: args.guildId,
        reporterId: args.reporterId,
        reportedId: args.reportedId,
        reason: reason.key,
        details: args.details?.slice(0, 500) || null,
        snapshot,
      },
    });
  } catch (err) {
    // @@unique(guildId, reporterId, reportedId): moi nguoi chi report mot
    // nguoi khac dung 1 lan.
    if (isUniqueViolation(err)) return { kind: "already_reported" };
    throw err;
  }

  // Block phia nguoi report — tu bao ve, KHONG doi trang thai ho so nguoi kia.
  await blockUser(args.reporterId, args.reportedId);

  const openCount = await db.report.count({
    where: { guildId: args.guildId, reportedId: args.reportedId, status: ReportStatus.OPEN },
  });

  await notifyMods(client, {
    guildId: args.guildId,
    reporterId: args.reporterId,
    reportedId: args.reportedId,
    reason,
    details: args.details ?? null,
    openCount,
    snapshot,
  }).catch((e) => log.error("khong gui duoc report cho mod", e));

  return { kind: "filed" };
}

async function notifyMods(
  client: Client,
  r: {
    guildId: string;
    reporterId: string;
    reportedId: string;
    reason: ReportReason;
    details: string | null;
    openCount: number;
    snapshot: { displayName: string; age: number; photoUrl: string | null };
  }
): Promise<void> {
  const cfg = await db.guildConfig.findUnique({ where: { guildId: r.guildId } });
  if (!cfg?.modChannelId) {
    log.warn(`guild ${r.guildId} chua co modChannelId — report khong den duoc ai`);
    return;
  }

  const channel = (await client.channels.fetch(cfg.modChannelId)) as TextChannel | null;
  if (!channel?.isTextBased()) return;

  // severe = nghi duoi 18 -> canh bao khan. KHONG @here (tranh bi lam dung
  // spam ping); mau do + tieu de KHAN du noi bat cho mod dang theo doi kenh.
  const urgent = r.reason.severe;

  const body = [
    `**Bị báo cáo:** <@${r.reportedId}> — ${r.snapshot.displayName}, ${r.snapshot.age}`,
    `**Người báo:** <@${r.reporterId}>`,
    `**Lý do:** ${r.reason.label}`,
    r.details ? `**Chi tiết:** ${r.details}` : null,
    `**Report đang mở cho người này:** ${r.openCount}`,
    r.snapshot.photoUrl ? `**Ảnh lúc bị báo:** ${r.snapshot.photoUrl}` : null,
  ]
    .filter(Boolean)
    .join("\n");

  await channel.send({
    components: [
      notice({
        color: urgent ? COLOR.crimson : COLOR.slate,
        title: urgent ? "🚨 KHẨN — nghi hồ sơ dưới 18 tuổi" : "⚑ Report mới",
        body,
        footer: urgent
          ? "Ưu tiên xem ngay. Nếu đúng, /cupid ban để khoá. Hồ sơ KHÔNG tự bị khoá."
          : "Hồ sơ không tự bị khoá. Xử lý: /cupid reports · /cupid resolve · /cupid ban.",
      }),
    ],
    flags: MessageFlags.IsComponentsV2,
  });
}

/// Block toan cuc, hai chieu ve mat hien thi.
/// Luu 1 chieu (blocker -> blocked) nhung discovery loc ca hai phia, nen
/// hieu qua la ca hai deu khong thay nhau nua.
export async function blockUser(blockerId: string, blockedId: string): Promise<void> {
  if (blockerId === blockedId) return;
  await db.block
    .create({ data: { blockerId, blockedId } })
    .catch((err) => {
      if (!isUniqueViolation(err)) throw err;
    });
}

export async function isBlocked(a: string, b: string): Promise<boolean> {
  const hit = await db.block.findFirst({
    where: {
      OR: [
        { blockerId: a, blockedId: b },
        { blockerId: b, blockedId: a },
      ],
    },
  });
  return hit !== null;
}

