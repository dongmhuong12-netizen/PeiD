import type { Attachment, Client } from "discord.js";
import { db } from "../db.js";
import { logger } from "../lib/logger.js";
import { isStale } from "../lib/cdnUrl.js";

export { expiresAt, isStale } from "../lib/cdnUrl.js";

const log = logger("photo");

const MAX_BYTES = 8 * 1024 * 1024;
const ALLOWED = ["image/png", "image/jpeg", "image/webp"];

/// Chi chap nhan anh do bot nhan truc tiep tu Discord (attachment).
/// KHONG bao gio nhan URL do user go vao: user co the tro toi mot server ho
/// kiem soat, thu ve IP cua moi nguoi luot qua profile, hoac trao doi anh
/// sau khi da duoc mod duyet.
const CDN_HOSTS = ["cdn.discordapp.com", "media.discordapp.net"];

export type PhotoResult = { ok: true; url: string } | { ok: false; error: string };

export function validatePhoto(a: Attachment): PhotoResult {
  const host = safeHost(a.url);
  if (!host || !CDN_HOSTS.includes(host)) {
    return { ok: false, error: "Ảnh phải được tải trực tiếp lên Discord." };
  }
  // contentType do Discord tu sniff, khong phai do client khai bao — nen
  // tin duoc. Doi duoi file thi khong.
  if (!a.contentType || !ALLOWED.includes(a.contentType.split(";")[0]!.trim())) {
    return { ok: false, error: "Chỉ nhận ảnh PNG, JPG hoặc WEBP." };
  }
  if (a.size > MAX_BYTES) {
    return { ok: false, error: "Ảnh quá lớn (tối đa 8MB)." };
  }
  if (!a.width || !a.height) {
    return { ok: false, error: "File này không phải ảnh hợp lệ." };
  }
  if (a.width < 200 || a.height < 200) {
    return { ok: false, error: "Ảnh quá nhỏ (tối thiểu 200×200)." };
  }
  return { ok: true, url: a.url };
}

function safeHost(u: string): string | null {
  try {
    return new URL(u).hostname.toLowerCase();
  } catch {
    return null;
  }
}

// ─────────────────────────────────────────────────────────────────────────
// Lam moi URL het han
// ─────────────────────────────────────────────────────────────────────────
//
// Xem lib/cdnUrl.ts de hieu tai sao can den phan nay.
// Discord co endpoint doi link cu lay link moi. Ta goi no theo lo, ngay
// truoc khi hien card.

interface RefreshResponse {
  refreshed_urls: { original: string; refreshed: string }[];
}

/// Doi lo URL het han lay URL moi va ghi nguoc vao DB.
/// An toan khi goi thua: URL con han duoc bo qua ngay.
export async function refreshPhotos(
  client: Client,
  profiles: { id: string; photoUrl: string | null }[]
): Promise<Map<string, string>> {
  const out = new Map<string, string>();
  const stale = profiles.filter(
    (p): p is { id: string; photoUrl: string } => !!p.photoUrl && isStale(p.photoUrl)
  );
  if (stale.length === 0) return out;

  try {
    // Endpoint nhan toi da 50 URL moi lan.
    for (let i = 0; i < stale.length; i += 50) {
      const batch = stale.slice(i, i + 50);
      const res = (await client.rest.post("/attachments/refresh-urls" as `/${string}`, {
        body: { attachment_urls: batch.map((p) => p.photoUrl) },
      })) as RefreshResponse;

      const byOriginal = new Map(res.refreshed_urls.map((r) => [r.original, r.refreshed]));
      for (const p of batch) {
        const fresh = byOriginal.get(p.photoUrl);
        if (!fresh || fresh === p.photoUrl) continue;
        out.set(p.id, fresh);
        await db.profile
          .update({ where: { id: p.id }, data: { photoUrl: fresh } })
          .catch(() => {});
      }
    }
  } catch (err) {
    // Lam moi that bai thi van hien card — anh vo con hon khong co card.
    log.warn("lam moi URL anh that bai", err);
  }

  return out;
}

/// Lam moi anh cua 1 profile ngay truoc khi render. Tra ve chinh doi tuong
/// da duoc cap nhat de goi y goi lien mach.
export async function withFreshPhoto<T extends { id: string; photoUrl: string | null }>(
  client: Client,
  profile: T
): Promise<T> {
  if (!profile.photoUrl || !isStale(profile.photoUrl)) return profile;
  const map = await refreshPhotos(client, [profile]);
  const fresh = map.get(profile.id);
  return fresh ? { ...profile, photoUrl: fresh } : profile;
}
