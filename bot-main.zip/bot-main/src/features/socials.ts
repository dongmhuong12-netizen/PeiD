import { SocialPlatform } from "@prisma/client";

/// Link MXH — thay cho y tuong render profile ra anh bang Puppeteer.
///
/// Vi sao bo Puppeteer: moi lan render ton ~400MB RAM va 1-3 giay. 10 nguoi
/// luot cung luc la VPS chet. Va neu user kiem soat duoc HTML/CSS thi do la
/// mot be mat tan cong nghiem trong. Doi lai duoc gi? Mot buc anh. Card
/// Components V2 da dep san roi.
///
/// ─── An toan ─────────────────────────────────────────────────────────────
/// TUYET DOI khong nhan URL tu do. Neu nhan, tinh nang nay thanh cong cu
/// phat tan link phishing/scam duoc bot chinh chu hien thi -> nan nhan tin
/// tuong hon han link nguoi la gui. Vi vay:
///   - Moi platform co domain co dinh, hardcode.
///   - Chi luu HANDLE da qua regex, khong luu URL.
///   - URL duoc bot TU DUNG lai luc hien thi.
/// Ket qua: khong the tro link ra ngoai cac domain trong danh sach nay.

interface PlatformSpec {
  platform: SocialPlatform;
  label: string;
  /// Regex cho handle sau khi da boc vo. Neo ^...$ bat buoc.
  handle: RegExp;
  /// Cac host duoc chap nhan khi user dan ca URL vao.
  hosts: readonly string[];
  /// Dung URL cong khai tu handle.
  url: (h: string) => string;
  /// Duong dan mau, hien trong modal.
  hint: string;
}

const SPECS: readonly PlatformSpec[] = [
  {
    platform: SocialPlatform.INSTAGRAM,
    label: "Instagram",
    handle: /^[a-zA-Z0-9._]{1,30}$/,
    hosts: ["instagram.com", "www.instagram.com"],
    url: (h) => `https://instagram.com/${h}`,
    hint: "vidu: linh.nguyen hoặc instagram.com/linh.nguyen",
  },
  {
    platform: SocialPlatform.FACEBOOK,
    label: "Facebook",
    // FB cho phep dau cham va gach duoi trong username tuy chinh.
    handle: /^[a-zA-Z0-9._-]{5,50}$/,
    hosts: ["facebook.com", "www.facebook.com", "fb.com", "m.facebook.com"],
    url: (h) => `https://facebook.com/${h}`,
    hint: "vidu: linh.nguyen.9 hoặc facebook.com/linh.nguyen.9",
  },
  {
    platform: SocialPlatform.TIKTOK,
    label: "TikTok",
    handle: /^[a-zA-Z0-9._]{2,24}$/,
    hosts: ["tiktok.com", "www.tiktok.com"],
    url: (h) => `https://tiktok.com/@${h}`,
    hint: "vidu: linhcooks hoặc tiktok.com/@linhcooks",
  },
  {
    platform: SocialPlatform.SPOTIFY,
    label: "Spotify",
    handle: /^[a-zA-Z0-9]{1,64}$/,
    hosts: ["open.spotify.com", "spotify.com"],
    url: (h) => `https://open.spotify.com/user/${h}`,
    hint: "dán link profile Spotify của bạn",
  },
  {
    platform: SocialPlatform.TWITTER,
    label: "X (Twitter)",
    handle: /^[a-zA-Z0-9_]{1,15}$/,
    hosts: ["x.com", "twitter.com", "www.x.com", "www.twitter.com"],
    url: (h) => `https://x.com/${h}`,
    hint: "vidu: linhng hoặc x.com/linhng",
  },
];

const BY_PLATFORM = new Map(SPECS.map((s) => [s.platform as string, s]));

export function socialSpecs(): readonly PlatformSpec[] {
  return SPECS;
}

export function socialSpec(platform: string): PlatformSpec | undefined {
  return BY_PLATFORM.get(platform);
}

export type ParseResult =
  | { ok: true; handle: string }
  | { ok: false; error: string };

/// Boc handle ra tu bat ky thu gi user dan vao, roi validate.
/// Chap nhan: "linh.ng", "@linh.ng", "instagram.com/linh.ng",
///            "https://www.instagram.com/linh.ng/?igshid=xxx"
export function parseSocial(platform: string, raw: string): ParseResult {
  const spec = BY_PLATFORM.get(platform);
  if (!spec) return { ok: false, error: "Nền tảng không hợp lệ." };

  let s = raw.trim();
  if (!s) return { ok: false, error: "Bạn chưa nhập gì." };

  if (/^https?:\/\//i.test(s) || /^[\w.-]+\.[a-z]{2,}\//i.test(s)) {
    const withProto = /^https?:\/\//i.test(s) ? s : `https://${s}`;
    let u: URL;
    try {
      u = new URL(withProto);
    } catch {
      return { ok: false, error: "Link không hợp lệ." };
    }

    // Chot chan: host phai nam trong danh sach cung. So sanh chinh xac,
    // KHONG dung endsWith — `evil-instagram.com` se lot qua endsWith.
    const host = u.hostname.toLowerCase();
    if (!spec.hosts.includes(host)) {
      return {
        ok: false,
        error: `Link phải thuộc ${spec.hosts[0]}. Hoặc chỉ cần nhập tên tài khoản.`,
      };
    }

    const seg = u.pathname.split("/").filter(Boolean);
    // Spotify: /user/<id>  |  TikTok: /@<handle>  |  con lai: /<handle>
    let candidate =
      spec.platform === SocialPlatform.SPOTIFY
        ? seg[0] === "user"
          ? seg[1]
          : undefined
        : seg[0];
    if (!candidate) return { ok: false, error: "Không tìm thấy tên tài khoản trong link." };
    s = candidate;
  }

  s = s.replace(/^@/, "").trim();

  if (!spec.handle.test(s)) {
    return { ok: false, error: `Tên tài khoản không hợp lệ. ${spec.hint}` };
  }
  return { ok: true, handle: s };
}

/// Dung URL hien thi. Vi handle da qua regex va domain la hang so, chuoi
/// tra ve khong the tro ra ngoai cac domain o tren.
export function socialUrl(platform: string, handle: string): string | null {
  const spec = BY_PLATFORM.get(platform);
  return spec ? spec.url(handle) : null;
}

export function socialDisplay(platform: string, handle: string): string {
  const url = socialUrl(platform, handle);
  const shown = platform === SocialPlatform.SPOTIFY ? "profile" : `@${handle}`;
  return url ? `[${shown}](${url})` : shown;
}
