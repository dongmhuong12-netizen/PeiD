/// Danh sach tag so thich co san.
///
/// Thiet ke: luu duoi dang array of string trong model Profile de query nhanh,
/// dong thoi validate theo danh sach keys cung de tranh spam.

export interface TagSpec {
    key: string;
    label: string;
    emoji: string;
}

export const TAGS: readonly TagSpec[] = [
    { key: "game", label: "Chơi Game", emoji: "🎮" },
    { key: "music", label: "Nghe Nhạc", emoji: "🎵" },
    { key: "anime", label: "Anime / Manga", emoji: "🎎" },
    { key: "movie", label: "Xem Phim", emoji: "🎬" },
    { key: "travel", label: "Du Lịch", emoji: "✈️" },
    { key: "food", label: "Ẩm Thực", emoji: "🍕" },
    { key: "sports", label: "Thể Thao", emoji: "⚽" },
    { key: "photo", label: "Nhiếp Ảnh", emoji: "📸" },
    { key: "reading", label: "Đọc Sách", emoji: "📚" },
    { key: "coding", label: "Lập Trình", emoji: "💻" },
    { key: "cafe", label: "Đi Cafe", emoji: "☕" },
    { key: "gym", label: "Tập Gym / Fitness", emoji: "💪" },
    { key: "pet", label: "Thú Cưng", emoji: "🐱" },
    { key: "fashion", label: "Thời Trang", emoji: "👗" },
    { key: "art", label: "Vẽ / Nghệ Thuật", emoji: "🎨" },
] as const;

const BY_KEY = new Map(TAGS.map((t) => [t.key, t]));

export function getTag(key: string): TagSpec | undefined {
    return BY_KEY.get(key);
}

export function isValidTag(key: string): boolean {
    return BY_KEY.has(key);
}

export const MAX_TAGS = 8;
