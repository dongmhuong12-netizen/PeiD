import { Prisma } from "@prisma/client";
import { db } from "../db.js";
import type { FullProfile } from "../ui/profileCard.js";

/// Ung vien tiep theo de luot, kem tin hieu "nguoi nay da Super Like minh".
export interface Candidate {
  profile: FullProfile;
  /// Khac null neu nguoi nay da Super Like minh -> card se lam noi bat va
  /// hien loi nhan ho gui kem. Day la ly do Super Like co gia tri: nguoi
  /// nhan THAY duoc, khong phai ve mot chieu vo nghia.
  superLikedYou: { note: string | null } | null;
}

// resolveSwipeLimit song o limits.ts (logic thuan). Re-export de router chi
// phai import tu mot cho.
export { resolveSwipeLimit } from "../limits.js";

const INCLUDE = {
  prompts: { orderBy: { position: "asc" } },
  socials: true,
} satisfies Prisma.ProfileInclude;

function startOfToday(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

export async function countSwipesToday(guildId: string, userId: string): Promise<number> {
  return db.swipe.count({
    where: { guildId, fromUserId: userId, createdAt: { gte: startOfToday() } },
  });
}

/// Dem so ung vien con lai. Dung cho ca tran swipe dong lan trang thai rong.
export async function countPool(me: FullProfile): Promise<number> {
  const rows = await db.$queryRaw<{ n: bigint }[]>`
    SELECT count(*)::bigint AS n
    FROM ${candidateFrom(me)}
  `;
  return Number(rows[0]?.n ?? 0);
}

/// Dieu kien loc ung vien — dung chung boi countPool va nextCandidate de
/// hai cai KHONG BAO GIO lech nhau. (Lech nhau = bot bao "con 8 nguoi"
/// roi hien "het nguoi roi".)
function candidateFrom(me: FullProfile): Prisma.Sql {
  return Prisma.sql`
    "Profile" p
    WHERE p."guildId" = ${me.guildId}
      AND p.status = 'ACTIVE'
      AND p."userId" <> ${me.userId}

      -- Loc 2 CHIEU: ho hop gu minh VA minh hop gu ho. Loc 1 chieu se cho
      -- user xem nhung nguoi khong bao gio like lai -> ty le match thap,
      -- user bo bot.
      AND p.gender = ANY(${me.seeking}::"Gender"[])
      AND p.age BETWEEN ${me.seekAgeMin} AND ${me.seekAgeMax}
      AND ${me.gender}::"Gender" = ANY(p.seeking)
      AND ${me.age} BETWEEN p."seekAgeMin" AND p."seekAgeMax"

      -- Da swipe roi thi khong hien lai. Swipe luu theo userId nen xoa
      -- profile roi tao lai KHONG reset duoc.
      AND NOT EXISTS (
        SELECT 1 FROM "Swipe" s
        WHERE s."guildId" = ${me.guildId}
          AND s."fromUserId" = ${me.userId}
          AND s."toUserId" = p."userId"
      )

      -- Block la 2 chieu va toan cuc.
      AND NOT EXISTS (
        SELECT 1 FROM "Block" b
        WHERE (b."blockerId" = ${me.userId} AND b."blockedId" = p."userId")
           OR (b."blockerId" = p."userId" AND b."blockedId" = ${me.userId})
      )
  `;
}

/// Lay 1 ung vien tiep theo.
///
/// Xep hang thay cho ELO:
///   0. Nguoi da Super Like minh len TRUOC TIEN — day la gia tri that su cua
///      Super Like: nguoi gui duoc uu tien xuat hien, kem loi nhan.
///   1. Bucket theo so lan da duoc show (moi 5 lan = 1 bucket). Nguoi it
///      duoc show len truoc => moi profile deu co co hoi, khong ai roi vao
///      vong xoay "it show -> it like -> cang it show" nhu ELO gay ra.
///   2. Trong cung bucket: nguoi hoat dong trong 3 ngay qua len truoc.
///      Match voi tai khoan chet la trai nghiem te nhat.
///   3. Con lai: ngau nhien, de moi nguoi khong thay cung 1 thu tu.
export async function nextCandidate(me: FullProfile): Promise<Candidate | null> {
  const rows = await db.$queryRaw<{ id: string }[]>`
    SELECT p.id
    FROM ${candidateFrom(me)}
    ORDER BY
      (EXISTS (
        SELECT 1 FROM "SuperLikeSent" sl
        WHERE sl."guildId" = ${me.guildId}
          AND sl."fromUserId" = p."userId"
          AND sl."toUserId" = ${me.userId}
      )) DESC,
      (COALESCE((
        SELECT count(*)::int
        FROM unnest(p.tags) t
        WHERE t = ANY(${me.tags}::text[])
      ), 0)) DESC,
      (p."timesShown" / 5) ASC,
      CASE WHEN p."lastActiveAt" > now() - interval '3 days' THEN 0 ELSE 1 END ASC,
      random()
    LIMIT 1
  `;

  const id = rows[0]?.id;
  if (!id) return null;

  const profile = await db.profile.findUnique({ where: { id }, include: INCLUDE });
  if (!profile) return null;

  // Dem exposure. Khong await de khong lam cham phan hoi — sai lech 1-2 lan
  // khong anh huong gi den chat luong xep hang.
  void db.profile
    .update({ where: { id }, data: { timesShown: { increment: 1 } } })
    .catch(() => { });

  // Nguoi nay co Super Like minh khong? -> lay note de hien noi bat tren card.
  const incoming = await db.superLikeSent.findUnique({
    where: {
      guildId_fromUserId_toUserId: {
        guildId: me.guildId,
        fromUserId: profile.userId,
        toUserId: me.userId,
      },
    },
  });
  const superLikedYou = incoming ? { note: incoming.note } : null;

  return { profile, superLikedYou };
}

export async function getDestinyCandidate(me: FullProfile): Promise<Candidate | null> {
  const rows = await db.$queryRaw<{ id: string }[]>`
    SELECT p.id
    FROM ${candidateFrom(me)}
    ORDER BY
      (COALESCE((
        SELECT count(*)::int
        FROM unnest(p.tags) t
        WHERE t = ANY(${me.tags}::text[])
      ), 0)) DESC,
      p."lastActiveAt" DESC
    LIMIT 1
  `;

  const id = rows[0]?.id;
  if (!id) return null;

  const profile = await db.profile.findUnique({ where: { id }, include: INCLUDE });
  if (!profile) return null;

  return {
    profile: profile as FullProfile,
    superLikedYou: null,
  };
}

export async function getProfile(guildId: string, userId: string): Promise<FullProfile | null> {
  return db.profile.findUnique({
    where: { guildId_userId: { guildId, userId } },
    include: INCLUDE,
  });
}

export async function touchActivity(guildId: string, userId: string): Promise<void> {
  await db.profile
    .updateMany({
      where: { guildId, userId },
      data: { lastActiveAt: new Date() },
    })
    .catch(() => { });
}
