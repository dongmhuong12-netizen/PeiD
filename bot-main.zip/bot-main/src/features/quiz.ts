import { ButtonBuilder, ButtonStyle } from "discord.js";
import { COLOR } from "../ui/theme.js";
import { notice } from "../ui/profileCard.js";
import { ID } from "../lib/ids.js";

export interface Question {
    text: string;
    options: string[];
}

export const QUIZ_QUESTIONS: Question[] = [
    {
        text: "Buổi hẹn hò đầu tiên lý tưởng của bạn sẽ là?",
        options: [
            "Quán cafe yên tĩnh, nhẹ nhàng chill chill ☕",
            "Đi phượt, leo núi trải nghiệm thiên nhiên ngoại ô ⛰️",
            "Net cỏ chiến game, leo rank thâu đêm 🎮",
            "Rạp chiếu phim xem phim bom tấn 🎬"
        ]
    },
    {
        text: "Nếu đối phương bất ngờ biến mất không rep tin nhắn suốt 2 ngày?",
        options: [
            "Lo lắng hỏi han xem họ có gặp chuyện gì không 🥺",
            "Hơi dỗi một tí, họ nhắn lại thì tỏ thái độ 😤",
            "Kệ họ, mình vẫn tiếp tục cuộc sống bình thường 🍃",
            "Tự động ngầm hiểu là 'hết duyên' và block luôn 🚫"
        ]
    },
    {
        text: "Hình mẫu người yêu lý tưởng của bạn thiên về gì?",
        options: [
            "Ngoại hình cuốn hút, nhìn là yêu ngay 😍",
            "Tâm hồn đồng điệu, nói chuyện hợp gu ✨",
            "Tính cách ấm áp, biết quan tâm chăm sóc 🌻",
            "Tài năng vượt trội, có chí tiến thủ lớn 🚀"
        ]
    },
    {
        text: "Khi có mâu thuẫn hay cãi cọ, bạn sẽ làm gì?",
        options: [
            "Im lặng suy nghĩ, khi bình tĩnh mới nói chuyện 🤐",
            "Phải nói rõ ràng ngay lập tức cho ra nhẽ 🗣️",
            "Nhờ bạn bè, người thân vào làm trung gian hoà giải 👥",
            "Chủ động nhận lỗi trước để giữ hoà khí dù mình đúng hay sai 🙏"
        ]
    },
    {
        text: "Bạn thích đi du lịch kiểu nào nhất?",
        options: [
            "Resort sang chảnh nghỉ dưỡng thảnh thơi 🏖️",
            "Du lịch bụi khám phá các vùng đất mới 🎒",
            "Du lịch tâm linh, đi chùa cầu may 🏛️",
            "Chỉ muốn ở nhà nằm ngủ hưởng thụ ngày nghỉ 🛌"
        ]
    }
];

export function buildQuestionCard(qIndex: number): any {
    const q = QUIZ_QUESTIONS[qIndex];
    if (!q) {
        throw new Error(`Question at index ${qIndex} not found`);
    }

    const buttons = q.options.map((_, idx) => {
        const letters = ["A", "B", "C", "D"];
        return new ButtonBuilder()
            .setCustomId(ID.quizAns(idx))
            .setLabel(letters[idx]!)
            .setStyle(ButtonStyle.Primary);
    });

    const bodyText = q.options.map((opt, idx) => {
        const letters = ["A", "B", "C", "D"];
        return `**${letters[idx]}**. ${opt}`;
    }).join("\n");

    return notice({
        color: COLOR.violet,
        title: `Câu hỏi ${qIndex + 1}/5: ${q.text}`,
        body: bodyText,
        buttons,
    });
}
