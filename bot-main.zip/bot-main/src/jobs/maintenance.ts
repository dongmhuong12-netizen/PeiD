import { Client, MessageFlags, ButtonBuilder, ButtonStyle } from "discord.js";
import { MatchStatus } from "@prisma/client";
import { db } from "../db.js";
import { LIMITS } from "../limits.js";
import { logger } from "../lib/logger.js";
import { notice } from "../ui/profileCard.js";
import { COLOR, GLYPH } from "../ui/theme.js";
import { ID } from "../lib/ids.js";
import { sendDM } from "../lib/dm.js";

const log = logger("jobs");

/// Match het han opt-in: mot ben khong bao gio bam.
///
/// Day la ly do co co che opt-in: khong ai bi keo vao phong voi nguoi khong
/// muon noi chuyen voi minh. Het han thi im lang cho qua — KHONG bao cho
/// ben da bam la "nguoi kia lo ban". Khong ai can biet dieu do.
async function expireOptIns(): Promise<number> {
  const res = await db.match.updateMany({
    where: { status: MatchStatus.PENDING_OPT_IN, optInExpiresAt: { lt: new Date() } },
    data: { status: MatchStatus.EXPIRED },
  });
  return res.count;
}

/// Don thread im lang.
///
/// Ke hoach ban dau: bot nhan "Có vẻ 2 bạn không hợp nhau" roi khoa phong.
/// Da bo cau do. Hai nguoi vua im lang mot thoi gian khong can bot phan xet
/// ho co hop nhau khong — co the ho da chuyen sang nhan tin rieng, hoac chi
/// don gian la ban. Chi don rac, khong binh luan.
async function archiveIdleThreads(client: Client): Promise<number> {
  const cutoff = new Date(Date.now() - LIMITS.idleThreadHours * 3_600_000);

  const stale = await db.match.findMany({
    where: {
      status: MatchStatus.ACTIVE,
      lastActivityAt: { lt: cutoff },
      threadId: { not: null },
    },
    take: 50,
  });

  let n = 0;
  for (const m of stale) {
    try {
      const thread = await client.channels.fetch(m.threadId!).catch(() => null);
      if (thread?.isThread() && !thread.archived) {
        await thread.send({
          components: [
            notice({
              color: COLOR.slate,
              title: "Phòng này đã được dọn",
              body: "Không có tin nhắn nào một thời gian, nên bot khép lại cho gọn.",
              footer: "Nhắn tin vào đây là phòng tự mở lại.",
            }),
          ],
          flags: MessageFlags.IsComponentsV2,
        });
        // Archive chu KHONG lock: ai nhan tin vao la thread tu song lai.
        // Lock lai la cat dut that su — do la viec cua /unmatch, khong phai
        // cua mot job don rac.
        await thread.setArchived(true);
      }
      await db.match.update({
        where: { id: m.id },
        data: { status: MatchStatus.ARCHIVED },
      });
      n++;
    } catch (err) {
      log.debug(`khong archive duoc thread ${m.threadId}`, err);
    }
  }
  return n;
}

/// Thread co tin nhan moi -> cap nhat lastActivityAt de job don rac bo qua.
export function trackThreadActivity(client: Client): void {
  client.on("messageCreate", async (msg) => {
    if (msg.author.bot || !msg.channel.isThread()) return;
    await db.match
      .updateMany({
        where: { threadId: msg.channel.id, status: MatchStatus.ARCHIVED },
        data: { status: MatchStatus.ACTIVE, lastActivityAt: new Date() },
      })
      .catch(() => { });
    await db.match
      .updateMany({
        where: { threadId: msg.channel.id, status: MatchStatus.ACTIVE },
        data: { lastActivityAt: new Date() },
      })
      .catch(() => { });
  });
}

async function sendOptInReminders(client: Client): Promise<number> {
  const cutoff = new Date(Date.now() + 6 * 3_600_000);
  const now = new Date();

  // Lay cac match can gui reminder
  const matches = await db.match.findMany({
    where: {
      status: MatchStatus.PENDING_OPT_IN,
      reminderSentAt: null,
      optInExpiresAt: { lte: cutoff, gte: now },
    },
    take: 50,
  });

  let count = 0;
  for (const m of matches) {
    try {
      // Gui cho user A neu ho chua Ready
      if (!m.userAReady) {
        const them = await db.profile.findFirst({
          where: { guildId: m.guildId, userId: m.userBId },
        });
        const userA = await client.users.fetch(m.userAId).catch(() => null);
        if (userA) {
          await sendDM(userA, {
            components: [
              notice({
                color: COLOR.gold,
                title: `⚡ Ghép cặp với ${them?.displayName ?? "ai đó"} sắp hết hạn!`,
                body: "Bạn còn ít hơn 6 tiếng để bấm nút.",
                buttons: [
                  new ButtonBuilder()
                    .setCustomId(ID.matchReady(m.id))
                    .setLabel("Bắt đầu chat")
                    .setEmoji(GLYPH.chat)
                    .setStyle(ButtonStyle.Success),
                  new ButtonBuilder()
                    .setCustomId(ID.matchDecline(m.id))
                    .setLabel("Bỏ qua")
                    .setStyle(ButtonStyle.Secondary),
                ],
              }),
            ],
            flags: MessageFlags.IsComponentsV2,
          });
        }
      }

      // Gui cho user B neu ho chua Ready
      if (!m.userBReady) {
        const them = await db.profile.findFirst({
          where: { guildId: m.guildId, userId: m.userAId },
        });
        const userB = await client.users.fetch(m.userBId).catch(() => null);
        if (userB) {
          await sendDM(userB, {
            components: [
              notice({
                color: COLOR.gold,
                title: `⚡ Ghép cặp với ${them?.displayName ?? "ai đó"} sắp hết hạn!`,
                body: "Bạn còn ít hơn 6 tiếng để bấm nút.",
                buttons: [
                  new ButtonBuilder()
                    .setCustomId(ID.matchReady(m.id))
                    .setLabel("Bắt đầu chat")
                    .setEmoji(GLYPH.chat)
                    .setStyle(ButtonStyle.Success),
                  new ButtonBuilder()
                    .setCustomId(ID.matchDecline(m.id))
                    .setLabel("Bỏ qua")
                    .setStyle(ButtonStyle.Secondary),
                ],
              }),
            ],
            flags: MessageFlags.IsComponentsV2,
          });
        }
      }

      // Cap nhat DB da gui reminder
      await db.match.update({
        where: { id: m.id },
        data: { reminderSentAt: new Date() },
      });
      count++;
    } catch (err) {
      log.error(`loi gui reminder cho match ${m.id}`, err);
    }
  }

  return count;
}

async function cleanupDraftProfiles(): Promise<number> {
  const cutoff = new Date(Date.now() - LIMITS.draftProfileCleanupDays * 24 * 3600 * 1000);
  const res = await db.profile.deleteMany({
    where: {
      status: "DRAFT",
      lastActiveAt: { lt: cutoff },
    },
  });
  return res.count;
}

export function startJobs(client: Client): void {
  const tick = async () => {
    try {
      const expired = await expireOptIns();
      const archived = await archiveIdleThreads(client);
      const reminded = await sendOptInReminders(client);
      const cleanedDrafts = await cleanupDraftProfiles();
      if (expired || archived || reminded || cleanedDrafts) {
        log.info(`don dep: ${expired} match het han, ${archived} phong im lang, ${reminded} nhac nho opt-in, ${cleanedDrafts} ho so nhap cu`);
      }
    } catch (err) {
      log.error("job loi", err);
    }
  };

  // Chay ngay khi khoi dong: bot tat vai ngay thi co dong ton du can don.
  void tick();
  setInterval(tick, 30 * 60 * 1000);
  log.info("job don dep chay moi 30 phut");
}
