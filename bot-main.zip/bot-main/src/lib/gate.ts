import type { GuildConfig } from "@prisma/client";
import type { GuildMember, Interaction } from "discord.js";
import { db } from "../db.js";
import { isDevUser } from "../features/admin/permissions.js";

export type GateResult =
  | { ok: true; guildId: string; cfg: GuildConfig }
  | { ok: false; reason: string };

/// Cong kiem tra truoc MOI hanh dong lien quan den hen ho.
///
/// Lop phong ve tuoi: bot khong the tu xac minh tuoi that cua ai ca — o
/// Tuoi trong modal chi la text, go gi cung duoc. Nen phong ve that nam o
/// cho khac: server phai chi dinh mot ROLE, va admin tu chiu trach nhiem
/// cap role do cho nguoi 18+.
///
/// Bot khong hoat dong cho den khi role do duoc cau hinh. Day la ly do
/// `enabled` mac dinh false: mot bot hen ho tu bat len o server bat ky, tron
/// lan trong so do co ca server tre em, la thu khong duoc phep ton tai.
export async function gate(i: Interaction): Promise<GateResult> {
  if (!i.inGuild() || !i.guildId) {
    return { ok: false, reason: "Chỉ dùng được trong server." };
  }

  const cfg = await db.guildConfig.findUnique({ where: { guildId: i.guildId } });
  if (!cfg?.enabled) {
    return {
      ok: false,
      reason: "Bot chưa được bật ở server này. Nhờ chủ server chạy `/father setup`.",
    };
  }
  if (!cfg.verifiedRoleId) {
    return { ok: false, reason: "Server chưa cấu hình xong. Nhờ admin chạy lại setup." };
  }

  // Dev toan cuc bo qua yeu cau role xac minh — de kiem thu va dieu khien o
  // server bat ky. Van doi bot da duoc setup (discovery can cau hinh); neu
  // chua, dev co isFather nen tu chay /father setup duoc.
  if (isDevUser(i.user.id)) {
    return { ok: true, guildId: i.guildId, cfg };
  }

  const member = i.member as GuildMember | null;
  const roles = member?.roles;
  const has =
    roles && "cache" in roles
      ? roles.cache.has(cfg.verifiedRoleId)
      : Array.isArray(roles)
        ? (roles as string[]).includes(cfg.verifiedRoleId)
        : false;

  if (!has) {
    return {
      ok: false,
      reason:
        `Bạn cần role <@&${cfg.verifiedRoleId}> để dùng bot.\n` +
        "Liên hệ mod của server để được cấp.",
    };
  }

  return { ok: true, guildId: i.guildId, cfg };
}
