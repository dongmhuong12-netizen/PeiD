/// Doc han cua URL Discord CDN. Logic thuan — khong dung database, khong
/// dung mang.
///
/// ─── Van de ──────────────────────────────────────────────────────────────
/// Tu 2023, MOI link CDN cua Discord deu duoc ky va het han sau ~24 gio:
///
///     https://cdn.discordapp.com/attachments/.../a.png
///         ?ex=<unix-he-16>&is=<unix-he-16>&hm=<chu-ky>
///
/// Bo tham so di thi Discord tra 403. Luu thang url vao DB roi quen =
/// TOAN BO anh profile hong sau dung mot ngay.
///
/// Day la cai bay chi lo ra o production: luc dev anh nao cung moi tinh nen
/// moi thu deu chay, den hom sau moi biet.

/// Doc tham so `ex` — thoi diem link chet, unix seconds viet he 16.
export function expiresAt(url: string): Date | null {
  try {
    const ex = new URL(url).searchParams.get("ex");
    if (!ex) return null;
    const secs = parseInt(ex, 16);
    return Number.isFinite(secs) ? new Date(secs * 1000) : null;
  } catch {
    return null;
  }
}

/// Coi la het han khi con duoi 1 gio.
/// Bien an toan: khong bao gio dua link sap chet cho client render — card co
/// the nam trong DM nhieu gio truoc khi nguoi ta mo ra doc.
export function isStale(url: string): boolean {
  const at = expiresAt(url);
  if (!at) return false; // Khong co chu ky -> khong het han (anh cu, hoac URL ngoai).
  return at.getTime() - Date.now() < 3_600_000;
}
