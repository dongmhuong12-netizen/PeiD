import { User, MessagePayload, MessageCreateOptions, Message } from "discord.js";
import { logger } from "./logger.js";

const log = logger("dm");

interface DMJob {
    user: User | { send: (options: string | MessagePayload | MessageCreateOptions) => Promise<Message> };
    options: string | MessagePayload | MessageCreateOptions;
    resolve: (value: Message | null) => void;
    reject: (reason: any) => void;
}

const queue: DMJob[] = [];
let processing = false;

async function processQueue() {
    if (processing) return;
    processing = true;

    while (queue.length > 0) {
        const job = queue.shift();
        if (!job) continue;

        try {
            const msg = await job.user.send(job.options);
            job.resolve(msg);
        } catch (err) {
            log.warn(`Không gửi được DM: ${err instanceof Error ? err.message : String(err)}`);
            // Tránh crash bot, hoàn thành Promise với null
            job.resolve(null);
        }

        // Khoảng cách an toàn giữa các tin DM
        await new Promise((resolve) => setTimeout(resolve, 150));
    }

    processing = false;
}

/**
 * Gửi DM cho User qua hàng đợi để chống rate limit Discord API.
 * Trả về Message nếu gửi thành công, hoặc null nếu lỗi (ví dụ block DM).
 */
export function sendDM(
    user: User | { send: (options: any) => Promise<Message> },
    options: string | MessagePayload | MessageCreateOptions
): Promise<Message | null> {
    return new Promise((resolve, reject) => {
        queue.push({ user, options, resolve, reject });
        void processQueue();
    });
}
