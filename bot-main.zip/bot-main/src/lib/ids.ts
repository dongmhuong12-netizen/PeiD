/// Ma hoa/giai ma customId cua component.
///
/// Discord gioi han customId 100 ky tu. Format: `d|<kind>|<args...>`
/// Prefix `d` de bot bo qua ngay cac component khong phai cua minh.
///
/// Tat ca customId deu di qua day. KHONG bao gio noi chuoi customId thu cong
/// o noi khac — de doi format chi phai sua 1 file.

const P = "d";
const SEP = "|";

export type ParsedId =
  | { kind: "swipe"; action: "like" | "pass" | "super"; targetId: string }
  | { kind: "swipe_next" }
  | { kind: "report_open"; targetId: string }
  | { kind: "report_submit"; targetId: string }
  | { kind: "block"; targetId: string }
  | { kind: "profile_setup" }
  | { kind: "profile_modal"; section: "basics" | "prompts" }
  | { kind: "profile_prefs" }
  | { kind: "profile_socials" }
  | { kind: "profile_tags" }
  | { kind: "profile_tags_select" }
  | { kind: "profile_socials_modal"; platform: string }
  | { kind: "match_ready"; matchId: string }
  | { kind: "match_decline"; matchId: string }
  | { kind: "unmatch_ask"; matchId: string }
  | { kind: "unmatch_do"; matchId: string }
  | { kind: "superlike_note"; targetId: string }
  | { kind: "cupid_perms"; targetId: string }
  | { kind: "quiz_start"; matchId: string }
  | { kind: "quiz_answer"; optionIndex: number }
  | { kind: "destiny_like"; userId: string }
  | { kind: "custom_glyph_list" }
  | { kind: "custom_glyph_pick"; key: string }
  | { kind: "custom_glyph_reset"; key: string }
  | { kind: "custom_glyph_page"; key: string; page: number; search: string }
  | { kind: "custom_glyph_search"; key: string }
  | { kind: "custom_glyph_clear"; key: string }
  | { kind: "custom_glyph_search_submit"; key: string }
  | { kind: "noop" };

export const ID = {
  swipe: (action: "like" | "pass" | "super", targetId: string) =>
    j("sw", action, targetId),
  swipeNext: () => j("nx"),
  reportOpen: (targetId: string) => j("ro", targetId),
  reportSubmit: (targetId: string) => j("rs", targetId),
  block: (targetId: string) => j("bl", targetId),
  profileSetup: () => j("ps"),
  profileModal: (section: "basics" | "prompts") => j("pm", section),
  profilePrefs: () => j("pp"),
  profileSocials: () => j("so"),
  profileTags: () => j("pt"),
  profileTagsSelect: () => j("ts"),
  profileSocialsModal: (platform: string) => j("sm", platform),
  matchReady: (matchId: string) => j("mr", matchId),
  matchDecline: (matchId: string) => j("md", matchId),
  unmatchAsk: (matchId: string) => j("ua", matchId),
  unmatchDo: (matchId: string) => j("ud", matchId),
  superLikeNote: (targetId: string) => j("sn", targetId),
  cupidPerms: (targetId: string) => j("cp", targetId),
  quizStart: (matchId: string) => j("qst", matchId),
  quizAns: (optIdx: number) => j("qan", optIdx.toString()),
  destinyLike: (userId: string) => j("dsl", userId),
  customGlyphList: () => j("cgl"),
  customGlyphPick: (key: string) => j("cgp", key),
  customGlyphReset: (key: string) => j("cgr", key),
  noop: () => j("no"),
} as const;

function j(...parts: string[]): string {
  const id = [P, ...parts].join(SEP);
  if (id.length > 100) {
    throw new Error(`customId qua dai (${id.length}/100): ${id}`);
  }
  return id;
}

export function parseId(customId: string): ParsedId | null {
  if (!customId.startsWith(P + SEP)) return null;
  const [, kind, a, b, c] = customId.split(SEP);

  switch (kind) {
    case "sw":
      if (a !== "like" && a !== "pass" && a !== "super") return null;
      if (!b) return null;
      return { kind: "swipe", action: a, targetId: b };
    case "nx":
      return { kind: "swipe_next" };
    case "ro":
      return a ? { kind: "report_open", targetId: a } : null;
    case "rs":
      return a ? { kind: "report_submit", targetId: a } : null;
    case "bl":
      return a ? { kind: "block", targetId: a } : null;
    case "ps":
      return { kind: "profile_setup" };
    case "pm":
      if (a !== "basics" && a !== "prompts") return null;
      return { kind: "profile_modal", section: a };
    case "pp":
      return { kind: "profile_prefs" };
    case "so":
      return { kind: "profile_socials" };
    case "pt":
      return { kind: "profile_tags" };
    case "ts":
      return { kind: "profile_tags_select" };
    case "sm":
      return a ? { kind: "profile_socials_modal", platform: a } : null;
    case "mr":
      return a ? { kind: "match_ready", matchId: a } : null;
    case "md":
      return a ? { kind: "match_decline", matchId: a } : null;
    case "ua":
      return a ? { kind: "unmatch_ask", matchId: a } : null;
    case "ud":
      return a ? { kind: "unmatch_do", matchId: a } : null;
    case "sn":
      return a ? { kind: "superlike_note", targetId: a } : null;
    case "cp":
      return a ? { kind: "cupid_perms", targetId: a } : null;
    case "qst":
      return a ? { kind: "quiz_start", matchId: a } : null;
    case "dsl":
      return a ? { kind: "destiny_like", userId: a } : null;
    case "cgl":
      return { kind: "custom_glyph_list" };
    case "cgp":
      return a ? { kind: "custom_glyph_pick", key: a } : null;
    case "cgr":
      return a ? { kind: "custom_glyph_reset", key: a } : null;
    case "cgp_page":
      return a ? { kind: "custom_glyph_page", key: a, page: b ? parseInt(b, 10) : 0, search: c || "" } : null;
    case "cgp_search":
      return a ? { kind: "custom_glyph_search", key: a } : null;
    case "cgp_clear":
      return a ? { kind: "custom_glyph_clear", key: a } : null;
    case "cgs_submit":
      return a ? { kind: "custom_glyph_search_submit", key: a } : null;
    case "no":
      return { kind: "noop" };
    default:
      return null;
  }
}
