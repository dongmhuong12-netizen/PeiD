/// Logic thuan lien quan den cap nguoi dung — khong dung den database.

/// Sap xep 2 userId ve dang chuan (userA < userB).
///
/// Nho vay bang Match chi can MOT @@unique(guildId, userAId, userBId) la
/// chan duoc trung o CA HAI chieu. Khong co no thi (A,B) va (B,A) la hai
/// dong hop le khac nhau, va hai nguoi co the co 2 match voi nhau cung luc.
export function orderPair(x: string, y: string): { userAId: string; userBId: string } {
  return x < y ? { userAId: x, userBId: y } : { userAId: y, userBId: x };
}

/// Postgres tra ve ma nay khi vi pham unique constraint.
/// Toan bo co che chong race condition cua bot dua vao viec bat dung ma nay
/// — xem comment dai trong features/swipe.ts.
export const UNIQUE_VIOLATION = "P2002";

export function isUniqueViolation(err: unknown): boolean {
  return (
    typeof err === "object" &&
    err !== null &&
    "code" in err &&
    (err as { code: unknown }).code === UNIQUE_VIOLATION
  );
}
