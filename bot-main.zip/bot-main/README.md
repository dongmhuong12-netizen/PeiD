# Discord Dating Bot

Bot hẹn hò cho Discord. Ý niệm: slow dating - ít lượt lướt, hồ sơ có chiều sâu, ghép đôi không dùng ELO.

---

## Hướng dẫn Cài đặt và Khởi chạy

Vui lòng lựa chọn một trong hai hướng dẫn bên dưới phù hợp với nhu cầu và năng lực kỹ thuật của bạn.

### Phần 1: Dành cho người dùng kỹ thuật (Sử dụng Railway, Docker, Postgres cục bộ)

Yêu cầu: Đã cài đặt sẵn Docker và Node.js trên máy.

```bash
npm install

# Khởi tạo Database qua Docker cục bộ
docker run --name dating-db -e POSTGRES_PASSWORD=dev -p 5432:5432 -d postgres:16
npm run db:push

# Cấu hình biến môi trường
cp .env.example .env      # Điền các biến DISCORD_TOKEN, DISCORD_CLIENT_ID và DATABASE_URL

# Đăng ký các lệnh gạch chéo (slash commands) lên Discord
npm run deploy

# Khởi chạy bot phát triển cục bộ
npm run dev
```

Để deploy lên Railway:
1. Tạo project mới trên Railway.
2. Thêm service PostgreSQL.
3. Kết nối mã nguồn bot từ GitHub lên Railway, cấu hình các biến môi trường trong mục Variables tương tự như trong file .env trên. Railway sẽ tự động chạy bot 24/7.

---

### Phần 2: Dành cho người mới bắt đầu (Không dùng Railway, Docker hoặc Postgres cục bộ)

Hướng dẫn này giúp bạn chạy bot trực tiếp trên máy tính cá nhân làm máy chủ, kết hợp với cơ sở dữ liệu đám mây miễn phí.

#### Bước 1: Cài đặt Node.js trên máy tính
- Truy cập trang chủ: https://nodejs.org/ và tải bản LTS mới nhất về cài đặt.
- Kiểm tra phiên bản bằng cách mở Terminal/PowerShell và nhập:
  ```bash
  node -v
  npm -v
  ```

#### Bước 2: Tạo Database miễn phí trên Neon.tech (Chỉ mất 1 phút)
- Truy cập: https://neon.tech/ và đăng nhập bằng tài khoản Google hoặc GitHub.
- Tạo một project mới tên là dating-db.
- Sao chép chuỗi kết nối có dạng:
  `postgresql://neondb_owner:mat_khau@ep-xxxx-xxxx.us-east-2.aws.neon.tech/neondb?sslmode=require`
  Chuỗi này sẽ được dùng để điền vào DATABASE_URL ở Bước 4.

#### Bước 3: Tạo Bot trên Discord Developer Portal
- Truy cập: https://discord.com/developers/applications và click New Application để tạo.
- Chuyển vào tab Bot:
  - Cho phép intent: cuộn xuống mục Privileged Gateway Intents và bật ở SERVER MEMBERS INTENT.
  - Reset Token và sao chép lại token của bot.
- Chuyển vào tab General Information:
  - Sao chép ở Application ID (Client ID).

#### Bước 4: Thiết lập file .env
- Trong thư mục của bot, sao chep file .env.example và đổi tên thành .env.
- Dùng notepad mở file .env và nhập như sau:
  ```env
  DISCORD_TOKEN=dien-token-bot-da-copy-o-buoc-3-vao-day
  DISCORD_CLIENT_ID=dien-application-id-da-copy-o-buoc-3-vao-day
  DEV_USER_ID=dien-id-discord-cua-ban-vao-day (Để làm admin tối cao)
  DATABASE_URL="dien-chuoi-ket-noi-neon-da-copy-o-buoc-2-vao-day"
  LOG_LEVEL=info
  ```

#### Bước 5: Tải thư viện và chạy bot
- Mở cmd hoặc powershell tại thư mục của bot và chạy các lệnh sau:
  ```bash
  # Tải các thư viện của bot
  npm install

  # Đồng bộ cơ sở dữ liệu đám mây
  npx prisma db push

  # Đăng ký lệnh với Discord
  npm run deploy

  # Chạy bot
  npm run dev
  ```

---

## Discord Developer Portal Settings

Bot cần một Privileged Gateway Intent duy nhất:
- SERVER MEMBERS INTENT - để đọc thông tin role xác minh tuổi của thành viên.

Không cần intent Message Content.

Quyền hạn cần thiết của bot khi mời vào server: Manage Threads, Create Private Threads, Send Messages in Threads.

---

## Kích hoạt cho server Discord

Chủ server (hoặc người đặt ở DEV_USER_ID) bắt buộc phải chạy lệnh này để bật hoạt động cho bot sau khi mời vào:

```text
/father setup verified-role:@RoleXacMinh18+ lounge:#kenh-duyet-khi-match mod-channel:#kenh-nhan-report
```

Bot sẽ không cho phép bất kỳ tương tác tính năng nào cho đến khi lệnh setup được chạy thành công trên server đó.

---

## Các quyết định thiết kế cần biết

### Không dùng ELO
Xếp hạng ứng viên dựa trên expose balancing (src/features/discovery.ts) thay vì thứ hạng ELO để tránh tình trạng death spiral (người ít thích càng ngày càng bị ẩn đi). Thứ tự ưu tiên là số lượt hiển thị phải đồng đều, tiếp đó là tần suất hoạt động và lựa chọn ngẫu nhiên.

### Match không tự tạo phòng ngay lập tức
Sau khi cả hai thích nhau, bot gửi tin nhắn riêng cho từng bên kèm theo nút bấm bắt đầu chat. Chỉ khi cả hai đầu đều đồng ý (Opt-in) trong thời hạn cho phép thì giao diện chat riêng (thread) mới thực sự mở ra, đảm bảo không ai bị bất ngờ kéo vào cuộc trò chuyện riêng tư mà họ không chủ động.

### Trần swipe co giãn theo quy mô
Giới hạn swipe mỗi ngày được tính động theo pool người dùng trên server chứ không cố định, thấp nhất là 5 và cao nhất là 30 lượt quẹt.

### Mạng xã hội chỉ bật mí sau khi match
Thông tin về các liên kết mạng xã hội chỉ được công khai sau khi cả hai bên match thành công và đồng ý mở lounge thread. Điều này vừa để bảo vệ thông tin riêng tư khỏi nạn spam, vừa tránh việc người dùng chỉ quẹt để tăng lượt theo dõi mạng xã hội.

---

## An toàn và Quyền riêng tư

### Quản lý báo cáo và chặn
Mỗi báo cáo đều đi kèm tự động chặn (block) người bị báo cáo ngay lập tức. Người dùng chỉ được báo cáo một người khác duy nhất một lần. Khi một hồ sơ nhận quá 3 báo cáo bất kỳ sẽ tự động bị ẩn tạm thời để chờ Ban quản trị duyệt hệ thông. Báo cáo nghi ngờ dưới 18 tuổi sẽ bị ẩn lập tức chỉ sau một báo cáo đầu tiên.

### Ảnh trên thẻ hồ sơ
Chỉ lấy liên kết từ Discord CDN. Khi đọc sẽ làm mới URL bằng endpoint lấy từ CDN theo lô trước khi hiển thị, tránh việc liên kết ảnh bị hỏng vì Discord CDN tự động thay đổi token chữ ký sau 24h.

---

## Phân quyền Admin: Dev / Father / Cupid

Lõi phân quyền đặt tại src/features/admin/permissions.ts.
- DEV_USER_ID trong file .env cho phép một tài khoản duy nhất có toàn quyền tối cao ở mọi server mà không thể bị hạ quyền bởi bất kỳ ai.
- Chủ server luôn mặc định là Father và có toàn quyền cấu hình, cấp quyền Cupid hoặc rút quyền.
- Quyền Cupid có thể cấp từng phần: Cấp Super Like, Xử lý báo cáo, Cấm/Mở cấm tài khoản, Xem số liệu thống kê.

---

## Cảm ơn sự quan tâm của bạn đến dự án
Dating Bot luôn sẵn sàng mang lại trải nghiệm kết nối nghiêm túc và an toàn cho cộng đồng của bạn.
